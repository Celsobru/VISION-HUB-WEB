/* ============================================
   AUTO CUT - Service Worker
   Verificação de licença Vísion Plus + badge de progresso
   + exportação no servidor (sobrevive ao fechar aba/popup)
   ============================================ */

const VP_API_URL = 'http://localhost:3009/api';
const VP_SERVER_URL = 'http://localhost:3009';

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CHECK_LICENSE') {
    checkVisionPlusLicense(request.data && request.data.instagram ? request.data.instagram : '')
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ licensed: false, status: 'error', message: err.message }));
    return true;
  }

  if (request.type === 'EXPORT_CLIPS') {
    exportClipsServer(request.data)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (request.type === 'PROGRESS_UPDATE') {
    const data = request.data || {};
    if (data.percent && data.percent > 0 && data.percent < 100) {
      chrome.action.setBadgeText({ text: data.percent + '%' });
      chrome.action.setBadgeBackgroundColor({ color: '#ff4757' });
    } else if (data.percent === 100) {
      chrome.action.setBadgeText({ text: '✓' });
      chrome.action.setBadgeBackgroundColor({ color: '#2ecc71' });
      setTimeout(() => chrome.action.setBadgeText({ text: '' }), 4000);
    }
    return false;
  }

  return false;
});

async function checkVisionPlusLicense(instagram) {
  if (!instagram) {
    return { licensed: false, status: 'no_username', message: 'Informe seu @ do Instagram.' };
  }

  const igUsername = String(instagram).replace('@', '').trim().toLowerCase();

  try {
    const response = await fetch(VP_API_URL + '/license/check?instagram=' + encodeURIComponent(igUsername) + '&product=autocut');
    const data = await response.json();

    chrome.storage.local.set({ 'vp_license': JSON.stringify({
      licensed: data.licensed,
      status: data.status,
      message: data.message,
      daysLeft: data.daysLeft || 0,
      expiresAt: data.expiresAt || null,
      checkedAt: new Date().toISOString(),
      instagram: igUsername
    })});

    return data;
  } catch (err) {
    // Servidor offline: usa cache com menos de 48h, senão bloqueia
    const cached = await new Promise(resolve => {
      chrome.storage.local.get('vp_license', (result) => {
        if (result.vp_license) {
          const parsed = JSON.parse(result.vp_license);
          if (Date.now() - new Date(parsed.checkedAt).getTime() < 48 * 60 * 60 * 1000) {
            parsed.fromCache = true;
            resolve(parsed);
            return;
          }
        }
        resolve(null);
      });
    });

    if (cached && cached.licensed) {
      return { ...cached, fromCache: true, message: cached.message + ' (verificado há pouco, offline agora)' };
    }
    return { licensed: false, status: 'offline', message: 'Não foi possível verificar sua licença. Certifique-se de que o Vísion Hub esteja rodando (porta 3009).' };
  }
}

/* ============ EXPORTAÇÃO NO SERVIDOR ============ */
/* O corte é feito no servidor com ffmpeg (não depende do player do YouTube).
   Aqui no service worker, o processo continua mesmo fechando o popup ou a aba. */

async function exportClipsServer(data) {
  const exportId = Date.now();
  const exportName = `export_${data.videoId}_${exportId}`;
  const destFolder = sanitizeFolder(data.destFolder || 'AutoCut');
  const progressUrl = `${VP_SERVER_URL}/api/corteviral/output/${exportName}/progress.json`;

  const poller = setInterval(async () => {
    try {
      const r = await fetch(progressUrl, { cache: 'no-store' });
      if (r.ok) {
        const p = await r.json();
        if (p && p.pct !== undefined) {
          broadcastProgress({ percent: p.pct, phase: p.msg || 'Processando...' });
          if (p.pct >= 100) clearInterval(poller);
        }
      }
    } catch (e) {}
  }, 900);

  try {
    const response = await fetch(`${VP_SERVER_URL}/api/corteviral/export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, exportId })
    });
    clearInterval(poller);

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Erro na exportação');
    }

    const result = await response.json();
    if (result.error) throw new Error(result.error);

    if (result.exportName) {
      broadcastProgress({ percent: 100, phase: 'Aguarde, salvando na pasta ' + destFolder + '...' });
    }

    const fileNames = (result.files || []).map(f => f.filename);
    if (result.legendaFile) fileNames.push(result.legendaFile);
    if (result.metadataFile) fileNames.push(result.metadataFile);

    const downloaded = [];
    const fails = [];
    for (const file of fileNames) {
      try {
        await downloadViaChrome(result.exportName, file, destFolder);
        downloaded.push(`${destFolder}/${file}`);
      } catch (e) {
        fails.push(file + ': ' + e.message);
      }
    }

    if (downloaded.length === 0) {
      throw new Error('Nenhum arquivo foi salvo. ' + (fails.join(' | ') || ''));
    }

    broadcastProgress({
      percent: 100,
      phase: `Finalizado: ${downloaded.length} arquivo(s) em Downloads/${destFolder}`
    });
    return { success: true, exportName: result.exportName, downloaded, folder: destFolder, warnings: fails };
  } catch (e) {
    clearInterval(poller);
    throw e;
  }
}

function broadcastProgress(data) {
  try {
    chrome.runtime.sendMessage({ type: 'PROGRESS_UPDATE', data }).catch(() => {});
  } catch (e) {}
}

function sanitizeFolder(name) {
  return String(name || 'AutoCut')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim() || 'AutoCut';
}

function downloadViaChrome(exportName, file, destFolder) {
  const url = `${VP_SERVER_URL}/api/corteviral/output/${exportName}/${encodeURIComponent(file)}`;
  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      { url, filename: `${destFolder}/${file}`, conflictAction: 'uniquify', saveAs: false },
      (downloadId) => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        resolve(downloadId);
      }
    );
  });
}