/* ============================================
   AUTO CUT - Motor de Análise Local (100% no navegador)
   Análise de texto/legendas + seleção de trechos virais
   ============================================ */

const CorteAnalyzer = (function () {

  const VIRAL_KEYWORDS = {
    high: [
      'incrível', 'inacreditável', 'insano', 'loucura', 'absurdo', 'muito bom',
      'melhor', 'pior', 'nunca', 'sempre', 'todo mundo', 'ninguém',
      'verdade', 'mentira', 'real', 'sério', 'cuidado', 'perigo',
      'segredo', 'descobri', 'revelou', 'expôs', 'provou',
      'incredible', 'unbelievable', 'insane', 'crazy', 'amazing',
      'never', 'always', 'everyone', 'nobody', 'truth', 'lie',
      'secret', 'discovered', 'revealed', 'exposed', 'proved'
    ],
    emotion: [
      'chorar', 'risada', 'raiva', 'medo', 'esperança', 'amor',
      'odio', 'triste', 'feliz', 'orgulho', 'vergonha', 'surpresa',
      'decepcionado', 'empolgado', 'animado', 'calmo', 'nervoso',
      'cry', 'laugh', 'angry', 'afraid', 'hope', 'love',
      'hate', 'sad', 'happy', 'proud', 'shame', 'surprise',
      'disappointed', 'excited', 'animated', 'calm', 'nervous'
    ],
    hook: [
      'olha', 'olha só', 'veja', 'presta atenção', 'escuta',
      'imagina', 'pensa', 'que tal', 'e se', 'vocês sabiam',
      'eu vou', 'eu fiz', 'eu descobri', 'eu vi', 'eu ouvi',
      'look', 'watch', 'listen', 'imagine', 'think',
      'what if', 'did you know', 'I will', 'I did', 'I found'
    ],
    viral: [
      'trending', 'viral', 'polêmico', 'controverso', 'polêmica',
      'meme', 'divertido', 'hilário', 'engraçado', 'piada',
      'dica', 'truque', 'hack', 'segredo', 'fórmula',
      'trending', 'viral', 'controversial', 'funny', 'meme',
      'tip', 'trick', 'hack', 'secret', 'formula'
    ]
  };

  const PUNCTUATION_SIGNALS = {
    '!': 1.5,
    '?!': 2.0,
    '??': 1.8,
    '...': 1.3,
    '¡': 1.5,
    '¿': 1.3
  };

  // ---------- TIME HELPERS ----------
  function parseDuration(str) {
    if (!str) return 0;
    const parts = str.split(':').map(Number);
    if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    if (parts.length === 2) return parts[0] * 60 + parts[1];
    return parts[0] || 0;
  }

  function formatTime(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hrs > 0) return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  }

  // ---------- ANÁLISE DE TEXTO ----------
  function analyzeText(text) {
    let score = 30;
    const lowerText = text.toLowerCase();
    const words = lowerText.split(/\s+/);
    const wordCount = words.length;

    for (const [punct, multiplier] of Object.entries(PUNCTUATION_SIGNALS)) {
      if (text.includes(punct)) score += 8 * multiplier;
    }

    let keywordHits = 0;
    for (const category of Object.values(VIRAL_KEYWORDS)) {
      for (const keyword of category) {
        if (lowerText.includes(keyword)) { keywordHits++; score += 5; }
      }
    }

    if (wordCount > 15) score += 5;
    if (wordCount > 25) score += 5;

    const capsWords = words.filter(w => w === w.toUpperCase() && w.length > 2);
    if (capsWords.length > 0) score += capsWords.length * 4;

    const numbers = text.match(/\d+/g);
    if (numbers && numbers.length > 0) score += 3 * numbers.length;

    if (text.includes('?')) score += 8;

    return {
      score: Math.min(100, Math.max(10, Math.round(score))),
      keywordHits,
      wordCount,
      hasExclamation: text.includes('!'),
      hasQuestion: text.includes('?'),
      isEmotional: Object.values(VIRAL_KEYWORDS.emotion).some(k => lowerText.includes(k))
    };
  }

  // ---------- SELEÇÃO DOS MELHORES TRECHOS ----------
  function findBestSegments(segments, maxDuration, numClips) {
    if (!segments || segments.length === 0) return [];

    const analyzed = segments.map(seg => ({ ...seg, analysis: analyzeText(seg.text) }));

    // Agrupa segmentos próximos (janela de 3s)
    const groups = [];
    let currentGroup = [];

    for (let i = 0; i < analyzed.length; i++) {
      const seg = analyzed[i];
      if (currentGroup.length === 0) {
        currentGroup.push(seg);
      } else {
        const lastEnd = currentGroup[currentGroup.length - 1].start +
                       currentGroup[currentGroup.length - 1].duration;
        if (seg.start - lastEnd < 3) {
          currentGroup.push(seg);
        } else {
          groups.push([...currentGroup]);
          currentGroup = [seg];
        }
      }
    }
    if (currentGroup.length > 0) groups.push(currentGroup);

    const scoredGroups = groups.map(group => {
      const totalText = group.map(s => s.text).join(' ');
      const startTime = group[0].start;
      const endTime = group[group.length - 1].start + group[group.length - 1].duration;
      const duration = Math.min(endTime - startTime, maxDuration);

      let groupScore = group.reduce((sum, s) => sum + s.analysis.score, 0) / group.length;
      const strongSignals = group.filter(s => s.analysis.score > 50).length;
      if (strongSignals > 0) groupScore += strongSignals * 3;
      if (group.some(s => s.analysis.isEmotional)) groupScore += 5;
      if (group.some(s => s.analysis.hasQuestion)) groupScore += 5;
      if (group.some(s => s.analysis.hasExclamation)) groupScore += 3;

      return {
        start: startTime,
        end: Math.min(startTime + maxDuration, Math.max(endTime, startTime + 10)),
        duration,
        text: totalText,
        score: Math.min(100, Math.round(groupScore)),
        segmentCount: group.length
      };
    });

    scoredGroups.sort((a, b) => b.score - a.score);

    function overlaps(aStart, aEnd, bStart, bEnd, tolerance) {
      const tol = tolerance || 5;
      return aStart < bEnd - tol && bStart < aEnd - tol;
    }

    const selected = [];
    const minSeparation = 10;

    for (const group of scoredGroups) {
      if (selected.length >= numClips) break;
      const groupEnd = group.end;
      const clash = selected.some(s => Math.abs(group.start - s.start) < minSeparation || overlaps(group.start, groupEnd, s.start, s.end));
      if (!clash) selected.push(group);
    }

    // Se faltam cortes, distribui uniformemente (determinístico, sem sobrepor)
    if (selected.length < numClips && analyzed.length > 0) {
      const totalDuration = analyzed[analyzed.length - 1].start;
      const usedRanges = selected.map(s => ({ start: s.start, end: s.end }));
      let guard = 0;

      while (selected.length < numClips && guard < numClips * 6) {
        guard++;
        const slot = (selected.length % numClips) + 1;
        const position = (totalDuration * slot) / (numClips + 1) + guard;
        const endPos = Math.min(position + maxDuration, totalDuration);
        if (endPos - position < 10) continue;
        const clash = usedRanges.some(r => Math.abs(position - r.start) < minSeparation || overlaps(position, endPos, r.start, r.end));
        if (!clash) {
          selected.push({
            start: position,
            end: endPos,
            duration: endPos - position,
            text: `Corte na posição ${formatTime(position)}`,
            score: 50,
            segmentCount: 0
          });
          usedRanges.push({ start: position, end: endPos });
        }
      }
    }

    selected.sort((a, b) => a.start - b.start);
    return selected;
  }

  // ---------- GERAÇÃO DE DESCRIÇÃO / HASHTAGS ----------
  function generateDescription(text) {
    if (!text) return 'Corte viral';
    const clean = text.replace(/\s+/g, ' ').trim();
    if (clean.length <= 100) return clean;
    const words = clean.split(' ');
    let desc = '';
    for (const word of words) {
      if ((desc + ' ' + word).length > 95) break;
      desc = desc ? desc + ' ' + word : word;
    }
    return desc + '...';
  }

  function generateHashtags(style) {
    const base = ['#viral', '#trending', '#fyp'];
    const styles = {
      viral: ['#reels', '#shorts'],
      funny: ['#humor', '#engraçado', '#meme', '#comédia'],
      educational: ['#dica', '#aprenda', '#conhecimento', '#tutorial'],
      emotional: ['#emoção', '#motivação', '#vidaboa', '#frases'],
      controversial: ['#polêmico', '#debate', '#opinião', '#controvérsia']
    };
    return [...base, ...(styles[style] || styles.viral)].join(' ');
  }

  function generateStyleDescription(style, number) {
    const descriptions = {
      viral: ['Momento impactante que vai te surpreender', 'O trecho que todo mundo está compartilhando', 'Isso é insano! Veja só'],
      funny: ['Hahaha esse momento é impagável', 'Piada que ninguém esperava', 'Ri demais com isso'],
      educational: ['Dica valiosa que você precisa saber', 'Aprenda algo novo agora', 'Conhecimento que vale ouro'],
      emotional: ['Momento que toca o coração', 'Frase que fica na cabeça', 'Lição de vida profunda'],
      controversial: ['Polêmica que gerou debate', 'O lado que ninguém vê', 'Questão que divide opiniões']
    };
    const options = descriptions[style] || descriptions.viral;
    return options[(number - 1) % options.length];
  }

  function extractHook(text) {
    if (!text) return '';
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 5);
    if (sentences.length > 0) return sentences[0].trim().substring(0, 100);
    return text.substring(0, 100);
  }

  // ---------- ANÁLISE PRINCIPAL (acoes 100% locais) ----------
  function analyzeVideo(info, options) {
    const { clipType, style, maxDuration, numClips, manualClips, startTime, segments } = options;
    const totalSeconds = parseDuration(info.duration);
    const startSeconds = startTime ? parseDuration(startTime) : 0;

    // Sem duração válida, qualquer corte seria lixo (ex: tudo 0:00) — falha alto
    if (!(totalSeconds > 0) && clipType !== 'manual') {
      return { clips: [], method: 'none', error: 'Duração do vídeo não detectada. Dê play e recarregue a página.' };
    }

    // MODALIDADE MANUAL
    if (clipType === 'manual') {
      const clips = (manualClips || []).map((clip, index) => ({
        id: index + 1,
        start: clip.start,
        end: clip.end,
        startTime: parseDuration(clip.start),
        endTime: parseDuration(clip.end),
        description: `Corte manual ${index + 1}`,
        hashtags: '',
        score: 70,
        selected: true
      }));
      return { clips, method: 'manual', requiresRecording: true };
    }

    // BASEIA-SE NAS LEGENDAS DO PRÓPRIO VÍDEO (buscadas na página)
    const filteredSegments = startSeconds > 0
      ? (segments || []).filter(seg => seg.start >= startSeconds)
      : (segments || []);

    if (filteredSegments.length > 0) {
      const bestClips = findBestSegments(filteredSegments, maxDuration, numClips);
      if (bestClips.length > 0) {
        const clips = bestClips.map((clip, index) => ({
          id: index + 1,
          start: formatTime(clip.start),
          end: formatTime(clip.end),
          startTime: clip.start,
          endTime: clip.end,
          description: generateDescription(clip.text),
          hashtags: generateHashtags(style),
          score: clip.score,
          hook: extractHook(clip.text),
          selected: true
        }));
        return { clips, method: 'subtitles', requiresRecording: true };
      }
    }

    // FALLBACK: distribuição por tempo quando não há legendas (determinístico, sem sobrepor)
    const clips = [];
    // Vídeo menor que 1 corte: 1 único corte com o vídeo inteiro
    if (totalSeconds > 0 && totalSeconds <= maxDuration && startSeconds <= 0) {
      clips.push({
        id: 1,
        start: formatTime(0),
        end: formatTime(totalSeconds),
        startTime: 0,
        endTime: totalSeconds,
        description: generateStyleDescription(style, 1),
        hashtags: generateHashtags(style),
        score: 70,
        hook: '',
        selected: true
      });
      return { clips, method: 'timing-full', requiresRecording: true };
    }
    const availableDuration = totalSeconds - startSeconds;
    for (let i = 0; i < numClips; i++) {
      const basePos = startSeconds + (availableDuration * (i + 1)) / (numClips + 1);
      const latestStart = Math.max(startSeconds, totalSeconds - maxDuration);
      const position = Math.max(startSeconds, Math.min(latestStart, basePos));
      const start = Math.floor(position);
      const end = Math.min(start + maxDuration, totalSeconds);

      let score = 55;
      if (position < 0.15) score = 65;
      else if (position > 0.3 && position < 0.7) score = 70;
      else if (position > 0.8) score = 60;

      clips.push({
        id: i + 1,
        start: formatTime(start),
        end: formatTime(end),
        startTime: start,
        endTime: end,
        description: generateStyleDescription(style, i + 1),
        hashtags: generateHashtags(style),
        score: Math.min(100, score + Math.floor(Math.random() * 15)),
        hook: '',
        selected: true
      });
    }
    return { clips, method: 'timing', requiresRecording: true };
  }

  return { analyzeVideo, analyzeText, findBestSegments, parseDuration, formatTime };
})();