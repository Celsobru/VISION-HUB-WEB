/* ============================================
   AUTO CUT - Content Script
   Extrai dados do vídeo e faz análise local.
   A exportação é feita no servidor (ffmpeg)
   e os arquivos são salvos pelo service worker.
   ============================================ */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'GET_VIDEO_INFO':
      sendResponse(getVideoInfo());
      return false;

    case 'GET_CURRENT_TIME': {
      const video = document.querySelector('video');
      if (video && video.currentTime !== undefined) {
        sendResponse({ time: formatClock(video.currentTime) });
      } else {
        sendResponse({ time: null });
      }
      return false;
    }

    case 'FETCH_SUBTITLES':
      fetchYouTubeSubtitles(request.data.videoId)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ error: err.message, segments: [] }));
      return true;

    case 'ANALYZE_VIDEO':
      analyzeVideoLocal(request.data)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ error: err.message }));
      return true;
  }
  return false;
});

/* ============ HELPERS ============ */
function formatClock(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

/* ============ GET_VIDEO_INFO ============ */
function getVideoInfo() {
  try {
    const url = window.location.href;
    if (!url.includes('youtube.com/watch')) {
      return { error: 'Não está em um vídeo do YouTube', url };
    }
    const videoId = new URLSearchParams(window.location.search).get('v');
    if (!videoId) return { error: 'Não foi possível obter o ID do vídeo' };

    const titleSelectors = ['h1.ytd-watch-metadata yt-formatted-string', '#title h1 yt-formatted-string', 'h1.title yt-formatted-string', '#container h1', 'h1'];
    const durationSelectors = ['.ytp-time-duration', '#description .ytp-time-duration', 'span.ytp-time-duration'];
    const channelSelectors = ['#channel-name a', 'ytd-channel-name a', '#owner #channel-name a', 'a.yt-simple-endpoint.style-scope.ytd-channel-name'];

    let title = '', duration = '', channel = '', description = '';
    for (const sel of titleSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) { title = el.textContent.trim(); break; }
    }
    for (const sel of durationSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) { duration = el.textContent.trim(); break; }
    }
    for (const sel of channelSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) { channel = el.textContent.trim(); break; }
    }

    const descEl = document.querySelector('#description-inline-expander') || document.querySelector('#description') || document.querySelector('ytd-text-inline-expander');
    if (descEl) description = descEl.textContent?.trim().substring(0, 2000) || '';

    // Duração: 1) dados internos do player (mais confiável) 2) DOM 3) elemento <video>
    try {
        const lenSec = window.ytInitialPlayerResponse?.videoDetails?.lengthSeconds;
        const n = parseInt(lenSec, 10);
        if (Number.isFinite(n) && n > 0) duration = formatClock(n);
    } catch (e) {}
    const video = document.querySelector('video');
    if (!duration && video && Number.isFinite(video.duration) && video.duration > 0) duration = formatClock(video.duration);
    if (!duration) return { error: 'Duração não detectada — dê play no vídeo e recarregue a página.' };
    if (!title) return { error: 'Não foi possível detectar o título. Tente recarregar a página.' };

    // URL direta de streaming (para o servidor baixar com ffmpeg)
    const videoUrl = extractStreamingUrl(video);

    return { title, duration: duration || '0:00', channel: channel || 'Desconhecido', description, videoId, videoUrl };
  } catch (err) {
    return { error: 'Erro ao obter info: ' + err.message };
  }
}

function extractStreamingUrl(video) {
  try {
    const html = document.documentElement.innerHTML;

    // itag=22 (mp4 720p com áudio) — melhor qualidade progressiva
    const m22 = html.match(/"url"\s*:\s*"(https:\/\/[^"]*googlevideo\.com[^"]*itag=22[^"]*)"/);
    if (m22) return m22[1].replace(/\\u0026/g, '&');

    // itag=18 (mp4 360p com áudio)
    const m18 = html.match(/"url"\s*:\s*"(https:\/\/[^"]*googlevideo\.com[^"]*itag=18[^"]*)"/);
    if (m18) return m18[1].replace(/\\u0026/g, '&');

    // qualquer videoplayback
    const any = html.match(/(https:\/\/[^"]*googlevideo\.com\/videoplayback[^"]*)/);
    if (any) return any[1].replace(/\\u0026/g, '&');

    // blob (último recurso — servidor vai usar yt-dlp)
    if (video && video.src) return video.src;
  } catch (e) {}
  return '';
}

/* ============ LEGENDAS ============ */
async function fetchYouTubeSubtitles(videoId) {
  const trackSource = extractCaptionTrack();
  if (!trackSource) return { lang: null, segments: [], error: 'Nenhuma legenda disponível para este vídeo' };

  const { lang, captionUrl } = trackSource;
  const segments = await fetchCaption(captionUrl, videoId);
  if (segments.length === 0) {
    return { lang, segments: [], error: 'Não foi possível baixar o conteúdo da legenda' };
  }
  return { lang, segments };
}

function extractCaptionTrack() {
  if (window.ytInitialPlayerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.length) {
    const tracks = window.ytInitialPlayerResponse.captions.playerCaptionsTracklistRenderer.captionTracks;
    const track = tracks.find(t => t.languageCode === 'pt' || t.languageCode === 'pt-BR') || tracks[0];
    return { lang: track.languageCode, captionUrl: track.baseUrl };
  }
  try {
    const html = document.documentElement.innerHTML;
    const idx = html.indexOf('"captionTracks"');
    if (idx !== -1) {
      const start = html.indexOf('[', idx);
      const end = html.indexOf(']', start);
      if (start !== -1 && end !== -1) {
        const tracks = JSON.parse(html.substring(start, end + 1));
        if (tracks.length > 0) {
          const track = tracks.find(t => t.languageCode === 'pt' || t.languageCode === 'pt-BR') || tracks[0];
          return { lang: track.languageCode, captionUrl: track.baseUrl };
        }
      }
    }
  } catch (e) {}
  return null;
}

function fetchCaption(baseUrl, videoId) {
  return new Promise((resolve) => {
    const candidates = [];
    if (baseUrl) candidates.push(baseUrl);
    if (videoId) {
      candidates.push(`https://www.youtube.com/api/timedtext?v=${videoId}&lang=pt&kind=asr`);
      candidates.push(`https://www.youtube.com/api/timedtext?v=${videoId}&lang=pt`);
    }

    let idx = 0;
    const tryNext = () => {
      if (idx >= candidates.length) { resolve([]); return; }
      const url = candidates[idx++];
      const xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.withCredentials = true;
      xhr.onload = () => {
        const text = xhr.responseText;
        if (xhr.status !== 200 || !text || text.length < 10) { tryNext(); return; }
        const segments = parseCaption(text);
        if (segments.length > 0) resolve(segments);
        else tryNext();
      };
      xhr.onerror = () => tryNext();
      xhr.send();
    };
    tryNext();
  });
}

function parseCaption(text) {
  if (text.trim().startsWith('<')) {
    const parser = new DOMParser();
    const xml = parser.parseFromString(text, 'text/xml');
    const segments = [];
    xml.querySelectorAll('text').forEach(el => {
      const txt = el.textContent
        .replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&quot;/g, '"')
        .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/<[^>]*>/g, '').trim();
      if (txt) segments.push({ start: parseFloat(el.getAttribute('start') || '0'), duration: parseFloat(el.getAttribute('dur') || '0'), text: txt });
    });
    if (segments.length > 0) return segments;
    xml.querySelectorAll('p').forEach(p => {
      const txt = p.textContent.replace(/<[^>]*>/g, '').trim();
      if (txt) segments.push({ start: parseInt(p.getAttribute('t') || '0') / 1000, duration: parseInt(p.getAttribute('d') || '0') / 1000, text: txt });
    });
    return segments;
  }
  if (text.trim().startsWith('{')) {
    try {
      const data = JSON.parse(text);
      if (data.events) {
        return data.events
          .filter(e => e.segs && e.segs.length > 0)
          .map(e => ({ start: e.tStartMs / 1000, duration: e.dDurationMs / 1000, text: e.segs.map(s => s.utf8).join('').trim() }))
          .filter(s => s.text.length > 0 && s.text !== '\n');
      }
    } catch (e) {}
  }
  return [];
}

/* ============ ANÁLISE LOCAL ============ */
async function analyzeVideoLocal(data) {
  const info = { duration: data.duration || '0:00', title: data.title || '' };

  const options = {
    clipType: data.clipType,
    style: data.style || 'viral',
    maxDuration: parseInt(data.maxDuration) || 60,
    numClips: parseInt(data.numClips) || 5,
    startTime: data.startTime || '',
    manualClips: data.manualClips || [],
    segments: []
  };

  if (data.clipType === 'auto' || data.clipType === 'subtitles') {
    try {
      const captions = await fetchYouTubeSubtitles(data.videoId);
      options.segments = captions.segments || [];
    } catch (e) {}
  }

  return CorteAnalyzer.analyzeVideo(info, options);
}