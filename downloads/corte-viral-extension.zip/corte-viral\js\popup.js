/* ============================================
   AUTO CUT - Popup (100% cliente)
   Licença, análise local e gravação no seu PC
   ============================================ */

let videoInfo = null;
let analyzedClips = [];
let license = null;

document.addEventListener('DOMContentLoaded', async () => {
  setupEventListeners();
  await loadLicense();
  setTimeout(checkYouTube, 500);

  chrome.runtime.onMessage.addListener((request) => {
    if (request.type === 'PROGRESS_UPDATE' && request.data && request.data.phase) {
      updateProgress(request.data.percent, request.data.phase);
    }
  });
});

/* ============ LICENÇA VÍSION HUB ============ */
async function loadLicense() {
  const stored = await new Promise(resolve => {
    chrome.storage.local.get('vp_license', (result) => {
      if (result.vp_license) {
        try { resolve(JSON.parse(result.vp_license)); return; } catch (e) {}
      }
      resolve(null);
    });
  });

  if (stored) {
    document.getElementById('lic-instagram').value = stored.instagram || '';
    license = stored;
    if (stored.licensed) {
      const valid = stored.fromCache || stored.checkedAt && (Date.now() - new Date(stored.checkedAt).getTime() < 24 * 60 * 60 * 1000);
      if (valid) {
        if (hasStoredLicensed(stored)) setLicenseOk(stored);
        return;
      }
    }
  }
  setLicensePending();
}

function hasStoredLicensed(stored) {
  return stored.licensed === true;
}

function setLicenseOk(data) {
  license = { ...data, licensed: true };
  const statusEl = document.getElementById('license-status');
  statusEl.innerHTML = `✅ <strong>Licença ativa</strong> — ${data.status || ''} • ${data.daysLeft || '∞'} dia(s) restante(s)`;
  statusEl.className = 'license-status license-ok';
  statusEl.classList.remove('hidden');
  document.getElementById('lic-check-btn').disabled = true;
  updateButtonsEnable();
}

function setLicensePending() {
  const statusEl = document.getElementById('license-status');
  statusEl.className = 'license-status license-pending';
  statusEl.classList.remove('hidden');
  statusEl.textContent = '🔒 Aguardando validação da licença.';
  license = null;
  updateButtonsEnable();
}

function setLicenseError(message) {
  const statusEl = document.getElementById('license-status');
  statusEl.className = 'license-status license-err';
  statusEl.classList.remove('hidden');
  statusEl.textContent = '❌ ' + message;
  license = null;
  updateButtonsEnable();
}

async function handleCheckLicense() {
  const username = document.getElementById('lic-instagram').value.trim();
  if (!username) { setLicenseError('Informe seu @ do Instagram.'); return; }

  const btn = document.getElementById('lic-check-btn');
  btn.disabled = true;
  btn.textContent = 'Verificando...';
  showStatus('loading', '🔑 Validando licença no Vísion Hub...');

  try {
    const result = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'CHECK_LICENSE', data: { instagram: username } }, (res) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(res);
      });
    });

    if (result && result.licensed) {
      setLicenseOk(result);
      showStatus('success', '✅ Licença válida! Você pode usar o Auto Cut.');
    } else {
      setLicenseError(result?.message || 'Licença não encontrada para este @.');
      showStatus('error', '❌ ' + (result?.message || 'Licença inválida.'));
    }
  } catch (err) {
    setLicenseError('Não foi possível conectar ao Vísion Hub (' + err.message + ').');
    showStatus('error', '❌ Servidor offline. Inicie o backend na porta 3009.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Validar';
  }
}

function updateButtonsEnable() {
  const enabled = !!(license && license.licensed);
  const analyzeBtn = document.getElementById('analyze-btn');
  analyzeBtn.disabled = !enabled;
  const exportBtn = document.getElementById('export-btn');
  exportBtn.disabled = !enabled;
}

/* ============ EVENTOS ============ */
function setupEventListeners() {
  document.getElementById('lic-check-btn').addEventListener('click', handleCheckLicense);

  document.querySelectorAll('input[name="clipType"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      document.getElementById('manual-section').classList.toggle('hidden', e.target.value !== 'manual');
      document.getElementById('ai-section').classList.toggle('hidden', e.target.value === 'manual');
    });
  });

  document.querySelectorAll('input[name="subtitleMode"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const isCustom = e.target.value === 'custom';
      const isAny = e.target.value !== 'none';
      document.getElementById('custom-subtitle-section').classList.toggle('hidden', !isCustom);
      document.getElementById('subtitle-style-section').classList.toggle('hidden', !isAny);
    });
  });

  document.getElementById('add-clip-btn').addEventListener('click', addClipInput);
  document.getElementById('analyze-btn').addEventListener('click', handleAnalyze);
  document.getElementById('export-btn').addEventListener('click', handleExport);
  document.getElementById('set-current-time-btn').addEventListener('click', setCurrentTime);
  document.getElementById('add-more-btn').addEventListener('click', handleAddMore);
}

/* ============ STATUS / UTIL ============ */
function showStatus(type, message) {
  const bar = document.getElementById('status-bar');
  bar.className = `status-bar ${type}`;
  bar.classList.remove('hidden');
  document.getElementById('status-text').textContent = message;
}

function updateProgress(percent, text) {
  const progressEl = document.getElementById('progress');
  progressEl.classList.remove('hidden');
  document.getElementById('progress-fill').style.width = (percent || 0) + '%';
  document.getElementById('progress-text').textContent = text || 'Processando...';
}

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0]) { reject(new Error('Nenhuma aba ativa')); return; }
      chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
  });
}

/* ============ YOUTUBE ============ */
async function checkYouTube() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.url || !tab.url.includes('youtube.com/watch')) {
    document.getElementById('not-youtube').classList.remove('hidden');
    document.getElementById('main-content').classList.add('hidden');
    return;
  }

  document.getElementById('not-youtube').classList.add('hidden');
  document.getElementById('main-content').classList.remove('hidden');

  showStatus('loading', '🔍 Buscando informações do vídeo...');

  try {
    const response = await sendMessage({ type: 'GET_VIDEO_INFO' });
    if (!response) { showStatus('error', '❌ Não foi possível comunicar com a página. Recarregue o YouTube.'); return; }
    if (response.error) { showStatus('error', '❌ ' + response.error); return; }

    videoInfo = response;
    document.getElementById('video-title').textContent = videoInfo.title || 'Título não encontrado';
    document.getElementById('video-duration').textContent = `${videoInfo.channel || ''} • ${videoInfo.duration || ''}`;
    showStatus('success', '✅ Vídeo detectado! Clique em Analisar.');
  } catch (err) {
    showStatus('error', '❌ Recarregue a página do YouTube e tente novamente.');
  }
}

async function setCurrentTime() {
  try {
    const result = await sendMessage({ type: 'GET_CURRENT_TIME' });
    if (result && result.time !== null && result.time !== undefined) {
      document.getElementById('start-time').value = result.time;
      showStatus('success', `⏱️ Tempo definido: ${result.time}`);
    } else {
      showStatus('error', '❌ Dê play no vídeo primeiro.');
    }
  } catch (e) {
    showStatus('error', '❌ Não foi possível ler o tempo.');
  }
}

async function handleAddMore() {
  if (!videoInfo) { showStatus('error', '❌ Nenhum vídeo detectado.'); return; }
  const analyzeBtn = document.getElementById('analyze-btn');
  const addMoreBtn = document.getElementById('add-more-btn');
  if (analyzedClips.length > 0) {
    const lasts = analyzedClips.map(c => c.end).sort();
    const lastEnd = lasts[lasts.length - 1];
    document.getElementById('start-time').value = lastEnd;
    showStatus('loading', `⏱️ Gerando mais cortes a partir de ${lastEnd}... (anteriores mantidos)`);
  } else {
    showStatus('loading', '🤖 Gerando novos cortes...');
  }
  analyzeBtn.disabled = true;
  addMoreBtn.disabled = true;
  try {
    await handleAnalyze({ append: analyzedClips.length > 0 });
  } finally {
    analyzeBtn.disabled = false;
    addMoreBtn.disabled = false;
    updateButtonsEnable();
  }
}

function vpParseClipTime(str) {
  if (typeof str === 'number') return str;
  const parts = String(str || '').split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] || 0;
}

function mergeClips(existing, fresh) {
  // Anexa só cortes que NÃO sobrepõem os já listados (evita repetidos)
  const out = existing.slice();
  for (const c of fresh) {
    const s = vpParseClipTime(c.start);
    const e = vpParseClipTime(c.end);
    const dup = out.some(o => {
      const os = vpParseClipTime(o.start);
      const oe = vpParseClipTime(o.end);
      return s < oe - 5 && os < e - 5;
    });
    if (!dup) out.push(c);
  }
  // Renumera ids
  out.forEach((c, i) => { c.id = i + 1; });
  return out;
}

function addClipInput() {
  const list = document.getElementById('clips-list');
  const group = document.createElement('div');
  group.className = 'clip-input-group';
  group.innerHTML = `
    <input type="text" placeholder="Início (ex: 1:30)" class="clip-start">
    <input type="text" placeholder="Fim (ex: 2:15)" class="clip-end">
    <button class="clip-remove">×</button>
  `;
  group.querySelector('.clip-remove').addEventListener('click', () => group.remove());
  list.appendChild(group);
}

/* ============ ANÁLISE (LOCAL) ============ */
async function handleAnalyze(opts) {
  if (!videoInfo) { showStatus('error', '❌ Nenhum vídeo detectado. Recarregue o YouTube.'); return; }
  if (!license || !license.licensed) { showStatus('error', '❌ Valide sua licença primeiro.'); return; }

  const clipType = document.querySelector('input[name="clipType"]:checked').value;
  const analyzeBtn = document.getElementById('analyze-btn');
  analyzeBtn.disabled = true;
  document.getElementById('btn-text').classList.add('hidden');
  document.getElementById('btn-loading').classList.remove('hidden');

  const analysisData = {
    videoId: videoInfo.videoId,
    title: videoInfo.title,
    channel: videoInfo.channel,
    description: videoInfo.description,
    duration: videoInfo.duration,
    clipType
  };

  if (clipType === 'auto' || clipType === 'subtitles') {
    analysisData.style = document.getElementById('clip-style').value;
    analysisData.maxDuration = parseInt(document.getElementById('max-duration').value);
    analysisData.numClips = parseInt(document.getElementById('num-clips').value);
    const startTimeVal = document.getElementById('start-time').value.trim();
    if (startTimeVal) analysisData.startTime = startTimeVal;
  } else if (clipType === 'manual') {
    const clips = [];
    document.querySelectorAll('.clip-input-group').forEach(group => {
      const start = group.querySelector('.clip-start').value;
      const end = group.querySelector('.clip-end').value;
      if (start && end) clips.push({ start, end });
    });
    analysisData.manualClips = clips;
  }

  try {
    showStatus('loading', '🔍 Analisando vídeo localmente...');
    const response = await sendMessage({ type: 'ANALYZE_VIDEO', data: analysisData });

    if (!response) { showStatus('error', '❌ Falha ao analisar. Recarregue o YouTube.'); return; }
    if (response.error) { showStatus('error', '❌ ' + response.error); return; }

    const fresh = response.clips || [];
    if (fresh.length === 0 && !(opts && opts.append && analyzedClips.length > 0)) {
      showStatus('error', '❌ Nenhum corte identificado. Tente outro vídeo.');
      return;
    }
    if (opts && opts.append) {
      const before = analyzedClips.length;
      analyzedClips = mergeClips(analyzedClips, fresh);
      const added = analyzedClips.length - before;
      displayClips(analyzedClips);
      showStatus('success', added > 0 ? `✅ +${added} novos cortes! Total: ${analyzedClips.length}.` : 'ℹ️ Sem trechos novos após o último ponto (tente manual).');
    } else {
      analyzedClips = fresh;
      displayClips(analyzedClips);
      showStatus('success', `✅ ${analyzedClips.length} cortes identificados! (método: ${response.method || 'local'})`);
    }
  } catch (err) {
    showStatus('error', '❌ ' + err.message);
  } finally {
    analyzeBtn.disabled = false;
    document.getElementById('btn-text').classList.remove('hidden');
    document.getElementById('btn-loading').classList.add('hidden');
    updateButtonsEnable();
  }
}

function displayClips(clips) {
  const container = document.getElementById('clips-results');
  container.innerHTML = '';

  clips.forEach((clip, index) => {
    const card = document.createElement('div');
    card.className = 'clip-card selected';

    const scoreClass = clip.score >= 80 ? 'score-high' : clip.score >= 50 ? 'score-medium' : 'score-low';

    card.innerHTML = `
      <input type="checkbox" class="clip-card-checkbox" data-index="${index}" checked>
      <div class="clip-card-header">
        <span class="clip-card-title">Corte ${index + 1}</span>
        <span class="clip-card-time">${clip.start} → ${clip.end}</span>
      </div>
      <p class="clip-card-description">${clip.description || 'Sem descrição'}</p>
      ${clip.hashtags ? '<p class="clip-card-hashtags">' + clip.hashtags + '</p>' : ''}
      <span class="clip-card-score ${scoreClass}">Viral: ${clip.score || 0}%</span>
    `;

    card.querySelector('input').addEventListener('change', (e) => {
      card.classList.toggle('selected', e.target.checked);
    });

    container.appendChild(card);
  });

  document.getElementById('results').classList.remove('hidden');
}

/* ============ EXPORTAÇÃO (servidor ffmpeg) ============ */
async function handleExport() {
  const selectedClips = [];
  document.querySelectorAll('.clip-card-checkbox:checked').forEach(cb => {
    const index = parseInt(cb.dataset.index);
    selectedClips.push(analyzedClips[index]);
  });

  if (selectedClips.length === 0) { showStatus('error', '❌ Selecione pelo menos um corte'); return; }

  const formatValue = document.querySelector('input[name="outputFormat"]:checked').value;
  const formats = formatValue === 'all' ? ['tiktok', 'shorts'] : [formatValue];

  const subtitleMode = document.querySelector('input[name="subtitleMode"]:checked').value;
  const subtitleText = document.getElementById('subtitle-text').value;
  const subtitleSize = document.getElementById('subtitle-size').value;
  const subtitleColor = document.getElementById('subtitle-color').value;

  const destFolder = (document.getElementById('dest-folder').value || 'AutoCut').trim();
  const cropPos = (document.getElementById('crop-pos') || {}).value || 'center';

  let subtitle = { mode: subtitleMode, size: subtitleSize, color: subtitleColor };

  if (subtitleMode === 'auto') {
    showStatus('loading', '🔍 Buscando legendas do YouTube...');
    try {
      const subResult = await sendMessage({ type: 'FETCH_SUBTITLES', data: { videoId: videoInfo.videoId } });
      if (subResult && subResult.segments && subResult.segments.length > 0) {
        subtitle.segments = subResult.segments;
        subtitle.lang = subResult.lang;
        showStatus('loading', `📽️ Exportando com ${subResult.segments.length} legendas (${subResult.lang || 'auto'})...`);
      } else {
        subtitle.mode = 'none';
        showStatus('loading', '📽️ Sem legendas disponíveis — exportando sem legenda...');
      }
    } catch (e) {
      subtitle.mode = 'none';
      showStatus('loading', '📽️ Exportando sem legenda...');
    }
  } else if (subtitleMode === 'custom' && subtitleText) {
    subtitle.mode = 'custom';
    subtitle.text = subtitleText;
  }

  const exportBtn = document.getElementById('export-btn');
  exportBtn.disabled = true;
  updateProgress(1, 'Enviando para o servidor...');

  showStatus('warning', '⏳ Processando no servidor. Você pode fechar este painel — os cortes continuam e serão salvos na pasta escolhida.');

  try {
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        type: 'EXPORT_CLIPS',
        data: {
          videoId: videoInfo.videoId,
          videoTitle: videoInfo.title || '',
          videoUrl: videoInfo.videoUrl || '',
          clips: selectedClips,
          formats,
          subtitle,
          destFolder,
          cropPos
        }
      }, (res) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(res);
      });
    });

    if (!response || response.error) {
      showStatus('error', '❌ ' + (response?.error || 'Erro na exportação'));
      return;
    }

    const count = response.downloaded ? response.downloaded.filter(f => f.endsWith('.mp4')).length : 0;
    showStatus('success', `✅ ${count} corte(s) exportados! Salvos em: Downloads/${response.folder || destFolder}`);
    updateProgress(100, 'Concluído! Verifique a pasta Downloads/' + (response.folder || destFolder));
    setTimeout(() => document.getElementById('progress').classList.add('hidden'), 5000);
  } catch (err) {
    showStatus('error', '❌ ' + err.message);
  } finally {
    exportBtn.disabled = false;
    updateButtonsEnable();
  }
}