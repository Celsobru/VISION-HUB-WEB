/** 
 * Direitos Autorais (C) Growbot 2016-2023 - Todos os Direitos Reservados
 *
 * Cópia não autorizada deste arquivo, por qualquer meio, é estritamente proibida
 * Proprietário e confidencial
 * Escrito por Growbot <growbotautomator@gmail.com>, 2016-2023
 */
var iterationizations = 0;

function waitForSharedData() {
    iterationizations++;
    if (window._sharedData) {
        localStorage.setItem('winvars', JSON.stringify(window._sharedData));
        //console.log('iterações: ' + iterationizations);
    } else {
        setTimeout(waitForSharedData, 1);
    }

}

waitForSharedData();