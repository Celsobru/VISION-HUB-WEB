
// ============ VISION PLUS - URL DA API DE LICENÇA ============
// Em produção, altere para o domínio real do site
var VP_API_URL = 'https://visionhubweb.com.br/api';

// ============ VERIFICAÇÃO DE LICENÇA VISION PLUS ============
async function checkVisionPlusLicense(instagram) {
    if (!instagram) return { licensed: false, status: 'no_username', message: 'Usuário não detectado.' };

    var igUsername = instagram.replace('@', '').trim().toLowerCase();

    try {
        var response = await fetch(VP_API_URL + '/license/check?instagram=' + encodeURIComponent(igUsername) + '&product=instabot');
        var data = await response.json();

        // Salvar resultado no storage local
        chrome.storage.local.set({
            'vp_license': JSON.stringify({
                licensed: data.licensed,
                status: data.status,
                message: data.message,
                daysLeft: data.daysLeft || 0,
                expiresAt: data.expiresAt || null,
                siteUrl: data.siteUrl || null,
                checkedAt: new Date().toISOString(),
                instagram: igUsername
            })
        });

        return data;
    } catch (err) {
        // Se o servidor estiver offline, verificar cache local
        return new Promise(function(resolve) {
            chrome.storage.local.get('vp_license', function(result) {
                if (result.vp_license) {
                    var cached = JSON.parse(result.vp_license);
                    // Usar cache se foi verificado há menos de 48h
                    var cachedTime = new Date(cached.checkedAt).getTime();
                    if (Date.now() - cachedTime < 48 * 60 * 60 * 1000) {
                        cached.fromCache = true;
                        resolve(cached);
                        return;
                    }
                }
                // Se não tem cache ou expirou, BLOQUEAR uso (servidor offline = sem licença)
                resolve({ licensed: false, status: 'offline', message: 'Não foi possível verificar sua licença. Verifique sua conexão.', fromCache: false });
            });
        });
    }
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {


    if (request.follow) {

        var u = request.follow;

        chrome.tabs.create({
            url: "https://www.instagram.com/" + u.username
        }, function(tab) {
            var tabId = tab.id;
            chrome.tabs.onUpdated.addListener(function(tabId, info) {
                if (info.status === 'complete') {

                    setTimeout(function() {
                        chrome.tabs.sendMessage(tab.id, {
                            hideGrowbot: true
                        });

                        chrome.tabs.sendMessage(tab.id, {
                            clickSomething: 'button div[dir="auto"]:contains("Follow")'
                        });
                    }, 3000);

                    setTimeout(function() {
                        chrome.tabs.remove(tab.id);
                    }, 20000);
                }
            });
        });
    }


    if (request.openReelTab) {

        var shortcode = request.openReelTab.code || request.openReelTab.shortcode;

        chrome.tabs.create({
            url: "https://www.instagram.com/p/" + shortcode
        }, function(tab) {


            var tabId = tab.id;

            chrome.tabs.onUpdated.addListener(function(tabId, info) {
                if (info.status === 'complete') {
                    chrome.tabs.sendMessage(tabId, {
                        hideGrowbot: true
                    });

                    setTimeout(function() {
                        chrome.tabs.sendMessage(tabId, {
                            hideGrowbot: true
                        });
                    }, 3000);


                    if (request.openReelTab.LikeWhenWatchingReel == true) {
                        setTimeout(function() {
                            // clicar em Curtir
                            chrome.tabs.sendMessage(tabId, {
                                clickSomething: 'svg[aria-label="Like"][width="24"]',
                                parent: 'div[role="button"]'

                            });
                        }, (((request.openReelTab.video_duration || 20) * 750)));
                    }


                    if (request.openReelTab.SaveWhenWatchingReel == true) {
                        setTimeout(function() {
                            // clicar em Salvar
                            chrome.tabs.sendMessage(tabId, {
                                clickSomething: 'svg[aria-label="Save"]',
                                parent: 'div[role="button"]'
                            });
                        }, (((request.openReelTab.video_duration || 20) * 750) + 2000));
                    }


                    setTimeout(function() {
                        chrome.tabs.remove(tab.id);
                    }, (((request.openReelTab.video_duration || 20) * 1000) + 1000));
                }
            });



        });

    }

    if (request.updatewanted && request.updatewanted == true) {
        gblIgBotUser.init();
    }

    if (request.guidCookie) {
        // Sincronização de GUID com servidor removida
    }

    if (request.ftOver == "true") {
        // Verificação de fim de trial removida
    }

    // ============ CLIQUE REAL DO NAVEGADOR (fallback quando o site ignora clique sintético) ============
    if (request.vpDebugClick) {
        (async function () {
            var tabId = sender && sender.tab && sender.tab.id;
            var x = Math.round((request.vpDebugClick && request.vpDebugClick.x) || 0);
            var y = Math.round((request.vpDebugClick && request.vpDebugClick.y) || 0);
            if (!tabId) { try { sendResponse({ success: false, error: 'sem aba' }); } catch (e) {} return; }
            try {
                await chrome.debugger.attach({ tabId: tabId }, '1.3');
                await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: x, y: y });
                await new Promise(function (r) { setTimeout(r, 200); });
                await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: x, y: y, button: 'left', clickCount: 1 });
                await new Promise(function (r) { setTimeout(r, 150); });
                await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: x, y: y, button: 'left', clickCount: 1 });
                try { sendResponse({ success: true }); } catch (e) {}
            } catch (e) {
                try { sendResponse({ success: false, error: String((e && e.message) || e) }); } catch (e2) {}
            } finally {
                try { await chrome.debugger.detach({ tabId: tabId }); } catch (e) {}
            }
        })();
        return true; // mantém o canal aberto para resposta assíncrona
    }

    // ============ CLIQUE REAL INTELIGENTE (hover, recoordenadas, clique) ============
    if (request.vpSmartClick) {
        (async function () {
            var tabId = sender && sender.tab && sender.tab.id;
            if (!tabId) { try { sendResponse({ success: false, error: 'sem aba' }); } catch (e) {} return; }
            var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
            var lastErr = null;
            // 2 tentativas: o attach pode cair se a página navegar no meio do fluxo
            for (var attemptN = 0; attemptN < 2; attemptN++) {
                try {
                    try { await chrome.debugger.detach({ tabId: tabId }); } catch (e) {}
                    await chrome.debugger.attach({ tabId: tabId }, '1.3');
                    var initX = Math.round((request.vpSmartClick && request.vpSmartClick.x) || 0);
                    var initY = Math.round((request.vpSmartClick && request.vpSmartClick.y) || 0);
                    // 1. Move até o botão (menu lateral pode expandir no hover)
                    await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: initX, y: initY });
                    await sleep(900); // aguarda animação do menu assentar
                    // 2. Pede coordenadas FRESCAS ao content script (pós-hover)
                    var fresh = await chrome.tabs.sendMessage(tabId, { vpGetCreateCoords: true });
                    var fx = (fresh && fresh.success) ? fresh.x : initX;
                    var fy = (fresh && fresh.success) ? fresh.y : initY;
                    var ftag = (fresh && fresh.tag ? fresh.tag + ' ' + fresh.w + 'x' + fresh.h : 'mesmas');
                    // 3. Move para o ponto final e clica
                    await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: fx, y: fy });
                    await sleep(250);
                    await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: fx, y: fy, button: 'left', clickCount: 1 });
                    await sleep(150);
                    await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: fx, y: fy, button: 'left', clickCount: 1 });
                    try { sendResponse({ success: true, x: fx, y: fy, tag: ftag }); } catch (e) {}
                    lastErr = null;
                    break;
                } catch (e) {
                    lastErr = e;
                    try { await chrome.debugger.detach({ tabId: tabId }); } catch (e2) {}
                    await sleep(500);
                }
            }
            if (lastErr) {
                try { sendResponse({ success: false, error: String((lastErr && lastErr.message) || lastErr) }); } catch (e2) {}
            }
            try { await chrome.debugger.detach({ tabId: tabId }); } catch (e) {}
        })();
        return true;
    }

    // ============ TECLA REAL DO NAVEGADOR (Enter no botão focado) ============
    if (request.vpDebugKey) {
        (async function () {
            var tabId = sender && sender.tab && sender.tab.id;
            var key = (request.vpDebugKey && request.vpDebugKey.key) || 'Enter';
            if (!tabId) { try { sendResponse({ success: false, error: 'sem aba' }); } catch (e) {} return; }
            try {
                await chrome.debugger.attach({ tabId: tabId }, '1.3');
                await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchKeyEvent', { type: 'keyDown', key: key, code: key, windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
                await new Promise(function (r) { setTimeout(r, 120); });
                await chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchKeyEvent', { type: 'keyUp', key: key, code: key, windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
                try { sendResponse({ success: true }); } catch (e) {}
            } catch (e) {
                try { sendResponse({ success: false, error: String((e && e.message) || e) }); } catch (e2) {}
            } finally {
                try { await chrome.debugger.detach({ tabId: tabId }); } catch (e) {}
            }
        })();
        return true;
    }

    // ============ VERIFICAÇÃO DE LICENÇA (chamado pelo contentscript) ============
    if (request.checkLicense) {
        checkVisionPlusLicense(request.checkLicense).then(function(result) {
            // Enviar resultado para TODAS as abas do Instagram
            chrome.tabs.query({ url: ["https://www.instagram.com/*"] }, function(tabs) {
                for (var i = 0; i < tabs.length; i++) {
                    chrome.tabs.sendMessage(tabs[i].id, {
                        licenseResult: result
                    }, function() { if (chrome.runtime.lastError) { /* ignorar */ } });
                }
            });
        });
    }


    if (request.ig_user) {
        gblIgBotUser.ig_users.push(request.ig_user);
        gblIgBotUser.ig_users = uniq(gblIgBotUser.ig_users);
        gblIgBotUser.current_ig_username = request.ig_user.username;

        if (request.ig_user_account_stats) {
            gblIgBotUser.account_growth_stats.push(request.ig_user_account_stats);
            gblIgBotUser.account_growth_stats = uniq(gblIgBotUser.account_growth_stats);
        }

        gblIgBotUser.saveToLocal();

        // Verificar licença automaticamente quando o usuário do IG é detectado
        checkVisionPlusLicense(request.ig_user.username).then(function(result) {
            if (sender.tab) {
                chrome.tabs.sendMessage(sender.tab.id, {
                    licenseResult: result
                }, function() { if (chrome.runtime.lastError) { /* ignorar */ } });
            }
        });
    }

    if (request.fnc == 'openBuyScreen') {
        // Tela de compra removida — servidor antigo não está mais disponível
    }

    if (request.fetchAiSettings) {
        var username = request.fetchAiSettings;
        var igUsername = username.replace('@', '').trim().toLowerCase();
        fetch(VP_API_URL + '/license/ai-settings?instagram=' + encodeURIComponent(igUsername))
            .then(function(response) { return response.json(); })
            .then(function(settings) {
                sendResponse({ success: true, settings: settings });
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true; // Keep message channel open for async response
    }

    if (request.generateAiContent) {
        var params = request.generateAiContent;
        var url = VP_API_URL + '/ai/generate?niche_mode=' + encodeURIComponent(params.niche_mode || 'manual') +
                  '&niche=' + encodeURIComponent(params.niche || '') +
                  '&instructions=' + encodeURIComponent(params.instructions || '');
        fetch(url)
            .then(function(response) { return response.json(); })
            .then(function(content) {
                sendResponse({ success: true, content: content });
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true; // Keep message channel open for async response
    }

    // ============ FILA DE POSTS (pasta local no servidor, por cliente) ============
    if (request.postQueueNext) {
        var igNext = request.postQueueInstagram || '';
        var kindNext = request.postQueueKind || '';
        fetch(VP_API_URL + '/post-queue/next?instagram=' + encodeURIComponent(igNext) + '&kind=' + encodeURIComponent(kindNext))
            .then(function(response) { return response.json(); })
            .then(function(data) {
                sendResponse(data);
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true;
    }

    if (request.postQueueDone) {
        fetch(VP_API_URL + '/post-queue/done', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: request.postQueueDone, instagram: request.postQueueInstagram || '' })
        })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                sendResponse(data);
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true;
    }

    if (request.postQueueStatus) {
        fetch(VP_API_URL + '/post-queue/status?instagram=' + encodeURIComponent(request.postQueueStatus || ''))
            .then(function(response) { return response.json(); })
            .then(function(data) {
                sendResponse(data);
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true;
    }

    if (request.postQueueUpload) {
        fetch(VP_API_URL + '/post-queue/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request.postQueueUpload)
        })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                sendResponse(data);
            })
            .catch(function(error) {
                sendResponse({ success: false, error: error.message });
            });
        return true;
    }

    // ============ CLIQUE REAL (trusted) VIA DEBUGGER ============
    // O Instagram ignora cliques sintéticos (isTrusted=false) no botão + Criar.
    // O debugger gera input de mouse real. Anexa, clica, desanexa (~1s, banner pisca).
    if (request.vpTrustedClick && sender && sender.tab) {
        (function (tabId, x, y) {
            var version = '1.3';
            function sendOk() { try { sendResponse({ success: true }); } catch (e) {} }
            function sendFail(msg) { try { sendResponse({ success: false, error: msg }); } catch (e) {} }
            try {
                chrome.debugger.attach({ tabId: tabId }, version, function () {
                    if (chrome.runtime.lastError) { sendFail(chrome.runtime.lastError.message); return; }
                    chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent',
                        { type: 'mousePressed', x: x, y: y, button: 'left', clickCount: 1 }, function () {
                        if (chrome.runtime.lastError) {
                            chrome.debugger.detach({ tabId: tabId }, function () {});
                            sendFail(chrome.runtime.lastError.message); return;
                        }
                        chrome.debugger.sendCommand({ tabId: tabId }, 'Input.dispatchMouseEvent',
                            { type: 'mouseReleased', x: x, y: y, button: 'left', clickCount: 1 }, function () {
                            chrome.debugger.detach({ tabId: tabId }, function () {});
                            if (chrome.runtime.lastError) { sendFail(chrome.runtime.lastError.message); return; }
                            sendOk();
                        });
                    });
                });
            } catch (e) { sendFail(String((e && e.message) || e)); }
        })(sender.tab.id, Math.round(request.vpTrustedClick.x || 0), Math.round(request.vpTrustedClick.y || 0));
        return true;
    }

    sendResponse();

});

var gblIgBotUser = {
    user_guid: undefined,
    
    
    ig_users: [],
    licenses: {},
    actions: [{
        date: '',
        action: ''
    }],
    account_growth_stats: [],
    options: {},
    //      listaPermitidos: [],
    //      filasSalvas: [{ name: 'q1',date:datetime,queue:[]},{ name: 'q1',date:datetime,queue:[]}]
    init: async function() {

        runWinVarsScript();

        this.user_guid = await this.getPref('growbot_user_guid');

        if (!this.user_guid || this.user_guid == false) {
            this.user_guid = this.uuidGenerator();
            this.setPref('growbot_user_guid', this.user_guid);
        }

       
    },
    
    overrideFT: function() {
        // Função desativada — verificação de trial removida
    },
    uuidGenerator: function() {
        var S4 = function() {
            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    },
    getPref: async function(name) {
        return new Promise(function(resolve) {
            chrome.storage.local.get(name, function(value) {
                if (Object.keys(value).length > 0) {
                    resolve(value[name]);
                } else {
                    resolve(false);
                }
            });
        });
    },
    setPref: async function(name, value) {
        chrome.storage.local.set({
            [name]: value
        }, function() {});
    },
    saveToLocal: function() {
        chrome.storage.local.set({
            'igBotUser': JSON.stringify(gblIgBotUser)
        }, function() {});
    },
  
                }
            
        
    



var instabot_free_trial_time = '2024-08-31'; // 129600000 = 36 horas, 259200000 = 72 horas, 604800000=7 dias, 1296000000 = 14 dias, 2592000000 = 30 dias
var first_run = false;
var todaysdate = new Date();
var today = todaysdate.getTime();
var timeSinceInstall;

chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.query({
        url: ["https://www.instagram.com/", "https://www.instagram.com/*"]
    }, tabs => {
        if (chrome.runtime.lastError) {
            return;
        }
        if (!tabs || tabs.length === 0) {
            chrome.tabs.create({
                url: 'https://www.instagram.com/'
            }, function(tab) {
                // Aguarda o content script carregar antes de enviar mensagem
                setTimeout(function() {
                    chrome.tabs.sendMessage(tab.id, {
                        "openGrowbot": true,
                        igBotUser: gblIgBotUser
                    }, function() { if (chrome.runtime.lastError) { /* ignorar */ } });
                }, 2000);
            });
        } else {
            var toggled = false;
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].active === true) {
                    toggled = true;
                    chrome.tabs.sendMessage(tabs[i].id, {
                        "toggleGrowbot": true,
                        igBotUser: gblIgBotUser
                    }, function() { if (chrome.runtime.lastError) { /* ignorar */ } });
                }
            }
            if (toggled === false) {
                chrome.tabs.update(tabs[0].id, {
                    active: true
                });
                chrome.tabs.sendMessage(tabs[0].id, {
                    "openGrowbot": true,
                    igBotUser: gblIgBotUser
                }, function() { if (chrome.runtime.lastError) { /* ignorar */ } });
            }
        }
    });
});


chrome.runtime.onInstalled.addListener(installedOrUpdated);

function installedOrUpdated() {
    gblIgBotUser.init();

    chrome.tabs.create({
        url: "https://www.instagram.com"
    }, function(tab) {

       

    });
}

function runWinVarsScript() {
    chrome.tabs.query({
        url: ["https://www.instagram.com/*", "https://www.instagram.com/"]
    }, tabs => {
        for (var i = 0; i < tabs.length; i++) {
            var igTabId = tabs[i].id;
            chrome.scripting.executeScript({
                    target: {
                        tabId: igTabId
                    },
                    files: ['winvars.js'],
                    world: 'MAIN'
                },
                function() {});
        }
    });
}







function uniq(ar) {
    return Array.from(new Set(ar.map(JSON.stringify))).map(JSON.parse);
}
