
try { console.log('VP content build: 2.4.3-guiado-fix42-20260917'); } catch (e) {}
var guidCookie = localStorage['gbUserGuid'];
var urlAcctInfo2 = 'https://www.instagram.com/';
var urlAcctInfo = 'https://i.instagram.com/api/v1/users/web_profile_info/?username=';
var urlAcctInfo3 = 'https://i.instagram.com/api/v1/users/${userid}/info/'; //possui email_público

/*

SALVAR NOME DE USUÁRIO E IP NOS METADADOS AO CARREGAR ASSINATURA

Estados de hover dos botões

- FILTROS
    connected_fb_page
    has_channel
    business_category_name
    highlight_reel_count
    data do último post** - tratar contas privadas
    data do primeiro post**
    média de posts por dia?

- opção para bloquear eventos do cliente

1) curtir automaticamente quando pessoas comentarem suas imagens
2) responder automaticamente a comentários (não tenho certeza se isso é um recurso essencial).

criar tour
tour em vídeo?  ttsreader.com

Adicionar Google Analytics

deseguir automático
agendar desseguimento
    - mensagens da página em segundo plano

barras de progresso!
https://loading.io/progress/
https://kimmobrunfeldt.github.io/progressbar.js/

<meter
  min="0"
  max="100"
  low="25"
  high="75"
  optimum="80"
  value="50"
></meter>


6) Seria possível integrar um sistema de filtragem baseado em localização? Por exemplo, colar coordenadas do Google + raio

botão para limpar já tentados ou carregar como fila

Fazer "Descurtir" rápido ou garantir que mostre info do usuário para cada foto.

Alguma forma de randomizar as curtidas nos posts
Meu palpite é que o IG detectaria você curtindo 1 post em cada seguimento.
Seria bom se pudesse randomizar curtidas e randomizar frequência nessa opção.
Por exemplo a cada 3 a 10 (Aleatório) seguimentos curtir (1-5 posts) Aleatório.

https://stackoverflow.com/questions/16758316/where-do-i-find-the-instagram-media-id-of-a-image

*/


var gblActionsQueue = [];

function prettyDate(dataString) {

    if (dataString == false) return '-';

    var d = new Date(dataString);
    //var parteDaData = d.toISOString().slice(0, 10);

    var year = d.getFullYear();
    var month = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');

    var datePart = year + '-' + month + '-' + day;

    // var timePart = d.toLocaleString([], {
    //     hour: '2-digit',
    //     minute: '2-digit'
    // });


    var timePart = d.getHours() + ':' + d.getMinutes();

    dataString = datePart + ' ' + timePart;
    return dataString;
}

function loadActionsQueue() {
    chrome.storage.local.get("gblActionsQueue", function (data) {
        if (typeof data.gblActionsQueue != 'undefined') {
            gblActionsQueue = data.gblActionsQueue;

            $('#tblScheduledActions').hide();
            $('#tblScheduledActions tbody').html('');


            for (var i = 0; i < gblActionsQueue.length; i++) {

                var tr = '<tr>';
                tr = tr + '<td>' + i + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].functionAlias + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].scheduledTime.replace('T', ' ') + '</td>';
                tr = tr + '<td>' + prettyDate(gblActionsQueue[i].ranAt) + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].repeatDaily + '</td>';
                tr = tr + '<td style="text-align: center;"><span class="minus-sign" data-scheduled-action="' + i + '">&minus;</span></td>';
                tr = tr + '</tr>';

                $('#tblScheduledActions tbody').append(tr);
                $('#tblScheduledActions').show();

            }


        }
    });
}

$(document).off('click.vpDelSched').on('click.vpDelSched', '#tblScheduledActions .minus-sign', function () {
    var pos = parseInt($(this).attr('data-scheduled-action'), 10);
    if (isNaN(pos) || pos < 0 || pos >= gblActionsQueue.length) {
        setTimeout(loadActionsQueue, 100);
        return false;
    }
    var removed = gblActionsQueue.splice(pos, 1);
    saveActionsQueue();
    setTimeout(loadActionsQueue, 100);
    if (removed && removed[0]) {
        outputMessage('Agendamento excluído: ' + (removed[0].functionAlias || ('#' + pos)));
    }
    return false;
});

function vpClearScheduledActions(doneOnly) {
    if (!gblActionsQueue || gblActionsQueue.length === 0) {
        outputMessage('Nenhum agendamento para excluir.');
        return false;
    }
    var removed = 0;
    if (doneOnly) {
        var nowTime = new Date().getTime();
        gblActionsQueue = gblActionsQueue.filter(function (a) {
            var done = a && a.ranAt && a.ranAt !== false && new Date(a.scheduledTime).getTime() < nowTime && a.repeatDaily !== true;
            if (done) removed++;
            return !done;
        });
    } else {
        removed = gblActionsQueue.length;
        gblActionsQueue = [];
    }
    saveActionsQueue();
    setTimeout(loadActionsQueue, 100);
    outputMessage(removed + ' agendamento(s) excluído(s).');
}


function snapToActiveWindow(timestamp, startHour, endHour) {
    var d = new Date(timestamp);
    var hour = d.getHours();
    var minutes = d.getMinutes();
    var currentTimeInHours = hour + minutes / 60;

    if (currentTimeInHours >= endHour) {
        d.setDate(d.getDate() + 1);
        d.setHours(Math.floor(startHour), Math.round((startHour % 1) * 60), 0, 0);
        return d.getTime();
    } else if (currentTimeInHours < startHour) {
        d.setHours(Math.floor(startHour), Math.round((startHour % 1) * 60), 0, 0);
        return d.getTime();
    }

    return timestamp;
}

function generateScheduledTimes(config, numActions, existingCountsPerDay) {
    var actionsPerDay = config.actionsPerDay;
    var startHour = config.startHour;
    var endHour = config.endHour;
    var minDelayMs = config.minDelayMs;
    var startAfterExisting = config.startAfterExisting;
    var maxScheduledTime = config.maxScheduledTime;
    var scheduleEvenly = config.scheduleEvenly;
    existingCountsPerDay = existingCountsPerDay || {};
    var useEvenWindow = scheduleEvenly !== false;

    var cursor;
    if (config.scheduleStartMs != null && isFinite(config.scheduleStartMs) && config.scheduleStartMs > 0) {
        cursor = config.scheduleStartMs;
    } else if (startAfterExisting && maxScheduledTime) {
        cursor = maxScheduledTime + minDelayMs;
    } else {
        cursor = Date.now() + 1000;
    }

    cursor = snapToActiveWindow(cursor, startHour, endHour);
    cursor = Math.max(cursor, Date.now());

    var windowHours = endHour > startHour ? endHour - startHour : (24 - startHour + endHour);
    var windowMs = windowHours * 3600000;

    var evenSpacing = Math.floor(windowMs / actionsPerDay);
    var configuredBaseMs = (typeof gblOptions !== 'undefined' && gblOptions.timeDelay != null)
        ? gblOptions.timeDelay
        : 180000;
    var effectiveDelay = Math.max(minDelayMs, evenSpacing, configuredBaseMs);

    var newCountsPerDay = {};

    var timestamps = [];
    for (var i = 0; i < numActions; i++) {
        var dayKey = new Date(cursor).toISOString().slice(0, 10);
        var existingCount = existingCountsPerDay[dayKey] || 0;
        var newCount = newCountsPerDay[dayKey] || 0;

        while (existingCount + newCount >= actionsPerDay) {
            var d = new Date(cursor);
            d.setDate(d.getDate() + 1);
            d.setHours(Math.floor(startHour), Math.round((startHour % 1) * 60), 0, 0);
            cursor = d.getTime();
            dayKey = new Date(cursor).toISOString().slice(0, 10);
            existingCount = existingCountsPerDay[dayKey] || 0;
            newCount = newCountsPerDay[dayKey] || 0;
        }

        cursor = Math.max(cursor, Date.now());
        timestamps.push(cursor);
        newCountsPerDay[dayKey] = (newCountsPerDay[dayKey] || 0) + 1;

        var randomizedDelay = getRandomizedTime(effectiveDelay);
        cursor += Math.round(randomizedDelay);

        cursor = snapToActiveWindow(cursor, startHour, endHour);
    }

    return timestamps;
}

function growbotActionRunner() {

    var nowTime = new Date().getTime();
    var nowDate = new Date().getDate();
    var yesterday = new Date(new Date().getTime() - (24 * 59 * 60 * 1000));
    var oneMinuteAgo = new Date(Date.now() - 1000 * 60);

    $('#currentTime').html('Current Time: ' + prettyDate(nowTime));

    for (var i = 0; i < gblActionsQueue.length; i++) {


        if (gblActionsQueue[i].enabled == true) {

            var shouldRunNow = false;
            var ranToday = true;
            var scheduledTime = new Date(gblActionsQueue[i].scheduledTime).getTime();
            var scheduledDate = new Date(gblActionsQueue[i].scheduledTime).getDate();


            // ajustar o horário agendado para hoje se a data agendada já passou e é uma repetição diária
            if (scheduledDate < nowDate && gblActionsQueue[i].repeatDaily == true) {
                var daysAgo = nowDate - scheduledDate;
                scheduledTime = new Date(scheduledTime + (daysAgo * 86400000));
            }

            if (gblActionsQueue[i].ranAt < yesterday && gblActionsQueue[i].repeatDaily == true) {
                // executou, mas foi há mais de 24 horas atrás
                ranToday = false;
            }

            if (gblActionsQueue[i].ranAt == false) {
                // nunca executou
                ranToday = false;
            }

            // o horário agendado já passou
            if (scheduledTime < nowTime && ranToday == false) {
                shouldRunNow = true;
            }

            // está obsoleto, o growbot não estava rodando quando chegou a hora
            if (scheduledTime < oneMinuteAgo) {
                shouldRunNow = false;
            }


            if (shouldRunNow == true) {

                window[gblActionsQueue[i].functionName](gblActionsQueue[i].args, i);
                gblActionsQueue[i].ranAt = nowTime;

                saveActionsQueue();
                setTimeout(loadActionsQueue, 100);
            }

        }
    }



}

function saveActionsQueue() {
    chrome.storage.local.set({
        gblActionsQueue: gblActionsQueue
    });
}

function btnAddScheduledAction() {

    // contaAlvo
    // mídiaAlvo
    // endpoint da api
    // método da api
    // próximaFunção / callback

    // em caso de falha atrasar todas as ações?


    // - código de status do resultado
    // - depende de outra ação?

    var yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).getTime();


    var action = {
        functionName: $('#scheduled_action_function_name').val(),
        functionAlias: $('#scheduled_action_function_name option:selected').text(),
        scheduledTime: $('#scheduled_action_scheduled_time').val(),
        ranAt: false,
        repeatDaily: $('#scheduled_action_repeat')[0].checked,
        enabled: true
    }


    gblActionsQueue.push(action);

    saveActionsQueue();

    setTimeout(loadActionsQueue, 100);
}

function vpParseHourToFloat(val, fallback) {
    if (!val) return fallback;
    var parts = String(val).split(':');
    var h = parseInt(parts[0], 10);
    var m = parts.length > 1 ? parseInt(parts[1], 10) : 0;
    if (isNaN(h) || isNaN(m)) return fallback;
    return h + (m / 60);
}

function vpScheduleQueueDistributed() {
    if (!vpLicenseGuard()) return false;

    if (!acctsQueue || acctsQueue.length === 0) {
        outputMessage('Fila de contas vazia. Carregue seguidores/seguindo/curtidores primeiro.');
        return false;
    }

    var action = $('#vp_dist_action').val() || 'follow';
    var perDay = parseInt($('#vp_dist_per_day').val(), 10) || 50;
    if (perDay < 1) perDay = 1;
    if (perDay > 500) perDay = 500;
    var startHour = vpParseHourToFloat($('#vp_dist_start').val(), 8);
    var endHour = vpParseHourToFloat($('#vp_dist_end').val(), 22);
    var startAtVal = $('#vp_dist_start_at').val();
    var startMs = startAtVal ? new Date(startAtVal).getTime() : Date.now();
    if (!isFinite(startMs) || startMs < Date.now() - 60000) startMs = Date.now();

    var targets = acctsQueue.slice(0, 200).map(function (a) {
        return { id: a.id, username: a.username };
    }).filter(function (t) { return t.id && t.username; });

    if (targets.length === 0) {
        outputMessage('Nenhum alvo válido na fila (faltando id/username).');
        return false;
    }

    var timestamps = generateScheduledTimes({
        actionsPerDay: perDay,
        startHour: startHour,
        endHour: endHour,
        minDelayMs: 60000,
        scheduleStartMs: startMs,
        scheduleEvenly: true
    }, targets.length, {});

    var actionLabel = action === 'follow' ? 'Seguir' : (action === 'unfollow' ? 'Deixar de seguir' : (action === 'follow_like1' ? 'Seguir+curtir' : 'Ver reels'));
    for (var i = 0; i < targets.length; i++) {
        var d = new Date(timestamps[i]);
        var iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + 'T' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
        gblActionsQueue.push({
            functionName: 'vpRunOneScheduledQueueTarget',
            functionAlias: 'Fila: ' + actionLabel + ' @' + targets[i].username,
            scheduledTime: iso,
            ranAt: false,
            repeatDaily: false,
            enabled: true,
            args: { action: action, id: String(targets[i].id), username: targets[i].username }
        });
    }

    saveActionsQueue();
    setTimeout(loadActionsQueue, 100);
    var lastDay = new Date(timestamps[timestamps.length - 1]).toLocaleString();
    outputMessage(targets.length + ' ações de "' + actionLabel + '" distribuídas até ' + lastDay + '. Sobrevivem a refresh do navegador.');
}

function vpRunOneScheduledQueueTarget(args, idx) {
    if (!vpLicenseGuard()) return false;

    args = args || {};
    if (!args.id || !args.username) {
        outputMessage('Ação agendada sem alvo, ignorando.');
        return false;
    }

    var isFollow = args.action === 'follow' || args.action === 'follow_like1';
    var isUnfollow = args.action === 'unfollow';
    if (!isFollow && !isUnfollow && args.action !== 'watch_reels') {
        outputMessage('Ação agendada desconhecida: ' + args.action);
        return false;
    }

    if (args.action === 'watch_reels') {
        vpWatchReelsOfAcct({ id: args.id, username: args.username });
        return true;
    }

    var url = isFollow
        ? 'https://www.instagram.com/api/v1/friendships/create/' + args.id + '/'
        : 'https://www.instagram.com/api/v1/friendships/destroy/' + args.id + '/';
    var verb = isFollow ? 'Seguido' : 'Deixado de seguir';

    $.ajax({
        url: url,
        method: 'POST',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (r) {
            if (r && (r.status === 'fail' || (r.spam === true))) {
                vpRescheduleOneTarget(idx, args, 'bloqueio do Instagram (' + (r.message || 'fail') + ')');
                return;
            }
            addStamp(args.id, 'stamp-div-green', isFollow ? 'followed' : 'unfollowed');
            outputMessage(verb + ' @' + args.username + ' (agendado)');
            try { actionsTaken++; } catch (e) {}
            if (args.action === 'follow_like1') {
                vpQueueOneMediaLike({ id: args.id, username: args.username });
            }
        })
        .fail(function (data) {
            var status = data ? data.status : 0;
            if (status == 429 || status == 403 || status == 400) {
                vpRescheduleOneTarget(idx, args, 'HTTP ' + status);
            } else {
                outputMessage('Falha em @' + args.username + ' (HTTP ' + status + '), mantendo como executado para não travar a fila.');
            }
        });
}

function vpRescheduleOneTarget(idx, args, reason) {
    try {
        if (typeof idx === 'number' && gblActionsQueue[idx] && gblActionsQueue[idx].args &&
            String(gblActionsQueue[idx].args.id) === String(args.id)) {
            var newTime = new Date(Date.now() + 60 * 60 * 1000);
            var iso = newTime.getFullYear() + '-' + String(newTime.getMonth() + 1).padStart(2, '0') + '-' + String(newTime.getDate()).padStart(2, '0') + 'T' + String(newTime.getHours()).padStart(2, '0') + ':' + String(newTime.getMinutes()).padStart(2, '0');
            gblActionsQueue[idx].scheduledTime = iso;
            gblActionsQueue[idx].ranAt = false;
            saveActionsQueue();
            setTimeout(loadActionsQueue, 100);
            outputMessage('@' + args.username + ': restrição detectada (' + reason + '), reagendado +60min como na 2.9.5.');
            return;
        }
    } catch (e) {}
    outputMessage('@' + args.username + ': restrição detectada (' + reason + ').');
}

function vpQueueOneMediaLike(acct) {
    if (!vpLicenseGuard()) return false;
    ajaxLoadUsersMedia('', false, function (r) {
        try {
            if (!r || !r.edges || r.edges.length === 0) {
                outputMessage('Sem posts para curtir em @' + acct.username);
                return;
            }
            var pieceOfMedia = r.edges[0].node;
            pieceOfMedia.owner = r.acct || { username: acct.username };
            mediaToLike.push(pieceOfMedia);
            arrayOfMediaToDiv(mediaToLike, true);
            outputMessage('1 post de @' + acct.username + ' na fila de curtidas (agendado)');
            if (alreadyLiking == false) {
                likeAllMedia();
            }
        } catch (e) {
            outputMessage('Falha ao enfileirar curtida de @' + acct.username);
        }
    }, acct);
}

async function vpWatchReelsOfAcct(acct) {
    if (!vpLicenseGuard()) return false;
    outputMessage('Carregando reels de @' + acct.username + ' (agendado)');
    ajaxLoadUsersMedia('', false, async function (r) {
        try {
            if (!r || !r.edges || r.edges.length === 0) {
                outputMessage('Sem posts em @' + acct.username);
                return;
            }
            var reels = r.edges.map(function (e) { return e.node; }).filter(function (m) {
                return m && (m.media_type == 2 || m.is_video == true);
            });
            if (reels.length === 0) {
                outputMessage('Sem reels em @' + acct.username);
                return;
            }
            outputMessage(reels.length + ' reels de @' + acct.username + ' para assistir e curtir');
            for (var i = 0; i < reels.length; i++) {
                reels[i].SaveWhenWatchingReel = false;
                reels[i].LikeWhenWatchingReel = true;
                reels[i].owner = r.acct || { username: acct.username };
                await watchReel(reels[i]);
                addStamp(reels[i].id, 'stamp-div-green', 'watched');
                if (timeoutsQueue.length == 0) break;
            }
        } catch (e) {
            outputMessage('Falha ao assistir reels de @' + acct.username);
        }
    }, acct);
}

function vpSleep(ms) {
    return new Promise(function (resolve) {
        timeoutsQueue.push(setTimeout(resolve, ms));
    });
}

function vpToLocalInputValue(ts) {
    var d = new Date(ts);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + 'T' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

function vpRescheduleRowPlusHour(idx, matchFn, reason) {
    try {
        var row = gblActionsQueue[idx];
        if (row && matchFn(row)) {
            row.scheduledTime = vpToLocalInputValue(Date.now() + 3600000);
            row.ranAt = false;
            saveActionsQueue();
            setTimeout(loadActionsQueue, 100);
            outputMessage(reason + ' Reagendado +60min.');
            return true;
        }
    } catch (e) {}
    return false;
}

function vpFollowOnce(acct) {
    return new Promise(function (resolve) {
        $.ajax({
            url: 'https://www.instagram.com/api/v1/friendships/create/' + acct.id + '/',
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function (r) {
                if (r && (r.status === 'fail' || r.spam === true)) resolve('blocked:' + (r.message || 'fail'));
                else resolve(true);
            })
            .fail(function (data) {
                var s = data ? Number(data.status) : 0;
                if (s == 429 || s == 403 || s == 400) resolve('blocked:HTTP ' + s);
                else resolve(false);
            });
    });
}

function vpScheduleTargetFollowLike() {
    if (!vpLicenseGuard()) return false;

    var target = String($('#vp_target_user').val() || '').replace('@', '').trim();
    var total = parseInt($('#vp_target_total').val(), 10) || 0;
    var perDay = parseInt($('#vp_target_per_day').val(), 10) || 50;
    if (!target) { outputMessage('Informe o @ do perfil alvo.'); return false; }
    if (!(total >= 1)) { outputMessage('Informe a quantidade total (ex: 1000).'); return false; }
    if (perDay < 1) perDay = 1;
    if (perDay > 200) perDay = 200;
    var startAtVal = $('#vp_target_start_at').val();
    var startMs = startAtVal ? new Date(startAtVal).getTime() : Date.now();
    if (!isFinite(startMs)) startMs = Date.now();

    gblActionsQueue.push({
        functionName: 'vpRunTargetFollowLikeBatch',
        functionAlias: 'Alvo @' + target + ' seguir+curtir (0/' + total + ')',
        scheduledTime: vpToLocalInputValue(startMs),
        ranAt: false,
        repeatDaily: $('#vp_target_daily').is(':checked'),
        enabled: true,
        args: { mode: 'target_follow_like', target: target, total: total, perDay: perDay, processed: 0, maxId: '' }
    });

    saveActionsQueue();
    setTimeout(loadActionsQueue, 100);
    outputMessage('Alvo @' + target + ' agendado: ' + total + ' follows (' + perDay + '/dia). O @ fica salvo e continua de onde parou.');
}

async function vpRunTargetFollowLikeBatch(args, idx) {
    if (!vpLicenseGuard()) return false;
    args = args || {};
    var target = String(args.target || '').replace('@', '').trim();
    var total = parseInt(args.total, 10) || 0;
    var perDay = parseInt(args.perDay, 10) || 50;
    var processed = parseInt(args.processed, 10) || 0;
    if (!target || !(total >= 1)) { outputMessage('Ação por alvo sem configuração, ignorando.'); return false; }
    if (processed >= total) {
        outputMessage('Alvo @' + target + ' concluído (' + processed + '/' + total + ').');
        try {
            var row0 = gblActionsQueue[idx];
            if (row0 && row0.args && row0.args.target === target) { row0.enabled = false; saveActionsQueue(); setTimeout(loadActionsQueue, 100); }
        } catch (e) {}
        return true;
    }

    var profile = null;
    try {
        if (currentProfilePage && currentProfilePage.username &&
            normalizeConvenienceUsername(currentProfilePage.username) === normalizeConvenienceUsername(target) && currentProfilePage.id) {
            profile = currentProfilePage;
        } else {
            outputMessage('Resolvendo perfil @' + target + '...');
            profile = await getUserInfoFromGraphQL(target);
        }
    } catch (e) { profile = null; }
    if (!profile || !profile.id) {
        vpRescheduleRowPlusHour(idx, function (r) { return r.args && r.args.target === target; }, 'Alvo @' + target + ' sem ID (Instagram bloqueou).');
        return false;
    }

    var toDo = Math.min(perDay, total - processed);
    var maxId = args.maxId || null;
    var done = 0, pages = 0;
    while (done < toDo && pages < 25) {
        pages++;
        var r = null;
        try {
            r = await growbotFetchFriendshipsListPage(profile.id, 'followers', maxId, target);
        } catch (e) {
            vpRescheduleRowPlusHour(idx, function (row) { return row.args && row.args.target === target; }, 'Lista de seguidores bloqueada (' + ((e && e.message) || 'erro') + ').');
            return false;
        }
        if (!r.users || r.users.length === 0) break;
        for (var i = 0; i < r.users.length && done < toDo; i++) {
            var nu = growbotNormalizeFriendshipsListUser(r.users[i]);
            nu.source_type = 'Follower';
            nu.source_owner = target;
            if (alreadyAttempted({ id: nu.id }) !== false) continue;
            var res = await vpFollowOnce(nu);
            if (typeof res === 'string' && res.indexOf('blocked:') === 0) {
                args.processed = processed;
                args.maxId = maxId || '';
                vpSaveTargetBatchProgress(idx, args, target, total, processed);
                vpRescheduleRowPlusHour(idx, function (row) { return row.args && row.args.target === target; }, '@' + nu.username + ': restrição (' + res + ').');
                return false;
            }
            if (res === true) {
                addToAttempted({ id: nu.id, username: nu.username });
                addStamp(nu.id, 'stamp-div-green', 'followed');
                outputMessage('Seguido @' + nu.username + ' (alvo @' + target + ' ' + (processed + 1) + '/' + total + ')');
                try { actionsTaken++; } catch (e) {}
                vpQueueOneMediaLike(nu);
                done++;
                processed++;
            }
            await vpSleep(getSafeActionTime(gblOptions.timeDelay));
        }
        maxId = (r.has_more && r.next_max_id) ? String(r.next_max_id) : '';
        if (!r.has_more) break;
    }

    args.processed = processed;
    args.maxId = maxId || '';
    vpSaveTargetBatchProgress(idx, args, target, total, processed);
    if (processed >= total) {
        outputMessage('Alvo @' + target + ' concluído (' + processed + '/' + total + ').');
        try {
            var row = gblActionsQueue[idx];
            if (row && row.args && row.args.target === target) { row.enabled = false; saveActionsQueue(); setTimeout(loadActionsQueue, 100); }
        } catch (e) {}
    } else {
        outputMessage('Alvo @' + target + ': +' + done + ' hoje (' + processed + '/' + total + '). Continua amanhã de onde parou.');
    }
    return true;
}

function vpSaveTargetBatchProgress(idx, args, target, total, processed) {
    try {
        var row = gblActionsQueue[idx];
        if (row && row.args && row.args.target === target) {
            row.args.processed = processed;
            row.args.maxId = args.maxId || '';
            row.functionAlias = 'Alvo @' + target + ' seguir+curtir (' + processed + '/' + total + ')';
            saveActionsQueue();
            setTimeout(loadActionsQueue, 100);
        }
    } catch (e) {}
}

function vpScheduleFeedComment() {
    if (!vpLicenseGuard()) return false;

    var count = parseInt($('#vp_feedcomment_count').val(), 10) || 10;
    if (count < 1) count = 1;
    if (count > 100) count = 100;
    var txt = String($('#txtActionTargetComments').val() || '').trim();
    var lines = txt.split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l.length > 0; });
    if (lines.length === 0) { outputMessage('Cadastre frases no Pool de Comentários (aba Alvo + Comentários).'); return false; }
    var startAtVal = $('#vp_feedcomment_start_at').val();
    var startMs = startAtVal ? new Date(startAtVal).getTime() : Date.now();
    if (!isFinite(startMs)) startMs = Date.now();

    gblActionsQueue.push({
        functionName: 'vpRunScheduledFeedComment',
        functionAlias: 'Comentar feed (' + count + ' posts)',
        scheduledTime: vpToLocalInputValue(startMs),
        ranAt: false,
        repeatDaily: $('#vp_feedcomment_daily').is(':checked'),
        enabled: true,
        args: { mode: 'feed_comment', count: count, templates: lines }
    });

    saveActionsQueue();
    setTimeout(loadActionsQueue, 100);
    outputMessage(count + ' comentários no feed agendados.');
}

function vpGetCommentedPosts() {
    return new Promise(function (resolve) {
        try {
            chrome.storage.local.get('vp_commented_posts', function (data) {
                resolve(Array.isArray(data.vp_commented_posts) ? data.vp_commented_posts : []);
            });
        } catch (e) { resolve([]); }
    });
}

function vpSaveCommentedPost(pk) {
    try {
        chrome.storage.local.get('vp_commented_posts', function (data) {
            var arr = Array.isArray(data.vp_commented_posts) ? data.vp_commented_posts : [];
            arr.push(String(pk));
            if (arr.length > 500) arr = arr.slice(arr.length - 500);
            chrome.storage.local.set({ vp_commented_posts: arr }, function () {});
        });
    } catch (e) {}
}

function vpCommentOnce(mediaPk, text) {
    return new Promise(function (resolve) {
        try {
            ajaxCommentOnMedia(mediaPk, text).done(function () { resolve(true); }).fail(function (data) {
                var s = data ? Number(data.status) : 0;
                if (s == 429 || s == 403 || s == 400) resolve('blocked:HTTP ' + s);
                else resolve(false);
            });
        } catch (e) { resolve(false); }
    });
}

async function vpLoadFeedPostsGraphQL(count) {
    try {
        var actorId = '0';
        try { if (typeof getInstagramActorId === 'function' && getInstagramActorId()) actorId = getInstagramActorId(); } catch (e) {}
        var lsd = '';
        try { if (typeof getInstagramLsdToken === 'function') lsd = getInstagramLsdToken() || ''; } catch (e) {}
        var fbDtsg = '';
        try { if (typeof getInstagramFbDtsg === 'function') fbDtsg = getInstagramFbDtsg() || ''; } catch (e) {}
        var jazoest = '';
        try { if (typeof getInstagramJazoest === 'function') jazoest = getInstagramJazoest(fbDtsg) || ''; } catch (e) {}
        var csrf = '';
        try { csrf = getCsrfFromCookie() || ''; } catch (e) {}
        if (!lsd || !fbDtsg) {
            return { ok: false, error: 'sem tokens de sessão (recarregue o Instagram)' };
        }
        var posts = [];
        var after = '';
        var pages = 0;
        while (posts.length < count && pages < 8) {
            pages++;
            var afterPart = (after && after != '') ? '{"after":"' + after + '",' : '{';
            var varsObj = afterPart + '"before":null,"data":{"device_id":"E1F25225-A6AE-44CF-9EC8-932EC7E261CB","is_async_ads_double_request":"0","is_async_ads_in_headload_enabled":"0","is_async_ads_rti":"0","rti_delivery_backend":"0"},"first":12,"last":null,"variant":"home","__relay_internal__pv__PolarisIsLoggedInrelayprovider":true,"__relay_internal__pv__PolarisShareSheetV3relayprovider":false}';
            var body = [
                'av=' + encodeURIComponent(actorId),
                '__d=www',
                '__user=0',
                '__a=1',
                '__comet_req=7',
                'fb_dtsg=' + encodeURIComponent(fbDtsg),
                'jazoest=' + encodeURIComponent(jazoest),
                'lsd=' + encodeURIComponent(lsd),
                'fb_api_caller_class=RelayModern',
                'fb_api_req_friendly_name=PolarisFeedRootPaginationCachedQuery_subscribe',
                'server_timestamps=true',
                'variables=' + encodeURIComponent(varsObj),
                'doc_id=28982951317985068'
            ];
            var resp = await fetch('https://www.instagram.com/graphql/query', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'accept': '*/*',
                    'content-type': 'application/x-www-form-urlencoded',
                    'x-asbd-id': '359341',
                    'x-csrftoken': csrf,
                    'x-fb-friendly-name': 'PolarisFeedRootPaginationCachedQuery_subscribe',
                    'x-fb-lsd': lsd,
                    'x-ig-app-id': '936619743392459'
                },
                referrer: 'https://www.instagram.com/',
                referrerPolicy: 'strict-origin-when-cross-origin',
                body: body.join('&')
            });
            if (!resp.ok) {
                return { ok: false, error: 'HTTP ' + resp.status };
            }
            var jd = await resp.json();
            var conn = jd && jd.data && jd.data.xdt_api__v1__feed__timeline__connection;
            if (!conn || !conn.edges) {
                return { ok: false, error: 'resposta inesperada' };
            }
            for (var i = 0; i < conn.edges.length && posts.length < count; i++) {
                var m = conn.edges[i] && conn.edges[i].node && conn.edges[i].node.media;
                if (m && m.id) {
                    posts.push({ pk: m.id, id: m.id, user: m.owner || {}, code: m.code || '' });
                }
            }
            if (conn.page_info && conn.page_info.has_next_page && conn.page_info.end_cursor) {
                after = conn.page_info.end_cursor;
            } else {
                break;
            }
        }
        return { ok: true, posts: posts };
    } catch (e) {
        return { ok: false, error: String((e && e.message) || e) };
    }
}

async function vpRunScheduledFeedComment(args, idx) {
    if (!vpLicenseGuard()) return false;
    args = args || {};
    var count = parseInt(args.count, 10) || 10;
    var liveTxt = '';
    try { liveTxt = String($('#txtActionTargetComments').val() || '').trim(); } catch (e) {}
    var lines = liveTxt ? liveTxt.split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l.length > 0; }) : (args.templates || []);
    if (lines.length === 0) { outputMessage('Sem frases de comentário. Cadastre no Pool (aba Alvo + Comentários).'); return false; }

    outputMessage('Carregando feed para comentar ' + count + ' posts (agendado)...');
    var feedLoad = await vpLoadFeedPostsGraphQL(count);
    if (!feedLoad.ok) {
        vpRescheduleRowPlusHour(idx, function (r) { return r.args && r.args.mode === 'feed_comment'; }, 'Feed bloqueado pelo Instagram (' + feedLoad.error + ').');
        return false;
    }
    var feedItems = feedLoad.posts;
    if (feedItems.length === 0) {
        outputMessage('Feed vazio, nada para comentar.');
        return true;
    }

    var commented = await vpGetCommentedPosts();
    var done = 0;
    for (var i = 0; i < feedItems.length && done < count; i++) {
        var media = feedItems[i];
        var pk = String(media.pk || media.id || '');
        if (!pk || commented.indexOf(pk) > -1) continue;
        var text = lines[Math.floor(Math.random() * lines.length)];
        outputMessage('Comentando post de @' + ((media.user && media.user.username) || 'feed') + ': ' + text);
        var res = await vpCommentOnce(media.pk || media.id, text);
        if (typeof res === 'string' && res.indexOf('blocked:') === 0) {
            vpRescheduleRowPlusHour(idx, function (r) { return r.args && r.args.mode === 'feed_comment'; }, 'Comentário bloqueado (' + res + ').');
            return false;
        }
        if (res === true) {
            vpSaveCommentedPost(pk);
            commented.push(pk);
            done++;
            outputMessage('Comentário enviado (' + done + '/' + count + ')');
        }
        await vpSleep(getRandomizedTime(gblOptions.timeDelay));
    }
    outputMessage('Comentários no feed concluídos: ' + done + '/' + count + ' (agendado).');
    return true;
}

const igExternalVars = {
    "emptyProfilePicUrl": "44884218_345707102882519_2446069589734326272_n",
    "qsForConvenienceButtons": "div.xw7yly9 div.xsag5q8.x2vl965.x1onr9mi ._ap3a._aaco._aacw._aacx._aad7._aade",
    "qsForConvenienceButtonsProfile": "main header h2[dir=\"auto\"] > span[dir=\"auto\"], a.x1i10hfl h2.x1lliihq > span",
    "qsForProfilePageUsername": "a.x1i10hfl h2.x1lliihq"
}

var gblAcctsQueueGrid;
var gblCheckboxPlugin;

var instabot_install_date = 0; // set from background page
var instabot_free_trial_time = 0; // set from background page
var instabot_has_license = false; // Será definido pela verificação de licença Vision Plus
var vp_license_checked = false; // Se a primeira verificação já foi feita

// ============ GUARD DE LICENÇA - BLOQUEIA AÇÕES SEM LICENÇA ============
function vpLicenseGuard() {
    if (instabot_has_license === true) return true;
    printMessage('⛔ Licença inválida ou expirada. Ações bloqueadas.');
    outputMessage('Sua licença Vision Plus não está ativa. Renove para continuar usando.');
    // Mostrar overlay se não estiver visível
    if (!document.getElementById('vp-license-overlay')) {
        chrome.runtime.sendMessage({ checkLicense: window.__vp_current_ig_username || '' });
    }
    return false;
}

var defaultFilterOptions = {
    applyFiltersAutomatically: true,
    followers: [0, 10000000],
    following: [0, 10000],
    followRatio: [-10000, 10000000],
    mutualFollowedBy: [0, 10000000],
    posts: [0, 100000],
    lastPosted: [0, 5000],
    private: true,
    non_private: true,
    verified: true,
    non_verified: true,
    follows_me: false,
    non_follows_me: true,
    followed_by_me: false,
    non_followed_by_me: true,
    external_url_contains: false,
    external_url_not_contains: false,
    external_url_contains_text: '',
    external_url_not_contains_text: '',
    is_business_account: true,
    non_is_business_account: true,
    is_joined_recently: true,
    non_is_joined_recently: true,
    connected_fb_page: true,
    non_connected_fb_page: true,
    bio_contains: false,
    bio_not_contains: false,
    bio_contains_text: '',
    bio_not_contains_text: '',
    no_profile_pic: true,
    profile_pic: true,
    business_category_name_contains: false,
    business_category_name_contains_text: '',
    business_category_name_not_contains: false,
    business_category_name_not_contains_text: ''
};


var gbDefaultColumns = [{
    "name": '✓',
    "data": 'id',
    "width": '40px',
    "formatter": '<input type="checkbox" id="cb_${cell}" value="${cell}" />',
    "visible": true,
}, {
    "name": 'Pic',
    "data": 'profile_pic_url',
    "formatter": '<label for="cb_${ig_id}"><img data-ig-userid="${ig_id}" data-src="${cell}" class="igBotQueueAcctProfilePicture"/></label>',
    "sort": false,
    "width": '62px',
    "visible": true
}, {
    "name": '@username',
    "data": 'username',
    "formatter": '<a href="https://www.instagram.com/${cell}" target="_blank">@${cell}</a>',
    "width": '165px',
    "visible": true
}, {
    "name": 'Full Name',
    "data": 'full_name',
    "width": '150px',
    "visible": true
}, {
    "name": 'Bio',
    "data": 'biography',
    "width": '300px',
    "visible": true
}, {
    "name": 'Clips',
    "data": 'has_clips',
    "width": '95px',
    "visible": true
}, {
    "name": 'Highlights',
    "data": 'highlight_reel_count',
    "width": '95px',
    "visible": true
}, {
    "name": 'Posts',
    "data": 'edge_owner_to_timeline_media.count',
    "width": '65px',
    "visible": true
}, {
    "name": 'Link In Bio',
    "data": 'external_url',
    "formatter": '<a href="${cell}" title="${cell}" target="_blank">${cell}</a>',
    "width": '250px',
    "visible": true
}, {
    "name": 'Followers',
    "data": 'edge_followed_by.count',
    "width": '90px',
    "visible": true
}, {
    "name": 'Following',
    "data": 'edge_follow.count',
    "width": '90px',
    "visible": true
}, {
    "name": 'Ratio',
    "data": 'followRatio',
    "width": '65px',
    "visible": true
}, {
    "name": 'Mutual',
    "data": 'edge_mutual_followed_by.count',
    "width": '70px',
    "visible": true,
    "numeric": true
}, {
    "name": 'Followed By Me',
    "data": 'followed_by_viewer',
    "width": '120px',
    "visible": true,
    "bool": true
}, {
    "name": 'Follows Me',
    "data": 'follows_viewer',
    "width": '95px',
    "visible": true,
    "bool": true
}, {
    "name": 'Requested',
    "data": 'requested_by_viewer',
    "width": '95px',
    "visible": true,
    "bool": true
}, {
    "name": 'Joined Recently',
    "data": 'is_joined_recently',
    "width": '100px',
    "visible": true,
    "bool": true
}, {
    "name": 'Private',
    "data": 'is_private',
    "width": '70px',
    "visible": true,
    "bool": true
}, {
    "name": 'Verified',
    "data": 'is_verified',
    "width": '70px',
    "visible": true,
    "bool": true
}, {
    "name": 'Business Category',
    "data": 'business_category_name',
    "width": '150px',
    "visible": true
}, {
    "name": 'Pronouns',
    "data": 'pronouns',
    "width": '90px',
    "visible": true
}, {
    "name": 'Last Posted',
    "data": 'lastPostDateInDays',
    "width": '100px',
    "visible": true
}, {
    "name": "Contact Phone Number",
    "data": "contact_phone_number",
    "visible": true
}, {
    "name": "Public Email",
    "data": "public_email",
    "visible": true
}, {
    "name": "Address Street",
    "data": "address_street",
    "visible": true
}, {
    "name": "City Name",
    "data": "city_name",
    "visible": true
}, {
    "name": "Zip",
    "data": "zip",
    "visible": true
}, {
    "name": "Latitude",
    "data": "latitude",
    "visible": true
}, {
    "name": "Longitude",
    "data": "longitude",
    "visible": true
}, {
    "name": "Primary Profile Link Type",
    "data": "primary_profile_link_type",
    "visible": false
}, {
    "name": "Show Fb Link On Profile",
    "data": "show_fb_link_on_profile",
    "visible": false
}, {
    "name": "Show Fb Page Link On Profile",
    "data": "show_fb_page_link_on_profile",
    "visible": false
}, {
    "name": "Can Hide Category",
    "data": "can_hide_category",
    "visible": false,
    "bool": true
}, {
    "name": "Smb Support Partner",
    "data": "smb_support_partner",
    "visible": false
}, {
    "name": "Current Catalog Id",
    "data": "current_catalog_id",
    "visible": false
}, {
    "name": "Mini Shop Seller Onboarding Status",
    "data": "mini_shop_seller_onboarding_status",
    "visible": false
}, {
    "name": "Account Category",
    "data": "account_category",
    "visible": false
}, {
    "name": "Can Add Fb Group Link On Profile",
    "data": "can_add_fb_group_link_on_profile",
    "visible": false,
    "bool": true
}, {
    "name": "Can Use Affiliate Partnership Messaging As Creator",
    "data": "can_use_affiliate_partnership_messaging_as_creator",
    "visible": false,
    "bool": true
}, {
    "name": "Can Use Affiliate Partnership Messaging As Brand",
    "data": "can_use_affiliate_partnership_messaging_as_brand",
    "visible": false
}, {
    "name": "Existing User Age Collection Enabled",
    "data": "existing_user_age_collection_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Feed Post Reshare Disabled",
    "data": "feed_post_reshare_disabled",
    "visible": false,
    "bool": true
}, {
    "name": "Has Public Tab Threads",
    "data": "has_public_tab_threads",
    "visible": false,
    "bool": true
}, {
    "name": "Highlight Reshare Disabled",
    "data": "highlight_reshare_disabled",
    "visible": false,
    "bool": true
}, {
    "name": "Include Direct Blacklist Status",
    "data": "include_direct_blacklist_status",
    "visible": false,
    "bool": true
}, {
    "name": "Is Direct Roll Call Enabled",
    "data": "is_direct_roll_call_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Pk",
    "data": "pk",
    "visible": false
}, {
    "name": "Pk Id",
    "data": "pk_id",
    "visible": false
}, {
    "name": "Profile Type",
    "data": "profile_type",
    "visible": false
}, {
    "name": "Show Ig App Switcher Badge",
    "data": "show_ig_app_switcher_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Show Post Insights Entry Point",
    "data": "show_post_insights_entry_point",
    "visible": false,
    "bool": true
}, {
    "name": "Show Text Post App Badge",
    "data": "show_text_post_app_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Show Text Post App Switcher Badge",
    "data": "show_text_post_app_switcher_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Text Post App Joiner Number Label",
    "data": "text_post_app_joiner_number_label",
    "visible": false
}, {
    "name": "Third Party Downloads Enabled",
    "data": "third_party_downloads_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Profile Picture Expansion Enabled",
    "data": "is_profile_picture_expansion_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Opal Enabled",
    "data": "is_opal_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Can Hide Public Contacts",
    "data": "can_hide_public_contacts",
    "visible": false,
    "bool": true
}, {
    "name": "Is Category Tappable",
    "data": "is_category_tappable",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Smb Support Flow",
    "data": "is_eligible_for_smb_support_flow",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Lead Center",
    "data": "is_eligible_for_lead_center",
    "visible": false,
    "bool": true
}, {
    "name": "Lead Details App Id",
    "data": "lead_details_app_id",
    "visible": false,
    "bool": true
}, {
    "name": "Direct Messaging",
    "data": "direct_messaging",
    "visible": false
}, {
    "name": "Fb Page Call To Action Id",
    "data": "fb_page_call_to_action_id",
    "visible": false
}, {
    "name": "Displayed Action Button Partner",
    "data": "displayed_action_button_partner",
    "visible": false
}, {
    "name": "Smb Delivery Partner",
    "data": "smb_delivery_partner",
    "visible": false
}, {
    "name": "Smb Support Delivery Partner",
    "data": "smb_support_delivery_partner",
    "visible": false
}, {
    "name": "Displayed Action Button Type",
    "data": "displayed_action_button_type",
    "visible": false
}, {
    "name": "Is Call To Action Enabled",
    "data": "is_call_to_action_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Shopping Post Onboard Nux Type",
    "data": "shopping_post_onboard_nux_type",
    "visible": false
}, {
    "name": "Ads Incentive Expiration Date",
    "data": "ads_incentive_expiration_date",
    "visible": false
}, {
    "name": "Account Badges",
    "data": "account_badges",
    "visible": false
}, {
    "name": "Auto Expand Chaining",
    "data": "auto_expand_chaining",
    "visible": false
}, {
    "name": "Birthday Today Visibility For Viewer",
    "data": "birthday_today_visibility_for_viewer",
    "visible": false
}, {
    "name": "Can Use Branded Content Discovery As Brand",
    "data": "can_use_branded_content_discovery_as_brand",
    "visible": false
}, {
    "name": "Can Use Branded Content Discovery As Creator",
    "data": "can_use_branded_content_discovery_as_creator",
    "visible": false
}, {
    "name": "Remove Message Entrypoint",
    "data": "remove_message_entrypoint",
    "visible": false
}, {
    "name": "Is Eligible For Request Message",
    "data": "is_eligible_for_request_message",
    "visible": false,
    "bool": true
}, {
    "name": "Transparency Product Enabled",
    "data": "transparency_product_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Whatsapp Number",
    "data": "whatsapp_number",
    "visible": false
}, {
    "name": "Merchant Checkout Style",
    "data": "merchant_checkout_style",
    "visible": false
}, {
    "name": "Mutual Followers Count",
    "data": "mutual_followers_count",
    "visible": false
}, {
    "name": "Nametag",
    "data": "nametag",
    "visible": false
}, {
    "name": "Open External Url With In App Browser",
    "data": "open_external_url_with_in_app_browser",
    "visible": false,
    "bool": true
}, {
    "name": "Pinned Channels Info",
    "data": "pinned_channels_info",
    "visible": false
}, {
    "name": "Profile Context",
    "data": "profile_context",
    "visible": false
}, {
    "name": "Profile Context Facepile Users",
    "data": "profile_context_facepile_users",
    "visible": false
}, {
    "name": "Profile Context Links With User Ids",
    "data": "profile_context_links_with_user_ids",
    "visible": false
}, {
    "name": "Profile Context Mutual Follow Ids",
    "data": "profile_context_mutual_follow_ids",
    "visible": false
}, {
    "name": "Profile Pic Id",
    "data": "profile_pic_id",
    "visible": false
}, {
    "name": "Recon Features",
    "data": "recon_features",
    "visible": false
}, {
    "name": "Relevant News Regulation Locations",
    "data": "relevant_news_regulation_locations",
    "visible": false
}, {
    "name": "Seller Shoppable Feed Type",
    "data": "seller_shoppable_feed_type",
    "visible": false
}, {
    "name": "Show Shoppable Feed",
    "data": "show_shoppable_feed",
    "visible": false,
    "bool": true
}, {
    "name": "Text Post App Badge Label",
    "data": "text_post_app_badge_label",
    "visible": false
}, {
    "name": "Total Ar Effects",
    "data": "total_ar_effects",
    "visible": false
}, {
    "name": "Is Memorialized",
    "data": "is_memorialized",
    "visible": false
}, {
    "name": "Is Potential Business",
    "data": "is_potential_business",
    "visible": false,
    "bool": true
}, {
    "name": "Is Profile Broadcast Sharing Enabled",
    "data": "is_profile_broadcast_sharing_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Recon Ad Cta On Profile Eligible With Viewer",
    "data": "is_recon_ad_cta_on_profile_eligible_with_viewer",
    "visible": false,
    "bool": true
}, {
    "name": "Is Supervision Features Enabled",
    "data": "is_supervision_features_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Whatsapp Linked",
    "data": "is_whatsapp_linked",
    "visible": false,
    "bool": true
}, {
    "name": "Latest Besties Reel Media",
    "data": "latest_besties_reel_media",
    "visible": false
}, {
    "name": "Num Of Admined Pages",
    "data": "num_of_admined_pages",
    "visible": false
}, {
    "name": "Page Id",
    "data": "page_id",
    "visible": false
}, {
    "name": "Page Name",
    "data": "page_name",
    "visible": false
}, {
    "name": "Ads Page Id",
    "data": "ads_page_id",
    "visible": false
}, {
    "name": "Ads Page Name",
    "data": "ads_page_name",
    "visible": false
}, {
    "name": "Charity Profile Fundraiser Info",
    "data": "charity_profile_fundraiser_info",
    "visible": false
}, {
    "name": "Creator Shopping Info",
    "data": "creator_shopping_info",
    "visible": false
}, {
    "name": "Fan Club Info",
    "data": "fan_club_info",
    "visible": false
}, {
    "name": "Follow Friction Type",
    "data": "follow_friction_type",
    "visible": false
}, {
    "name": "Follower Count",
    "data": "follower_count",
    "visible": false
}, {
    "name": "Following Count",
    "data": "following_count",
    "visible": false
}, {
    "name": "Has Active Charity Business Profile Fundraiser",
    "data": "has_active_charity_business_profile_fundraiser",
    "visible": false,
    "bool": true
}, {
    "name": "Has Anonymous Profile Picture",
    "data": "has_anonymous_profile_picture",
    "visible": false,
    "bool": true
}, {
    "name": "Has Collab Collections",
    "data": "has_collab_collections",
    "visible": false,
    "bool": true
}, {
    "name": "Has Exclusive Feed Content",
    "data": "has_exclusive_feed_content",
    "visible": false,
    "bool": true
}, {
    "name": "Has Fan Club Subscriptions",
    "data": "has_fan_club_subscriptions",
    "visible": false,
    "bool": true
}, {
    "name": "Has Highlight Reels",
    "data": "has_highlight_reels",
    "visible": false,
    "bool": true
}, {
    "name": "Has Igtv Series",
    "data": "has_igtv_series",
    "visible": false,
    "bool": true
}, {
    "name": "Has Music On Profile",
    "data": "has_music_on_profile",
    "visible": false,
    "bool": true
}, {
    "name": "Has Private Collections",
    "data": "has_private_collections",
    "visible": false,
    "bool": true
}, {
    "name": "Has Videos",
    "data": "has_videos",
    "visible": false,
    "bool": true
}, {
    "name": "Hd Profile Pic Url Info",
    "data": "hd_profile_pic_url_info",
    "visible": false
}, {
    "name": "Hd Profile Pic Versions",
    "data": "hd_profile_pic_versions",
    "visible": false
}, {
    "name": "Interop Messaging User Fbid",
    "data": "interop_messaging_user_fbid",
    "visible": false
}, {
    "name": "Is Bestie",
    "data": "is_bestie",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Diverse Owned Business Info",
    "data": "is_eligible_for_diverse_owned_business_info",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Meta Verified Links In Reels",
    "data": "is_eligible_for_meta_verified_links_in_reels",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Meta Verified Enhanced Link Sheet",
    "data": "is_eligible_for_meta_verified_enhanced_link_sheet",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible To Display Diverse Owned Business Info",
    "data": "is_eligible_to_display_diverse_owned_business_info",
    "visible": false,
    "bool": true
}, {
    "name": "Is Facebook Onboarded Charity",
    "data": "is_facebook_onboarded_charity",
    "visible": false,
    "bool": true
}, {
    "name": "Is Favorite",
    "data": "is_favorite",
    "visible": false,
    "bool": true
}, {
    "name": "Is In Canada",
    "data": "is_in_canada",
    "visible": false,
    "bool": true
}, {
    "name": "Strong Id  ",
    "data": "strong_id__",
    "visible": false
}, {
    "name": "External Lynx Url",
    "data": "external_lynx_url",
    "visible": false
}, {
    "name": "Is Interest Account",
    "data": "is_interest_account",
    "visible": false,
    "bool": true
}, {
    "name": "Latest Reel Media",
    "data": "latest_reel_media",
    "visible": false
}, {
    "name": "Media Count",
    "data": "media_count",
    "visible": false
}, {
    "name": "Total Clips Count",
    "data": "total_clips_count",
    "visible": false
}, {
    "name": "Total Igtv Videos",
    "data": "total_igtv_videos",
    "visible": false
}, {
    "name": "Recs From Friends",
    "data": "recs_from_friends",
    "visible": false
}, {
    "name": "City Id",
    "data": "city_id",
    "visible": false
}, {
    "name": "Public Phone Country Code",
    "data": "public_phone_country_code",
    "visible": false
}, {
    "name": "Public Phone Number",
    "data": "public_phone_number",
    "visible": false
}, {
    "name": "Professional Conversion Suggested Account Type",
    "data": "professional_conversion_suggested_account_type",
    "visible": false
}, {
    "name": "Account Type",
    "data": "account_type",
    "visible": false
}, {
    "name": "Fbid V2",
    "data": "fbid_v2",
    "visible": false
}, {
    "name": "Is Profile Audio Call Enabled",
    "data": "is_profile_audio_call_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Instagram Location Id",
    "data": "instagram_location_id",
    "visible": false
}, {
    "name": "Is New To Instagram",
    "data": "is_new_to_instagram",
    "visible": false,
    "bool": true
}, {
    "name": "Is New To Instagram 30d",
    "data": "is_new_to_instagram_30d",
    "visible": false,
    "bool": true
}, {
    "name": "Is Secondary Account Creation",
    "data": "is_secondary_account_creation",
    "visible": false,
    "bool": true
}, {
    "name": "Category",
    "data": "category",
    "visible": false
}, {
    "name": "Category Id",
    "data": "category_id",
    "visible": false
}, {
    "name": "Is Business",
    "data": "is_business",
    "visible": false
}, {
    "name": "Language Code",
    "data": "languageCode",
    "visible": false
}, {
    "name": "Language %",
    "data": "languagePercentage",
    "visible": false
}, {
    "name": "Language #",
    "data": "languageCount",
    "visible": false
}, {
    "name": "Language",
    "data": "languageName",
    "visible": true
}];


var defaultOptions = {
    timeDelay: 180000,
    timeDelayAfterSoftRateLimit: 600000,
    timeDelayAfterHardRateLimit: 3600000,
    timeDelayAfter429RateLimit: 60000,
    timeDelayAfterAdditionalInfo: 2000,
    useTimeDelayAfterAdditionalInfo: false,
    retriesAfterAdditionalInfo404: 10,
    timeDelayAfterSkip: 0.5,
    useRandomTimeDelay: true,
    percentRandomTimeDelay: 0.5,
    followPrivateAccounts: true,
    limitQueue: true,
    maxAcctQueueLength: 50,
    maxMediaQueueLength: 50,
    paginationLimit: 100,
    mediapaginationLimit: 100,
    truncateStart: 0,
    dontUnFollowFollowers: true,
    dontUnFollowFilters: false,
    dontRemoveOrBlockFilters: false,
    dontUnFollowNonGrowbot: true,
    unFollowFresh: false,
    unFollowIfOld: true,
    unFollowDelay: 259200000, // 259200000 = 3 dias
    unFollowIfOlderThan: 2592000000, // 2592000000 = 30 dias
    followLikeLatestPics: false,
    numberFollowLikeLatestPics: 1,
    numberLoadPostsFromAccounts: 1,
    includePinnedPostForAccountMedia: true,
    filterOptions: defaultFilterOptions,
    ui: [],
    cbShowQueueOnScreen: true,
    cbRemoveUnusedColumns: false,
    showFollowingInQueue: true,
    showLikesInQueue: true,
    removeAccountsFromQueue: false,
    autoSaveQueue: false,
    showStamps: true,
    showProfilePicInQueue: true,
    showConvenienceButtons: true,
    loadQueueOnStartup: false,
    clickNotNow: false,
    followPeopleAlreadyAttempted: false,
    maxPerEnabled: false,
    maxPerActions: 50,
    maxPerPeriod: 86400000,
    getExtendedData: false,
    getLastPostDate: false,
    endcursors: [],
    queueColumns: gbDefaultColumns,
    MediaIncludeLikersCommentersTagged: false,
    SaveWhenWatchingReel: true,
    LikeWhenWatchingReel: true,
    lastTab: 'tab1',
    includePinnedPostForLikes: true,
    includePinnedPostForComments: true,
    txtActionTargetProfile: '',
    txtActionTargetCount: 10,
    txtActionTargetComments: ''
};

var gblOptions = defaultOptions;

var gbl404attempt = 0;

var acctsQueue = [];
var theirFollowings = [];
var myFollowers = [];
var timeoutsQueue = [];
var alreadyLiking = false;

var acctsProcessed = [];
var acctsPreviouslyAttempted = [];
var acctsWhiteList = [];
var freeTrialInterval;

var scrollIntervalId;
var totalAvailableForQueue;

var loadedTheirFollowers = false;
var loadedTheirFollowings = false;
var loadedMyFollowers = false;
var loadedMyFollowings = false;

var user;
var currentProfilePage = false;
var gbProfileLoading = false;
var gbProfileLastErrorAt = 0;

var todaysdate = new Date();
var today = todaysdate.getTime();

var mediaToLike = [];
var previousLikes = [];

var currentList = false;

var queueSplit = false;

var usernameCheckInterval;

var maxActionsDelayStartTime = 0;
var actionsTaken = 0;

var gblFollow404Count = 0;
var gblUnfollow404Count = 0;

let mediaForComments = [];
let accountIdsThatCommented = [];


let mediaForLikes = [];
let accountIdsThatLiked = [];

function waitForWinVars() {

    var sharedData = JSON.parse(localStorage.getItem('winvars'));

    if (sharedData) {

        if (sharedData.config && sharedData.config.viewer != null) {
            user = sharedData.config;
            gbInit();
        } else {
            waitForElement('script[type="application/json"]', document, gbInit, false);
        }

    } else {
        setTimeout(waitForWinVars, 10);
    }

}

function gbInit() {

    if (shouldLoadGrowbotOnThisPage() == false) return false;

    localStorage.clear('winvars');


    injectControlsDiv();


    if (getBackgroundInfo() === false) {
        return false;
    }



    startUserNameFreshnessInterval();

    setInterval(monitorButtonConditions, 250);

    setInterval(growbotActionRunner, 1000);


}

function getCookie(name) {
    let cookie = {};
    document.cookie.split(';').forEach(function (el) {
        let split = el.split('=');
        cookie[split[0].trim()] = split.slice(1).join("=");
    })
    return cookie[name];
}

function getCsrfFromCookie() {
    return getCookie('csrftoken');
}

function getInstagramPageTokenSource() {
    var chunks = [];
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
        var text = scripts[i].textContent || '';
        if (text.indexOf('DTSG') > -1 || text.indexOf('dtsg') > -1 || text.indexOf('LSD') > -1 || text.indexOf('"lsd"') > -1) {
            chunks.push(text);
        }
    }
    if (chunks.length > 0) return chunks.join('\n');
    return document.documentElement && document.documentElement.innerHTML ? document.documentElement.innerHTML : '';
}

function getInstagramLsdToken() {
    var lsdInput = document.querySelector('input[name="lsd"]');
    if (lsdInput && lsdInput.value) return lsdInput.value;
    var html = getInstagramPageTokenSource();
    if (!html) return '';
    var patterns = [
        /"LSD",\[\],\{"token":"([^"]+)"/,
        /"lsd":"([^"]+)"/,
        /name="lsd" value="([^"]+)"/
    ];
    for (var i = 0; i < patterns.length; i++) {
        var match = html.match(patterns[i]);
        if (match && match[1]) return match[1];
    }
    return '';
}

function getInstagramFbDtsg() {
    var fbDtsgInput = document.querySelector('input[name="fb_dtsg"]');
    if (fbDtsgInput && fbDtsgInput.value) return fbDtsgInput.value;
    var html = getInstagramPageTokenSource();
    if (!html) return '';
    var patterns = [
        /"DTSGInitData",\[\],\{"token":"([^"]+)"/,
        /"DTSGInitialData",\[\],\{"token":"([^"]+)"/,
        /"dtsg":\{"token":"([^"]+)"/,
        /name="fb_dtsg" value="([^"]+)"/,
        /"fb_dtsg":"([^"]+)"/
    ];
    for (var j = 0; j < patterns.length; j++) {
        var match = html.match(patterns[j]);
        if (match && match[1]) return match[1];
    }
    return '';
}

function getInstagramJazoest(fbDtsg) {
    if (!fbDtsg) return '';
    var sum = 0;
    for (var i = 0; i < fbDtsg.length; i++) {
        sum += fbDtsg.charCodeAt(i);
    }
    return String(2 + sum);
}

function getInstagramActorId() {
    try {
        if (typeof user !== 'undefined' && user && user.viewerId) {
            var viewerId = String(user.viewerId);
            if (viewerId.indexOf('178414') === 0) return viewerId;
        }
    } catch (e) {}
    var dsUserId = getCookie('ds_user_id');
    if (dsUserId) return '178414' + String(dsUserId);
    return '';
}

function getMediaIdForLike(media) {
    if (media.pk != null && media.pk !== '') return String(media.pk);
    if (media.id != null && media.id !== '') {
        var id = String(media.id);
        if (id.indexOf('_') > -1) return id.split('_')[0];
        return id;
    }
    return '';
}

function parseInstagramGraphqlLikeResult(data) {
    if (!data || typeof data !== 'object') {
        return { ok: false, message: 'empty response' };
    }
    if (data.errors && data.errors.length) {
        var msg = data.errors.map(function (e) {
            return e.message || JSON.stringify(e);
        }).join('; ');
        return { ok: false, message: msg };
    }
    if (!data.data || typeof data.data !== 'object') {
        return { ok: false, message: 'missing data object' };
    }
    var keys = Object.keys(data.data);
    if (keys.length === 0) {
        return { ok: false, message: 'empty data object' };
    }
    for (var i = 0; i < keys.length; i++) {
        if (data.data[keys[i]] === null) {
            return { ok: false, message: keys[i] + ' returned null' };
        }
    }
    return { ok: true };
}

function handleLikeMediaFailure(media, status, responseSnippet) {
    mediaToLike.unshift(media);
    if (status == 403) {
        printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
        timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfterSoftRateLimit));
    } else if (status == 400) {
        printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
        timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfterHardRateLimit));
    } else if (status == 429) {
        printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
        timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfter429RateLimit));
    } else {
        console.error('Like failed:', { status: status, responseSnippet: responseSnippet });
        outputMessage((status || 'error') + ' error, trying again in 5 seconds');
        if (responseSnippet) outputMessage('Like failure response (truncated): ' + responseSnippet);
        timeoutsQueue.push(setTimeout(likeAllMedia, 5000));
    }
}

function handleLikeMediaSuccess(media) {
    previousLikes.push(media.id);
    savePreviousLikesToStorage();
    if (media.user && media.user.username) {
        outputMessage('Liked post for ' + media.user.username);
    } else if (media.owner && media.owner.username) {
        outputMessage('Liked post for ' + media.owner.username);
    } else {
        outputMessage('Liked post');
    }
    addStamp(media.id, 'stamp-div-green', 'liked');
    var waitTime = getRandomizedTime(gblOptions.timeDelay);
    if (mediaToLike.length > 0) {
        outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to Like next');
        timeoutsQueue.push(setTimeout(likeAllMedia, waitTime));
        alreadyLiking = true;
    } else {
        alreadyLiking = false;
    }
}

async function igSafeTimelineJson(fetchResp) {
    if (!fetchResp) return { ok: false, message: 'empty response' };
    if (!fetchResp.ok) return { ok: false, message: 'HTTP ' + fetchResp.status };
    var ct = '';
    try { ct = fetchResp.headers.get('content-type') || ''; } catch (e) {}
    try {
        if (ct.indexOf('application/json') === -1) {
            var t = await fetchResp.text();
            if (t.indexOf('<!DOCTYPE') > -1 || t.indexOf('<html') > -1) return { ok: false, message: 'blocked (login HTML)' };
            try { return { ok: true, data: JSON.parse(t) }; } catch (e) { return { ok: false, message: 'invalid JSON' }; }
        }
        return { ok: true, data: await fetchResp.json() };
    } catch (e) {
        return { ok: false, message: String(e && e.message || e) };
    }
}

function displayFreeTrialTimeLeft() {
    // Licença sempre ativa — verificação de servidor removida
    $('#h2FreeTrialTimeLeft').text('Licença ativa');
    $('#relinkSubscription').hide();
    clearInterval(freeTrialInterval);
}

function timeToDate(t) {
    var date = new Date(parseInt(t));
    return date.toString();
}

function printMessage(txt) {
    outputMessage(txt);
}

function outputMessage(txt) {

    var statusDiv = document.getElementById('igBotStatusDiv');
    var fakeConsole = document.getElementById('txtConsole');

    if (txt.trim() != '' && statusDiv) {
        txt = getTimeStamp() + ' - ' + txt;
        statusDiv.textContent = txt;
        displayWaitTimeHacky();
    }

    if (fakeConsole) {
        try {
            var newLog = fakeConsole.textContent + '\n' + txt;
            // Limita o log (evita estourar quota do storage após horas de uso)
            if (newLog.length > 60000) {
                newLog = newLog.slice(-40000);
                if (/^[\uDC00-\uDFFF]/.test(newLog)) newLog = newLog.slice(1);
            }
            fakeConsole.textContent = newLog;
            chrome.storage.local.set({
                growbotLog: newLog.length > 20000 ? newLog.slice(-20000) : newLog
            }, function () { });
        } catch (e) {
            try { fakeConsole.textContent = fakeConsole.textContent + '\n' + txt; } catch (e2) {}
        }
    }

    scrollLog();

    includeLogInMailToLinks();

}

function scrollLog() {
    setTimeout(function () {
        var fakeConsole = document.getElementById('txtConsole');
        if (document.activeElement.id !== 'txtConsole') {
            fakeConsole.scrollTop = fakeConsole.scrollHeight;
        }
    }, 100);
}

function includeLogInMailToLinks() {
    // Blindado: slice(-20000) podia cortar um emoji (par surrogate) no meio e
    // o encodeURIComponent lançava "URI malformed", quebrando o post no meio.
    try {
        var full = document.getElementById('txtConsole').textContent;
        var t = full.length > 20000 ? full.slice(-20000) : full;
        if (/^[\uDC00-\uDFFF]/.test(t)) t = t.slice(1);
        if (/[\uD800-\uDBFF]$/.test(t)) t = t.slice(0, -1);
        $('.growbotEmailLink').attr('target', '_blank').attr('href', 'mailto:growbotautomator@gmail.com?body=' + encodeURIComponent('\n\n------------------------------------------------------------------------------------------------------------------------------------\nPlease type your message above this line, include the log below for debugging:\n------------------------------------------------------------------------------------------------------------------------------------\n' + t));
    } catch (e) {}
}

function trimLog() {
    var fakeConsole = document.getElementById('txtConsole');
    //fakeConsole.textContent = fakeConsole.textContent.slice(-100);

    var arrLines = fakeConsole.textContent.split('\n');
    arrLines = arrLines.slice(arrLines.length - 1000, arrLines.length);

    fakeConsole.textContent = arrLines.join('\n');

    outputMessage('Log trimmed');
}

function displayWaitTimeHacky() {
    var statusDiv = document.getElementById('igBotStatusDiv');

    var statusText = statusDiv.textContent;

    if (statusText.indexOf('Max actions exceeded') > -1) {
        statusDiv.textContent = getTimeStamp() + ' - ' + 'Max actions exceeded, waiting ' + millisecondsToHumanReadable(maxActionsDelayRemaining(), true)
        setTimeout(displayWaitTimeHacky, 1000);
        return false;
    }

    if (statusText.indexOf('waiting ') > -1 && statusText.indexOf(' seconds') > -1) {
        var secondsStart = statusText.indexOf('waiting ') + 8;
        var secondsEnd = statusText.indexOf(' second');
        var seconds = statusText.substring(secondsStart, secondsEnd);

        if (!isNaN(seconds) && (seconds - 1 > 0)) {
            statusDiv.textContent = statusDiv.textContent.replace('waiting ' + seconds + ' seconds', 'waiting ' + (Math.round((seconds - 1) * 100) / 100) + ' seconds');
            if (seconds - 1 > 1) {
                setTimeout(displayWaitTimeHacky, 1000);
            }
        }
    }

    if (statusText.indexOf('waiting ') > -1 && statusText.indexOf(' minute') > -1) {
        var secondsStart = statusText.indexOf('waiting ') + 8;
        var secondsEnd = statusText.indexOf(' minute');
        var minutes = statusText.substring(secondsStart, secondsEnd);

        if (!isNaN(minutes)) {
            seconds = minutes * 60;
            statusDiv.textContent = statusDiv.textContent.replace('waiting ' + minutes + ' minutes', 'waiting ' + (Math.round((seconds - 1) * 100) / 100) + ' seconds');
            if (seconds - 1 > 1) {
                setTimeout(displayWaitTimeHacky, 1000);
            }
        }
    }

}

function millisecondsToHumanReadable(ms, formatAsString) {

    var obj = {};
    var x = ms / 1000;
    obj.seconds = parseInt(x % 60);
    x /= 60;
    obj.minutes = parseInt(x % 60);
    x /= 60;
    obj.hours = parseInt(x % 24);
    x /= 24;
    obj.days = parseInt(x);

    if (formatAsString == false) {
        return obj;
    }

    return obj.days + ' days, ' + obj.hours + ' hours, ' + obj.minutes + ' minutes, ' + obj.seconds + ' seconds';

}

function zeroPad(digitcount, num) {
    for (var i = 0; i < digitcount; i++) {
        num = "0" + num;
    }

    return num.substr(-digitcount, digitcount);
}

function getTimeStamp() {
    var d = new Date();
    var meridium = '';
    var hours = d.getHours();

    // if (hours > 11) {
    //     meridium = ' pm';
    //     hours = hours - 12;
    // } else {
    //     meridium = ' am';
    // }

    // if (hours == 0) {
    //     meridium = ' pm';
    //     hours = 12;
    // }

    return (d.getFullYear() + '-' + zeroPad(2, d.getMonth() + 1)) + '-' + zeroPad(2, d.getDate()) + ' ' + zeroPad(2, d.getHours()) + ':' + zeroPad(2, d.getMinutes()) + ':' + zeroPad(2, d.getSeconds()) + meridium;
}

function containsObject(obj, list) {
    var i;
    for (i = 0; i < list.length; i++) {
        if (list[i].id === obj.id) {
            return true;
        }
    }

    return false;
}

function findAcctById(id, list, returnIndexOnly) {
    if (returnIndexOnly !== true) returnIndexOnly = false;
    var i;
    for (i = 0; i < list.length; i++) {
        if (list[i].id === id) {
            if (returnIndexOnly === true) return i;
            return list[i];
        }
    }
    return false;
}


function normalizeConvenienceUsername(s) {
    return String(s || '').trim().replace(/^@/, '').toLowerCase();
}

var growbotProfilePathReservedSegments = ['explore', 'stories', 'accounts', 'direct', 'reel', 'p', 'tv', 'tags', 'locations', 'legal', 'about-us'];

function getProfileUsernameFromPath() {
    var parts = window.location.pathname.split('/').filter(function (p) {
        return p.length > 0;
    });
    if (parts.length !== 1) {
        return '';
    }
    if (growbotProfilePathReservedSegments.indexOf(parts[0]) > -1) {
        return '';
    }
    return parts[0];
}

function growbotConvenienceAncestorExcluded(el) {
    return !!(el && el.closest && (el.closest('.Mr508') || el.closest('.XQXOT')));
}

function findProfileConvenienceAnchor() {
    var pathUser = getProfileUsernameFromPath();
    if (!pathUser) {
        return null;
    }
    var pathNorm = normalizeConvenienceUsername(pathUser);
    var header = document.querySelector('main header');
    if (!header) {
        return null;
    }
    var matches = [];
    var nodes = header.querySelectorAll('h1, h2, span');
    var i;
    for (i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (growbotConvenienceAncestorExcluded(el)) {
            continue;
        }
        if (normalizeConvenienceUsername(el.textContent) === pathNorm) {
            matches.push(el);
        }
    }
    if (matches.length === 0) {
        return null;
    }
    for (i = 0; i < matches.length; i++) {
        var innermost = true;
        var j;
        for (j = 0; j < matches.length; j++) {
            if (i !== j && matches[i].contains(matches[j])) {
                innermost = false;
                break;
            }
        }
        if (innermost) {
            return matches[i];
        }
    }
    return matches[0];
}

function profileConvenienceLinksExistForUsername(usernameNorm) {
    var count = 0;
    $('a.igBotInjectedLinkWhitelist, a.igBotInjectedLinkUnfollow').each(function () {
        if (normalizeConvenienceUsername($(this).attr('data-username')) === usernameNorm) {
            count++;
        }
    });
    return count >= 2;
}

function ensureProfileConvenienceLinks() {
    if (gblOptions.showConvenienceButtons == false) {
        return false;
    }
    var pathUser = getProfileUsernameFromPath();
    if (!pathUser) {
        return false;
    }
    var pathNorm = normalizeConvenienceUsername(pathUser);
    if (profileConvenienceLinksExistForUsername(pathNorm)) {
        return true;
    }
    var el = findProfileConvenienceAnchor();
    if (!el) {
        return false;
    }
    return addNewConvenienceLinks(el, {
        isProfile: true
    }) === true;
}

/** Inject after this node so convenience controls are not <a> inside Instagram's profile <a> (invalid; breaks clicks and nextAll). */
function growbotConvenienceAnchorToInjectAfter($usernameEl) {
    var $a = $usernameEl.closest('a[role="link"]').first();
    if ($a.length && $.contains($a[0], $usernameEl[0])) {
        return $a;
    }
    $a = $usernameEl.closest('a[href]').first();
    if ($a.length && $.contains($a[0], $usernameEl[0])) {
        var path = String($a.attr('href') || '').split('?')[0];
        if (/^\/[^/]+\/?$/.test(path)) {
            return $a;
        }
    }
    return $usernameEl;
}

function addNewConvenienceLinks(element, options) {

    options = options || {};

    if (gblOptions.showConvenienceButtons == false) return false;

    var $$this = $(element);

    if (!options.isProfile && $$this.children('div').length > 0) return false;
    if ($$this.parents('.Mr508').length > 0) return false;
    if ($$this.parents('.XQXOT').length > 0) return false;

    var username = $.trim($$this.text());
    if (!username) return false;
    var usernameNorm = normalizeConvenienceUsername(username);

    if (options.isProfile) {
        var pathNorm = normalizeConvenienceUsername(getProfileUsernameFromPath());
        if (pathNorm && usernameNorm !== pathNorm) {
            return false;
        }
    }

    var $injectAfter = growbotConvenienceAnchorToInjectAfter($$this);
    if ($injectAfter.nextAll('a.igBotInjectedLinkWhitelist').length > 0 && $injectAfter.nextAll('a.igBotInjectedLinkUnfollow').length > 0) {
        return true;
    }

    var safeUsername = String(username).replace(/"/g, '&quot;').replace(/</g, '&lt;');

    $injectAfter.after('<a class="igBotInjectedLinkWhitelist" href="javascript:void(0);" data-username="' + safeUsername + '">Whitelist</a> <a class="igBotInjectedLinkUnfollow" href="javascript:void(0);" data-username="' + safeUsername + '">Unfollow</a>');
    $$this.parents('.RqtMr').css({
        'max-width': 'initial'
    });

    return true;

}


async function convenienceLinkUnfollowAcct(userName) {
    var acct = await getAdditionalDataForAcct({
        username: userName
    });
    quickUnfollowAcct(acct);
}

async function convenienceLinkWhitelistAcct(userName) {
    var acct = await getAdditionalDataForAcct({
        username: userName
    });
    if (addAcctToWhiteList(acct) === true) saveWhiteListToStorage();
    $('.igBotInjectedLinkWhitelist[data-username="' + acct.username + '"]').fadeOut();
    $('.igBotInjectedLinkUnfollow[data-username="' + acct.username + '"]').fadeOut();
}

function waitForTrue(variableNames, callback, args) {
    var allTrue = true;
    var waitingFor = 'waiting for ';
    for (var i = 0; i < variableNames.length; i++) {
        if (window[variableNames[i]] === false) {
            allTrue = false;
            waitingFor = waitingFor + variableNames[i] + ' ';
        } else {
            waitingFor = waitingFor.replace(variableNames[i], '');
        }
    }

    if (allTrue === true) {
        printMessage(chrome.i18n.getMessage('Done'));
        callback.apply(this, args);
    } else {
        timeoutsQueue.push(setTimeout(function () {
            waitForTrue(variableNames, callback, args);
        }, 1000));
    }

}

function waitForElement(query, parent, callback, reenable) {
    const observer = new MutationObserver((mutations, obs) => {
        var elementToObserve = document.querySelectorAll(query)[0];
        if (elementToObserve) {
            callback();

            if (reenable == true) {
                setTimeout(function () {
                    obs.observe(parent, {
                        childList: true,
                        subtree: true
                    });
                }, 1000);
            }

            obs.disconnect();
            return;
        }
    });

    observer.observe(parent, {
        childList: true,
        subtree: true
    });

}

function loadOptions() {
    chrome.storage.local.get("gblOptions", function (data) {
        if (typeof data.gblOptions != 'undefined') {
            gblOptions = data.gblOptions;

            if (typeof gblOptions.filterOptions == 'undefined') {
                gblOptions.filterOptions = defaultFilterOptions;
            }

            // para opções recém-adicionadas: definir gblOptions.xxxx com o valor padrão se .xxxx não estava nas opções salvas anteriormente
            for (var key in defaultOptions) {
                if (gblOptions.hasOwnProperty(key) === false) {
                    gblOptions[key] = defaultOptions[key];
                }
            }

            // Config v4: tempo mínimo de 180 segundos entre as ações principais
            // (se a config salva tinha menos que 180s, sobe para 180s)
            if (!gblOptions.configVersion || gblOptions.configVersion < 4) {
                if (gblOptions.timeDelay < 180000) gblOptions.timeDelay = 180000;
                saveOptions();
                gblOptions.configVersion = 4;
            }

            // para opções de filtro recém-adicionadas: definir gblOptions.filterOptions.xxxx com o valor padrão se .xxxx não estava nas opções de filtro salvas anteriormente
            for (var key in defaultFilterOptions) {
                if (gblOptions.filterOptions.hasOwnProperty(key) === false) {
                    gblOptions.filterOptions[key] = defaultFilterOptions[key];
                }
            }

            document.getElementById('textSecondsBetweenActions').value = gblOptions.timeDelay / 1000;
            document.getElementById('textSecondsAfterSkip').value = gblOptions.timeDelayAfterSkip / 1000;
            document.getElementById('textMinutesAfterSoftRateLimit').value = gblOptions.timeDelayAfterSoftRateLimit / 60000;
            document.getElementById('textMinutesAfter429RateLimit').value = gblOptions.timeDelayAfter429RateLimit / 60000;
            document.getElementById('textHoursAfterHardRateLimit').value = gblOptions.timeDelayAfterHardRateLimit / 3600000;
            document.getElementById('texttimeDelayAfterAdditionalInfo').value = gblOptions.timeDelayAfterAdditionalInfo / 1000;
            document.getElementById('textRetryAfterAdditionalInfo404').value = Number(gblOptions.retriesAfterAdditionalInfo404);
            document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked = gblOptions.useTimeDelayAfterAdditionalInfo;
            document.getElementById('cbRandomizeTimeDelay').checked = gblOptions.useRandomTimeDelay;
            document.getElementById('cbFollowPrivateAccounts').checked = gblOptions.followPrivateAccounts;
            document.getElementById('cbFilterNonPrivate').checked = gblOptions.filterOptions.non_private;
            document.getElementById('cbFilterVerified').checked = gblOptions.filterOptions.verified;
            document.getElementById('cbFilterNonVerified').checked = gblOptions.filterOptions.non_verified;
            document.getElementById('cbFilterBusiness').checked = gblOptions.filterOptions.is_business_account;
            document.getElementById('cbFilterNonBusiness').checked = gblOptions.filterOptions.non_is_business_account;
            document.getElementById('cbFilterJoinedRecently').checked = gblOptions.filterOptions.is_joined_recently;
            document.getElementById('cbFilterNonJoinedRecently').checked = gblOptions.filterOptions.non_is_joined_recently;
            document.getElementById('cbFollowsMe').checked = gblOptions.filterOptions.follows_me;
            document.getElementById('cbNonFollowsMe').checked = gblOptions.filterOptions.non_follows_me;
            document.getElementById('cbFollowedByMe').checked = gblOptions.filterOptions.followed_by_me;
            document.getElementById('cbNonFollowedByMe').checked = gblOptions.filterOptions.non_followed_by_me;
            document.getElementById('cbFilterNoProfilePic').checked = gblOptions.filterOptions.no_profile_pic;
            document.getElementById('cbFilterProfilePic').checked = gblOptions.filterOptions.profile_pic;
            document.getElementById('cbApplyFilterAutomatically').checked = gblOptions.filterOptions.applyFiltersAutomatically;
            document.getElementById('igBotPercentRandomTimeDelay').value = gblOptions.percentRandomTimeDelay * 200;
            document.getElementById('cbDontUnfollowFollowers').checked = gblOptions.dontUnFollowFollowers;
            document.getElementById('cbDontUnfollowNonGrowbot').checked = gblOptions.dontUnFollowNonGrowbot;
            document.getElementById('cbDontUnfollowFilters').checked = gblOptions.dontUnFollowFilters;
            document.getElementById('cbDontRemoveOrBlockFilters').checked = gblOptions.dontRemoveOrBlockFilters;
            document.getElementById('cbDontUnfollowFresh').checked = !gblOptions.unFollowFresh;
            document.getElementById('cbUnfollowOld').checked = gblOptions.unFollowIfOld;
            document.getElementById('textUnfollowNew').value = gblOptions.unFollowDelay / 86400000;
            document.getElementById('textUnfollowOld').value = gblOptions.unFollowIfOlderThan / 86400000;
            document.getElementById('cbLimitQueueSize').checked = gblOptions.limitQueue;
            document.getElementById('txtLimitQueueSize').value = gblOptions.maxAcctQueueLength;
            document.getElementById('cbLimitMediaQueueSize').checked = gblOptions.limitMediaQueue;
            document.getElementById('txtLimitMediaQueueSize').value = gblOptions.maxMediaQueueLength;
            document.getElementById('numberFollowLikeLatestPics').value = gblOptions.numberFollowLikeLatestPics || 1;
            document.getElementById('cbRemoveFromQueue').checked = gblOptions.removeAccountsFromQueue;
            document.getElementById('cbAutoSaveQueue').checked = gblOptions.autoSaveQueue;
            document.getElementById('cbShowStamps').checked = gblOptions.showStamps;
            document.getElementById('cbShowProfilePicInQueue').checked = gblOptions.showProfilePicInQueue;
            document.getElementById('cbConvenienceLinks').checked = gblOptions.showConvenienceButtons;
            document.getElementById('cbFollowAlreadyAttempted').checked = gblOptions.followPeopleAlreadyAttempted;
            document.getElementById('cbShowLikesInQueue').checked = gblOptions.showLikesInQueue;
            document.getElementById('cbShowQueueOnScreen').checked = gblOptions.cbShowQueueOnScreen;
            document.getElementById('cbRemoveUnusedColumns').checked = gblOptions.cbRemoveUnusedColumns;
            document.getElementById('cbClickNotNow').checked = gblOptions.clickNotNow;
            document.getElementById('cbLoadQueueOnStartup').checked = gblOptions.loadQueueOnStartup;
            document.getElementById('cbLimitActions').checked = gblOptions.maxPerEnabled;
            document.getElementById('textLimitActionsPer').value = gblOptions.maxPerActions;
            document.getElementById('textLimitActionsPerTime').value = gblOptions.maxPerPeriod / 3600000;
            document.getElementById('cbGetExtendedData').checked = gblOptions.getExtendedData;
            document.getElementById('cbGetLastPostDate').checked = gblOptions.getLastPostDate;
            document.getElementById('cbFilterBioContains').checked = gblOptions.filterOptions.bio_contains;
            document.getElementById('cbFilterBioNotContains').checked = gblOptions.filterOptions.bio_not_contains;
            document.getElementById('txtFilterBioContains').value = gblOptions.filterOptions.bio_contains_text;
            document.getElementById('txtFilterBioNotContains').value = gblOptions.filterOptions.bio_not_contains_text;
            document.getElementById('cbFilterExternalUrlContains').checked = gblOptions.filterOptions.external_url_contains;
            document.getElementById('cbFilterExternalUrlNotContains').checked = gblOptions.filterOptions.external_url_not_contains;
            document.getElementById('txtFilterExternalUrlContains').value = gblOptions.filterOptions.external_url_contains_text;
            document.getElementById('txtFilterExternalUrlNotContains').value = gblOptions.filterOptions.external_url_not_contains_text;
            document.getElementById('cbFilterBusinessCategoryNameContains').checked = gblOptions.filterOptions.business_category_name_contains;
            document.getElementById('cbFilterBusinessCategoryNameNotContains').checked = gblOptions.filterOptions.business_category_name_not_contains;
            document.getElementById('txtFilterBusinessCategoryNameContains').value = gblOptions.filterOptions.business_category_name_contains_text;
            document.getElementById('txtFilterBusinessCategoryNameNotContains').value = gblOptions.filterOptions.business_category_name_not_contains_text;
            document.getElementById('cbMediaIncludeLikersCommentersTagged').checked = gblOptions.MediaIncludeLikersCommentersTagged;
            document.getElementById('SaveWhenWatchingReel').checked = gblOptions.SaveWhenWatchingReel;
            document.getElementById('LikeWhenWatchingReel').checked = gblOptions.LikeWhenWatchingReel;
            document.getElementById('includeSuggestedPostsFromFeed').checked = gblOptions.includeSuggestedPostsFromFeed;
            document.getElementById('includePinnedPostForLikes').checked = gblOptions.includePinnedPostForLikes;
            document.getElementById('includePinnedPostForComments').checked = gblOptions.includePinnedPostForComments;
            if (document.getElementById('numberLoadPostsFromAccounts')) document.getElementById('numberLoadPostsFromAccounts').value = gblOptions.numberLoadPostsFromAccounts || 1;
            if (document.getElementById('includePinnedPostForAccountMedia')) document.getElementById('includePinnedPostForAccountMedia').checked = gblOptions.includePinnedPostForAccountMedia !== false;

            if(gblOptions.dmConfig) {
                if(document.getElementById('txtDmTargetProfile')) document.getElementById('txtDmTargetProfile').value = gblOptions.dmConfig.txtDmTargetProfile || "";
                if(document.getElementById('txtDmTemplateTarget')) document.getElementById('txtDmTemplateTarget').value = gblOptions.dmConfig.txtDmTemplateTarget || "";
            }

            if(document.getElementById('txtActionTargetProfile')) document.getElementById('txtActionTargetProfile').value = gblOptions.txtActionTargetProfile || "";
            if(document.getElementById('txtActionTargetCount')) document.getElementById('txtActionTargetCount').value = gblOptions.txtActionTargetCount || 10;
            if(document.getElementById('txtActionTargetComments')) document.getElementById('txtActionTargetComments').value = gblOptions.txtActionTargetComments || "";

            $('#paginationLimit option:selected').attr("selected", null);
            $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");
            $('#paginationLimit').trigger('change');

            $('li.' + gblOptions.lastTab + ' label').click();

            if (typeof gblOptions.ui == 'undefined' || gblOptions.ui.length == 0) {
                [...document.getElementsByTagName('details')].forEach((detailsEl) => {
                    detailsEl.setAttribute('open', true)
                });
            } else {
                gblOptions.ui.forEach((detailsOpt) => {
                    if (detailsOpt.open == true) {
                        var el = document.getElementById(detailsOpt.id);
                        if (el) el.setAttribute('open', true);
                    }
                });
            }

        }

        if (typeof gblOptions.filterOptions == 'undefined') {
            gblOptions.filterOptions = defaultFilterOptions;
        }

        if (typeof gblOptions.queueColumns == 'undefined') {
            gblOptions.queueColumns = gbDefaultColumns;
        }

        for (var i = 0; i < gbDefaultColumns.length; i++) {

            var hasObj = false;
            for (var j = 0; j < gblOptions.queueColumns.length; j++) {
                if (gblOptions.queueColumns[j].data == gbDefaultColumns[i].data) {
                    hasObj = true;

                    if (gbDefaultColumns[i].bool == true) {
                        gblOptions.queueColumns[j]["bool"] = true;
                    }

                }
            }

            if (hasObj == false) {
                gblOptions.queueColumns.push(gbDefaultColumns[i]);
            }

        }


        loadOptionsColumns();

        bindNoUiSliders();

        bindEvents();

    });
}


function loadOptionsColumns() {
    var queueColumnsOptions = document.getElementById('queueColumnsOptions');

    for (var i = 0; i < gblOptions.queueColumns.length; i++) {

        var qc = gblOptions.queueColumns[i];

        var vizString = '';
        var disabledString = '';

        if (qc.visible == true) vizString = ' checked="' + qc.visible + '"'
        if (qc.data == 'id' || qc.data == 'username') disabledString = ' disabled="disabled"'

        var columnCheckbox = elementFromString('<label for="cb_' + qc.data + '"><input type="checkbox" id="cb_' + qc.data + '"' + vizString + disabledString + '>' + qc.name + "</label>");

        queueColumnsOptions.appendChild(columnCheckbox);

    }
}

function elementFromString(string) {
    var div = document.createElement('DIV');
    div.innerHTML = string;
    return div.firstChild;
}


function setFilterIconOpacity() {
    if (gblOptions.filterOptions.applyFiltersAutomatically == true && $('#radioFollow').is(':checked') == true) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else if (gblOptions.dontUnFollowFilters == true && $('#radioUnFollow').is(':checked') == true) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else if (gblOptions.dontRemoveOrBlockFilters == true && ($('#radioRemoveFromFollowers').is(':checked') == true || $('#radioBlock').is(':checked') == true)) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else {
        document.getElementById('iconFilter').style.opacity = 0.5;
    }
}

function saveOptions() {

    gblOptions.filterOptions.applyFiltersAutomatically = document.getElementById('cbApplyFilterAutomatically').checked;
    gblOptions.filterOptions.private = document.getElementById('cbFollowPrivateAccounts').checked;
    gblOptions.filterOptions.non_private = document.getElementById('cbFilterNonPrivate').checked;
    gblOptions.filterOptions.verified = document.getElementById('cbFilterVerified').checked;
    gblOptions.filterOptions.non_verified = document.getElementById('cbFilterNonVerified').checked;
    gblOptions.filterOptions.follows_me = document.getElementById('cbFollowsMe').checked;
    gblOptions.filterOptions.non_follows_me = document.getElementById('cbNonFollowsMe').checked;
    gblOptions.filterOptions.followed_by_me = document.getElementById('cbFollowedByMe').checked;
    gblOptions.filterOptions.non_followed_by_me = document.getElementById('cbNonFollowedByMe').checked;
    gblOptions.filterOptions.is_joined_recently = document.getElementById('cbFilterJoinedRecently').checked;
    gblOptions.filterOptions.non_is_joined_recently = document.getElementById('cbFilterNonJoinedRecently').checked;
    gblOptions.filterOptions.is_business_account = document.getElementById('cbFilterBusiness').checked;
    gblOptions.filterOptions.non_is_business_account = document.getElementById('cbFilterNonBusiness').checked;
    gblOptions.filterOptions.bio_contains = document.getElementById('cbFilterBioContains').checked;
    gblOptions.filterOptions.bio_not_contains = document.getElementById('cbFilterBioNotContains').checked;
    gblOptions.filterOptions.bio_contains_text = document.getElementById('txtFilterBioContains').value;
    gblOptions.filterOptions.bio_not_contains_text = document.getElementById('txtFilterBioNotContains').value;
    gblOptions.filterOptions.external_url_contains = document.getElementById('cbFilterExternalUrlContains').checked;
    gblOptions.filterOptions.external_url_not_contains = document.getElementById('cbFilterExternalUrlNotContains').checked;
    gblOptions.filterOptions.external_url_contains_text = document.getElementById('txtFilterExternalUrlContains').value;
    gblOptions.filterOptions.external_url_not_contains_text = document.getElementById('txtFilterExternalUrlNotContains').value;
    gblOptions.filterOptions.no_profile_pic = document.getElementById('cbFilterNoProfilePic').checked;
    gblOptions.filterOptions.profile_pic = document.getElementById('cbFilterProfilePic').checked;
    gblOptions.filterOptions.business_category_name_contains = document.getElementById('cbFilterBusinessCategoryNameContains').checked;
    gblOptions.filterOptions.business_category_name_not_contains = document.getElementById('cbFilterBusinessCategoryNameNotContains').checked;
    gblOptions.filterOptions.business_category_name_contains_text = document.getElementById('txtFilterBusinessCategoryNameContains').value;
    gblOptions.filterOptions.business_category_name_not_contains_text = document.getElementById('txtFilterBusinessCategoryNameNotContains').value;


    var uiOptions = [];

    [...document.getElementsByTagName('details')].forEach((detailsEl) => {
        uiOptions.push({
            'id': detailsEl.id,
            'open': detailsEl.open ? true : false
        });
    });

    var filterOptions = gblOptions.filterOptions;
    var endcursors = gblOptions.endcursors;

    gblOptions.dontUnFollowFollowers = document.getElementById('cbDontUnfollowFollowers').checked;
    gblOptions.dontUnFollowNonGrowbot = document.getElementById('cbDontUnfollowNonGrowbot').checked;
    gblOptions.dontUnFollowFilters = document.getElementById('cbDontUnfollowFilters').checked;
    gblOptions.dontRemoveOrBlockFilters = document.getElementById('cbDontRemoveOrBlockFilters').checked;
    gblOptions.filterOptions = filterOptions;
    gblOptions.followPeopleAlreadyAttempted = document.getElementById('cbFollowAlreadyAttempted').checked;
    gblOptions.followPrivateAccounts = document.getElementById('cbFollowPrivateAccounts').checked;
    gblOptions.limitQueue = document.getElementById('cbLimitQueueSize').checked;
    gblOptions.limitMediaQueue = document.getElementById('cbLimitMediaQueueSize').checked;
    gblOptions.maxAcctQueueLength = parseInt(document.getElementById('txtLimitQueueSize').value);
    gblOptions.maxMediaQueueLength = parseInt(document.getElementById('txtLimitMediaQueueSize').value);
    gblOptions.numberFollowLikeLatestPics = document.getElementById('numberFollowLikeLatestPics').value;
    gblOptions.percentRandomTimeDelay = document.getElementById('igBotPercentRandomTimeDelay').value / 200;
    gblOptions.showLikesInQueue = document.getElementById('cbShowLikesInQueue').checked;
    gblOptions.clickNotNow = document.getElementById('cbClickNotNow').checked;
    gblOptions.loadQueueOnStartup = document.getElementById('cbLoadQueueOnStartup').checked;
    gblOptions.cbShowQueueOnScreen = document.getElementById('cbShowQueueOnScreen').checked;
    gblOptions.cbRemoveUnusedColumns = document.getElementById('cbRemoveUnusedColumns').checked;
    gblOptions.removeAccountsFromQueue = document.getElementById('cbRemoveFromQueue').checked;
    gblOptions.autoSaveQueue = document.getElementById('cbAutoSaveQueue').checked;
    gblOptions.showConvenienceButtons = document.getElementById('cbConvenienceLinks').checked;
    gblOptions.showStamps = document.getElementById('cbShowStamps').checked;
    gblOptions.showProfilePicInQueue = document.getElementById('cbShowProfilePicInQueue').checked;
    gblOptions.getExtendedData = document.getElementById('cbGetExtendedData').checked;
    gblOptions.getLastPostDate = document.getElementById('cbGetLastPostDate').checked;
    gblOptions.timeDelay = document.getElementById('textSecondsBetweenActions').value * 1000;
    gblOptions.timeDelayAfterHardRateLimit = document.getElementById('textHoursAfterHardRateLimit').value * 3600000;
    gblOptions.timeDelayAfterSkip = document.getElementById('textSecondsAfterSkip').value * 1000;
    gblOptions.timeDelayAfterSoftRateLimit = document.getElementById('textMinutesAfterSoftRateLimit').value * 60000;
    gblOptions.timeDelayAfter429RateLimit = document.getElementById('textMinutesAfter429RateLimit').value * 60000;
    gblOptions.timeDelayAfterAdditionalInfo = document.getElementById('texttimeDelayAfterAdditionalInfo').value * 1000;
    gblOptions.useTimeDelayAfterAdditionalInfo = document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked;
    gblOptions.retriesAfterAdditionalInfo404 = Number(document.getElementById('textRetryAfterAdditionalInfo404').value);
    gblOptions.ui = uiOptions;
    gblOptions.unFollowFresh = !document.getElementById('cbDontUnfollowFresh').checked;
    gblOptions.unFollowIfOld = document.getElementById('cbUnfollowOld').checked;
    gblOptions.unFollowDelay = parseInt(document.getElementById('textUnfollowNew').value) * 86400000;
    gblOptions.unFollowIfOlderThan = parseInt(document.getElementById('textUnfollowOld').value) * 86400000;
    gblOptions.useRandomTimeDelay = document.getElementById('cbRandomizeTimeDelay').checked;
    gblOptions.maxPerEnabled = document.getElementById('cbLimitActions').checked;
    gblOptions.maxPerActions = document.getElementById('textLimitActionsPer').value;
    gblOptions.maxPerPeriod = document.getElementById('textLimitActionsPerTime').value * 3600000;
    gblOptions.paginationLimit = $('#paginationLimit').val();
    gblOptions.mediapaginationLimit = $('#mediapaginationLimit').val();
    gblOptions.endcursors = endcursors;
    gblOptions.MediaIncludeLikersCommentersTagged = document.getElementById('cbMediaIncludeLikersCommentersTagged').checked;
    gblOptions.SaveWhenWatchingReel = document.getElementById('SaveWhenWatchingReel').checked;
    gblOptions.LikeWhenWatchingReel = document.getElementById('LikeWhenWatchingReel').checked;

    if(document.getElementById('txtActionTargetProfile')) gblOptions.txtActionTargetProfile = document.getElementById('txtActionTargetProfile').value;
    if(document.getElementById('txtActionTargetCount')) gblOptions.txtActionTargetCount = document.getElementById('txtActionTargetCount').value;
    if(document.getElementById('txtActionTargetComments')) gblOptions.txtActionTargetComments = document.getElementById('txtActionTargetComments').value;
    gblOptions.includeSuggestedPostsFromFeed = document.getElementById('includeSuggestedPostsFromFeed').checked;
    gblOptions.includePinnedPostForLikes = document.getElementById('includePinnedPostForLikes').checked;
    gblOptions.includePinnedPostForComments = document.getElementById('includePinnedPostForComments').checked;
    if (document.getElementById('numberLoadPostsFromAccounts')) gblOptions.numberLoadPostsFromAccounts = document.getElementById('numberLoadPostsFromAccounts').value;
    if (document.getElementById('includePinnedPostForAccountMedia')) gblOptions.includePinnedPostForAccountMedia = document.getElementById('includePinnedPostForAccountMedia').checked;

    gblOptions.dmConfig = {
        txtDmTargetProfile: document.getElementById('txtDmTargetProfile') ? document.getElementById('txtDmTargetProfile').value : "",
        txtDmTemplateTarget: document.getElementById('txtDmTemplateTarget') ? document.getElementById('txtDmTemplateTarget').value : ""
    };

    document.querySelectorAll('#detailsQueueColumns input').forEach((cb) => {
        var columnDataName = cb.id.replace('cb_', '');
        var columnObjIndex = gblOptions.queueColumns.findIndex(item => item.data == columnDataName);

        gblOptions.queueColumns[columnObjIndex].visible = cb.checked;
    });

    chrome.storage.local.set({
        gblOptions: gblOptions
    });

    // setFilterIconOpacity();
}


function loadPreviousAttempts() {
    chrome.storage.local.get("acctsAttempted", function (data) {
        if (Array.isArray(data.acctsAttempted)) {
            acctsPreviouslyAttempted = data.acctsAttempted;
            printMessage(chrome.i18n.getMessage('PreviouslyAttempted', [acctsPreviouslyAttempted.length]));

            acctsPreviouslyAttempted = cleanAcctsForStorage(acctsPreviouslyAttempted);
            chrome.storage.local.set({
                acctsAttempted: acctsPreviouslyAttempted
            }, function () { });;
        }
    })
}



function cleanAcctsForStorage(queueToOptimize) {
    var previousBytes = bytesFromString(JSON.stringify(queueToOptimize));

    for (var i = 0; i < queueToOptimize.length; i++) {
        var a = queueToOptimize[i];
        if (a.edge_felix_video_timeline) delete queueToOptimize[i].edge_felix_video_timeline;
        if (a.edge_felix_combined_post_uploads) delete queueToOptimize[i].edge_felix_combined_post_uploads;
        if (a.edge_felix_combined_draft_uploads) delete queueToOptimize[i].edge_felix_combined_draft_uploads;
        if (a.edge_felix_drafts) delete queueToOptimize[i].edge_felix_drafts;
        if (a.edge_felix_pending_draft_uploads) delete queueToOptimize[i].edge_felix_pending_draft_uploads;
        if (a.edge_felix_pending_post_uploads) delete queueToOptimize[i].edge_felix_pending_post_uploads;
        if (a.edge_saved_media) delete queueToOptimize[i].edge_saved_media;
        if (a.edge_media_collections) delete queueToOptimize[i].edge_media_collections;
        if (a.edge_owner_to_timeline_media && a.edge_owner_to_timeline_media.edges) queueToOptimize[i].edge_owner_to_timeline_media.edges = [];
    }

    var nowBytes = bytesFromString(JSON.stringify(queueToOptimize));
    var savedBytes = previousBytes - nowBytes;

    if (savedBytes > 0) {
        printMessage('Cleaned up accounts for storage and performance (saved ' + formatBytes(savedBytes) + ')');
    }

    return queueToOptimize;
}

function bytesFromString(str) {
    var bytes = 0,
        len = str.length,
        codePoint, next, i;

    for (i = 0; i < len; i++) {
        codePoint = str.charCodeAt(i);

        // Substitutos solitários não podem ser passados para encodeURI
        if (codePoint >= 0xD800 && codePoint < 0xE000) {
            if (codePoint < 0xDC00 && i + 1 < len) {
                next = str.charCodeAt(i + 1);

                if (next >= 0xDC00 && next < 0xE000) {
                    bytes += 4;
                    i++;
                    continue;
                }
            }
        }

        bytes += (codePoint < 0x80 ? 1 : (codePoint < 0x800 ? 2 : 3));
    }

    return bytes;
}

function formatBytes(bytes, decimals) {
    if (bytes == 0) return '0 Bytes';
    var k = 1024,
        dm = decimals <= 0 ? 0 : decimals || 2,
        sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function loadPreviousLikes() {
    chrome.storage.local.get("previousLikes", function (data) {
        if (Array.isArray(data.previousLikes)) {
            previousLikes = data.previousLikes;
            printMessage(chrome.i18n.getMessage('PreviouslyLiked', [previousLikes.length]));
        }
    })
}

function savePreviousLikesToStorage() {
    chrome.storage.local.set({
        previousLikes: previousLikes
    });
}

function addAcctToWhiteList(acct) {
    var acctInWhiteList = findAcctById(acct.id, acctsWhiteList);
    if (acct !== false && acctInWhiteList == false) {
        acctsWhiteList.push(acct);
        printMessage(acct.username + chrome.i18n.getMessage('AddedToWhitelist'));
        return true;
    } else {
        printMessage(acct.username + chrome.i18n.getMessage('AlreadyOnWhitelist'));
        return false;
    }
}

function loadWhiteList() {
    chrome.storage.local.get("acctsWhiteList", function (data) {
        if (Array.isArray(data.acctsWhiteList)) {
            acctsWhiteList = data.acctsWhiteList;
            printMessage(chrome.i18n.getMessage('WhitelistLoaded', [acctsWhiteList.length]));
        }
    })
}

function saveWhiteListToStorage() {
    chrome.storage.local.set({
        acctsWhiteList: acctsWhiteList
    });
    printMessage(chrome.i18n.getMessage('WhitelistSavedLocal'));
}

function saveWhiteListToDisk() {
    saveText("growbot-whitelist.txt", JSON.stringify(acctsWhiteList));
    printMessage(chrome.i18n.getMessage('WhitelistSavedFile'));
}

function saveWhiteListToStorageAndDisk() {
    saveWhiteListToStorage();
    saveWhiteListToDisk();
}

function saveText(filename, text) {
    var blob = new Blob([text], {
        type: "text/plain;charset=utf-8"
    });
    saveAs(blob, filename);
}

function viewWhiteList() {
    if (acctsWhiteList.length > 0) {

        dialog({
            yes: chrome.i18n.getMessage('WhitelistLoadFile'),
            no: chrome.i18n.getMessage('WhitelistLoadLocal'),
            question: chrome.i18n.getMessage('WhitelistLoadQuestion')
        },
            function () {
                openWhiteListFile()
            },
            function () {
                currentList = 'acctsWhiteList';
                arrayOfUsersToDiv(acctsWhiteList, true);
                $('#btnSaveWhiteList').show();
            });

    } else {
        openWhiteListFile();
    }
}

function openWhiteListFile() {
    var input = document.createElement("input");
    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'text/plain,text/json,application/JSON');

    input.addEventListener("change", function () {
        if (this.files && this.files[0]) {
            var myFile = this.files[0];
            var reader = new FileReader();

            reader.addEventListener('load', function (e) {
                acctsWhiteList = JSON.parse(e.target.result);
                currentList = 'acctsWhiteList';
                arrayOfUsersToDiv(acctsWhiteList, true);
            });

            reader.readAsText(myFile);
        }
    });

    input.click();
}



function openQueueFile() {
    var input = document.createElement("input");
    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'text/plain,text/json,application/JSON');

    input.addEventListener("change", function () {
        if (this.files && this.files[0]) {
            var myFile = this.files[0];
            var reader = new FileReader();

            reader.addEventListener('load', function (e) {
                var fileData = e.target.result;

                if (fileData.indexOf('relationships_follow_requests_sent') > -1) {
                    var fileJSON = JSON.parse(e.target.result);
                    var pendingArray = fileJSON.relationships_follow_requests_sent;

                    for (var i = 0; i < pendingArray.length; i++) {

                        if (pendingArray[i].string_list_data &&
                            pendingArray[i].string_list_data.length > 0 &&
                            pendingArray[i].string_list_data[0].value) {

                            acctsQueue.push({
                                "username": pendingArray[i].string_list_data[0].value
                            });
                        }
                    }

                    alert('Loaded partial queue from list of usernames.  Before Growbot can use this queue, you will need to process the queue with Get More Data selected.');

                } else if (fileData.indexOf('{') > -1) {
                    // JSON
                    acctsQueue = JSON.parse(e.target.result);
                    currentList = 'acctsQueue';

                    if (acctsQueue.length > gblOptions.maxAcctQueueLength &&
                        gblOptions.limitQueue == true &&
                        window.confirm('Saved queue has ' + acctsQueue.length + ' accounts, limit to first ' + gblOptions.maxAcctQueueLength + ' accounts?')) {

                        truncateQueue();
                    }

                    acctsQueue = cleanAcctsForStorage(acctsQueue);

                } else if (fileData.indexOf(',') > -1 || fileData.indexOf('\n') > -1 || fileData.indexOf('\r') > -1) {
                    // o arquivo tem quebras de linha ou vírgulas mas não tem {
                    // limpar quebras de linha do windows, quebras duplas, substituir quebras com vírgula, analisar como csv
                    fileData = fileData.replace(/\r/g, '\n');
                    fileData = fileData.replace(/\n\n/g, '\n');
                    fileData = fileData.replace(/\n/g, ',');
                    fileData = fileData.replace(/,,/g, ',');

                    var arrr = fileData.split(',');
                    for (var i = 0; i < arrr.length; i++) {
                        acctsQueue.push({
                            "username": arrr[i]
                        });
                    }

                    alert('Loaded partial queue from list of usernames.  Before Growbot can use this queue, you will need to process the queue with Get More Data selected.');
                } else {
                    alert("Error: Can't load queue file, are you sure this is a Growbot queue?");
                }

                acctsQueue = fixAcctQueueCounts(acctsQueue);


                arrayOfUsersToDiv(acctsQueue, true);

            });

            reader.readAsText(myFile);
        }
    });

    input.click();
}



function loadSavedQueue() {
    chrome.storage.local.get("acctsQueue", function (data) {
        if (Array.isArray(data.acctsQueue)) {

            dialog({
                no: chrome.i18n.getMessage('QueueLoadFile'),
                yes: chrome.i18n.getMessage('QueueLoadLocal'),
                question: chrome.i18n.getMessage('QueueLoadQuestion')
            },
                function () {
                    acctsQueue = data.acctsQueue;

                    if (acctsQueue.length > gblOptions.maxAcctQueueLength &&
                        gblOptions.limitQueue == true &&
                        window.confirm('Saved queue has ' + acctsQueue.length + ' accounts, limit to first ' + gblOptions.maxAcctQueueLength + ' accounts?')) {

                        truncateQueue();
                    }

                    arrayOfUsersToDiv(acctsQueue, true);

                    printMessage(chrome.i18n.getMessage('QueueLoaded', [acctsQueue.length]));
                },
                function () {
                    openQueueFile();
                })
        } else {
            openQueueFile();
        }
    });
}


function loadQueueFromLocal() {
    chrome.storage.local.get("acctsQueue", function (data) {
        if (Array.isArray(data.acctsQueue)) {

            acctsQueue = JSON.parse(JSON.stringify(data.acctsQueue));

            acctsQueue = fixAcctQueueCounts(acctsQueue);

            arrayOfUsersToDiv(acctsQueue, true);

            printMessage(chrome.i18n.getMessage('QueueLoaded', [acctsQueue.length]));
        }
    });
}


function fixAcctQueueCounts(q) {

    var newArr = [];

    for (var i = 0; i < q.length; i++) {

        var newq = q[i];

        // if (q[i]["edge_owner_to_timeline_media.count"]) {
        if (q[i]["edge_owner_to_timeline_media.count"]) {
            newq.edge_owner_to_timeline_media = {
                "count": q[i]["edge_owner_to_timeline_media.count"]
            }
            delete newq["edge_owner_to_timeline_media.count"];
        } else {
            newq.edge_owner_to_timeline_media = {
                "count": 0
            }

        }
        // }

        //  if (q[i]["edge_followed_by.count"]) {
        if (q[i]["edge_followed_by.count"]) {
            newq["edge_followed_by"] = {
                "count": q[i]["edge_followed_by.count"]
            }
            delete newq["edge_followed_by.count"]

        }
        //  }

        //   if (q[i]["edge_follow.count"]) {
        if (q[i]["edge_follow.count"]) {
            newq["edge_follow"] = {
                "count": q[i]["edge_follow.count"]
            }
            delete newq["edge_follow.count"]
        }
        //   }

        // if (q[i]["edge_mutual_followed_by.count"]) {
        if (q[i]["edge_mutual_followed_by.count"]) {
            newq["edge_mutual_followed_by"] = {
                "count": q[i]["edge_mutual_followed_by.count"]
            }
            delete newq["edge_mutual_followed_by.count"]
        } else {
            newq["edge_mutual_followed_by"] = {
                "count": 0
            }
        }
        // }

        newArr.push(JSON.parse(JSON.stringify(newq)))

    }


    return newArr;

}


function generateFileName() {
    var fileName = "growbot";

    var endCursorsForThisPage = gblOptions.endcursors;

    endCursorsForThisPage = endCursorsForThisPage.filter(e => e.id === currentProfilePage.id);

    if (endCursorsForThisPage.length > 0) {
        var p = endCursorsForThisPage[endCursorsForThisPage.length - 1];
        fileName = fileName + '-' + p.username;
        fileName = fileName + '-' + p.action.replace('load', '').toLowerCase();
    } else {
        fileName = fileName + '-' + 'queue';
    }


    return fileName;
}

function saveQueueToDisk() {
    saveText(generateFileName() + ".txt", JSON.stringify(acctsQueue));
    printMessage(chrome.i18n.getMessage('QueueSavedFile'));
}

function saveQueueToStorage() {
    chrome.storage.local.set({
        acctsQueue: acctsQueue
    }, function () {
        printMessage(chrome.i18n.getMessage('QueueSavedLocal'));
    });
}

function saveQueueToStorageAndDisk() {
    saveQueueToStorage();
    saveQueueToDisk();
}



function initUnfollowMyFollowers() {
    if (acctsQueue.length === 0 && window.confirm('Queue empty, load your following and begin unfollowing?') === true) {
        ajaxGetAllMyFollowing('');
        waitForTrue(['loadedMyFollowings'], ajaxUnfollowAll, []);
    } else {
        ajaxUnfollowAll();
    }
}


async function ajaxLoadUsersMedia(after, loadAllMedia, callback, acct) {

    if (!acct) acct = currentProfilePage;
    if (!acct || !acct.username) {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var fetchMedia = null;
    try {
        fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "129477",
                "x-csrftoken": getCsrfFromCookie(),
                "x-fb-friendly-name": "PolarisProfilePostsQuery",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + acct.username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + acct.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });
    } catch (e) {
        outputMessage('Failed to load posts: ' + (e && e.message || e));
        return false;
    }

    var parsed = await igSafeTimelineJson(fetchMedia);
    if (!parsed.ok) {
        outputMessage('Failed to load posts: ' + parsed.message);
        return false;
    }
    var jsonData = parsed.data;
    var r = jsonData && jsonData.data && jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;
    if (!r) {
        outputMessage('Failed to load posts: unexpected response');
        return false;
    }

    r.acct = acct;
    callback(r);
}


async function ajaxLoadAllUsersCommenters(after) {

    if (!currentProfilePage || !currentProfilePage.username) {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }
    if (currentProfilePage.is_private === true && currentProfilePage.followed_by_viewer === false) {
        outputMessage('Skipping ' + currentProfilePage.username + ': private account (do not try to load media for private accounts)');
        return false;
    }

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var fetchMedia = null;
    try {
        fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "129477",
                "x-csrftoken": getCsrfFromCookie(),
                "x-fb-friendly-name": "PolarisProfilePostsQuery",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + currentProfilePage.username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + currentProfilePage.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });
    } catch (e) {
        outputMessage('Failed to load posts for commenters: ' + (e && e.message || e));
        return false;
    }

    var parsed = await igSafeTimelineJson(fetchMedia);
    if (!parsed.ok) {
        outputMessage('Failed to load posts for commenters: ' + parsed.message);
        return false;
    }
    var jsonData = parsed.data;
    var r = jsonData && jsonData.data && jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;
    if (!r) {
        outputMessage('Failed to load posts for commenters: unexpected response');
        return false;
    }
    outputMessage('Loaded ' + (r.edges ? r.edges.length : 0) + ' posts for commenters of ' + currentProfilePage.username);

    loadCommentsForMedia(r);
}


async function loadMoreCommentsForMedia2(media, nextMinId) {

    return new Promise(async function (resolve, reject) {

        try {
            var mediaId = media.id || media.pk || '';
            if (String(mediaId).indexOf('_') > -1) mediaId = String(mediaId).split('_')[0];
            var url = "https://www.instagram.com/api/v1/media/" + mediaId + "/comments/?can_support_threading=true&permalink_enabled=false";

            if (nextMinId && nextMinId !== 0) {
                url = url + '&min_id=' + encodeURIComponent(nextMinId);
            }

            const fetchComments = await fetch(url, {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "priority": "u=1, i",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "x-asbd-id": "129477",
                    "x-csrftoken": getCsrfFromCookie(),
                    "x-ig-app-id": "936619743392459",
                    "x-requested-with": "XMLHttpRequest"
                },
                "referrer": "https://www.instagram.com/p/DB1UCFKuS8u/",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET",
                "mode": "cors",
                "credentials": "include"
            });
            var parsed = await igSafeTimelineJson(fetchComments);
            if (!parsed.ok) {
                outputMessage('Failed loading comments (HTTP bloqueado): ' + parsed.message);
                if (!media.comments) media.comments = [];
                media.nextMinId = 0;
                resolve(media);
                return;
            }
            var jsonData = parsed.data;
        var c = jsonData.comments;
        media.nextMinId = jsonData.next_min_id || 0;

        if (media.comments) {

        } else {
            media.comments = [];
        }

        for (var i = 0; i < c.length; i++) {
            media.comments.push(c[i]);
        }


        resolve(media);
        } catch (e) {
            outputMessage('Failed loading comments: ' + (e && e.message || e));
            if (!media.comments) media.comments = [];
            media.nextMinId = 0;
            resolve(media);
        }
    });

}

async function loadCommentsForMedia(r) {
    for (var i = 0; i < r.edges.length; i++) {

        var media = r.edges[i];

        if (gblOptions.includePinnedPostForComments == false && media.node.timeline_pinned_user_ids.length > 0) continue;

        var mediaWithComments = await loadMoreCommentsForMedia2(media.node);

        for (j = 0; j < (mediaWithComments.comment_count / 1); j++) {

            if (mediaWithComments.comment_count > 0 &&
                mediaWithComments.comments &&
                mediaWithComments.comments.length < mediaWithComments.comment_count &&
                mediaWithComments.nextMinId &&
                mediaWithComments.nextMinId !== 0) {

                mediaWithComments = await loadMoreCommentsForMedia2(mediaWithComments, mediaWithComments.nextMinId);

            } else {
                break;
            }

            var users = allNodes(mediaWithComments.comments, 'user');
            for (var k = 0; k < users.length; k++) {
                var u = users[k];
                acctsQueue.push(u);
            }

            acctsQueue = uniq(acctsQueue);

            mediaToLike.push(media.node);


            arrayOfUsersToDiv(acctsQueue, true);
            arrayOfMediaToDiv(mediaToLike, true);

            if ((gblOptions.limitQueue == true && acctsQueue.length > gblOptions.maxAcctQueueLength)) {
                printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
                return false;
            }

        }

        outputMessage('Loaded ' + mediaWithComments.comments.length + '/' + mediaWithComments.comment_count + ' comments for post ' + (i + 1) + '/' + r.edges.length);

    }

    if ((gblOptions.limitQueue == true && acctsQueue.length > gblOptions.maxAcctQueueLength)) {
        arrayOfUsersToDiv(acctsQueue, true);
        printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
        return false;
    }

    if (r.page_info.has_next_page == true) {
        outputMessage('waiting 2 seconds to load the next batch of posts for comments');
        timeoutsQueue.push(setTimeout(function () {
            ajaxLoadAllUsersCommenters(r.page_info.end_cursor);
        }, 2000));
    } else {
        printMessage(chrome.i18n.getMessage('Done'));
    }
}

async function ajaxLoadAllUsersLikers(after) {
    if (!currentProfilePage || !currentProfilePage.username) {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }
    if (currentProfilePage.is_private === true && currentProfilePage.followed_by_viewer === false) {
        outputMessage('Skipping ' + currentProfilePage.username + ': private account (do not try to load media for private accounts)');
        return false;
    }
    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var fetchMedia = null;
    try {
        fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "129477",
                "x-csrftoken": getCsrfFromCookie(),
                "x-fb-friendly-name": "PolarisProfilePostsQuery",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + currentProfilePage.username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + currentProfilePage.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });
    } catch (e) {
        outputMessage('Failed to load posts for likers: ' + (e && e.message || e));
        return false;
    }

    var parsed = await igSafeTimelineJson(fetchMedia);
    if (!parsed.ok) {
        outputMessage('Failed to load posts for likers: ' + parsed.message);
        return false;
    }
    var jsonData = parsed.data;
    var r = jsonData && jsonData.data && jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;
    if (!r) {
        outputMessage('Failed to load posts for likers: unexpected response');
        return false;
    }
    outputMessage('Loaded ' + (r.edges ? r.edges.length : 0) + ' posts for likers of ' + currentProfilePage.username);

    beginLoadLikesForMedia(r);

}


async function loadLikesForQueueMedia() {
    for (var j = 0; j < likers.length; j++) {
        if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
            if (findAcctById(likers[j].id, acctsQueue) === false) {
                acctsQueue.push(likers[j]);
            }
        } else {

            arrayOfUsersToDiv(acctsQueue, true);
            arrayOfMediaToDiv(mediaToLike, true);

            printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
            return false;
        }
    }
}


async function beginLoadLikesForMedia(r) {

    for (var i = 0; i < r.edges.length; i++) {
        var media = r.edges[i];

        if (gblOptions.includePinnedPostForLikes == false && media.node.timeline_pinned_user_ids.length > 0) continue;

        mediaToLike.push(media.node);

        let likers = await loadLikesForMedia(media);

        for (var j = 0; j < likers.length; j++) {
            if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
                if (findAcctById(likers[j].id, acctsQueue) === false) {
                    acctsQueue.push(likers[j]);
                }
            } else {

                arrayOfUsersToDiv(acctsQueue, true);
                arrayOfMediaToDiv(mediaToLike, true);

                printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
                return false;
            }
        }

    }

    arrayOfUsersToDiv(acctsQueue, false);
    arrayOfMediaToDiv(mediaToLike, false);

    if (r.page_info.has_next_page == true) {
        outputMessage('waiting 2 seconds to load more media for likes');
        timeoutsQueue.push(setTimeout(function () {
            ajaxLoadAllUsersLikers(r.page_info.end_cursor);
        }, 2000));
    } else {
        printMessage(chrome.i18n.getMessage('Done'));
    }
}

function resolveCurrentPageUsernameForUi() {
    if (currentProfilePage != false && currentProfilePage && currentProfilePage.username) {
        return currentProfilePage.username;
    }
    try {
        if (typeof getProfileUsernameFromPath === 'function') {
            var p = getProfileUsernameFromPath();
            if (p) return p;
        }
    } catch (e) {}
    return '';
}

async function ajaxLoadPostsFromAccountPage(after) {
    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var username = resolveCurrentPageUsernameForUi();
    if (username == '') {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }

    var count = '??';
    if (gblOptions.limitMediaQueue == true && !isNaN(document.getElementById('txtLimitMediaQueueSize').value)) {
        count = document.getElementById('txtLimitMediaQueueSize').value;
    }

    document.getElementById('btnLoadPostsFromAccountPage').classList.add('pulsing');

    var fetchMedia = null;
    try {
        fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "129477",
                "x-csrftoken": getCsrfFromCookie(),
                "x-fb-friendly-name": "PolarisProfilePostsQuery",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });
    } catch (e) {
        document.getElementById('btnLoadPostsFromAccountPage').classList.remove('pulsing');
        outputMessage('Falha ao carregar posts de @' + username + ': ' + (e && e.message || e));
        return false;
    }

    var parsed = await igSafeTimelineJson(fetchMedia);
    if (!parsed.ok) {
        document.getElementById('btnLoadPostsFromAccountPage').classList.remove('pulsing');
        outputMessage('Falha ao carregar posts de @' + username + ': ' + parsed.message);
        return false;
    }
    var r = parsed.data && parsed.data.data && parsed.data.data.xdt_api__v1__feed__user_timeline_graphql_connection;

    if (!r || !r.edges) {
        document.getElementById('btnLoadPostsFromAccountPage').classList.remove('pulsing');
        outputMessage('Falha ao carregar posts de @' + username + ': resposta inesperada');
        return false;
    }

    for (var i = 0; i < r.edges.length; i++) {
        var media = r.edges[i];

        if (gblOptions.includePinnedPostForAccountMedia == false && media.node.timeline_pinned_user_ids.length > 0) continue;

        if (gblOptions.limitMediaQueue == true && mediaToLike.length >= gblOptions.maxMediaQueueLength) {
            arrayOfMediaToDiv(mediaToLike, false);
            document.getElementById('btnLoadPostsFromAccountPage').classList.remove('pulsing');
            printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
            return false;
        }

        mediaToLike.push(media.node);
    }

    arrayOfMediaToDiv(mediaToLike, false);

    if (r.page_info.has_next_page == true && (gblOptions.limitMediaQueue == false || mediaToLike.length < gblOptions.maxMediaQueueLength)) {
        outputMessage(mediaToLike.length + ' posts de @' + username + ' na fila de mídia.');
        timeoutsQueue.push(setTimeout(function () {
            ajaxLoadPostsFromAccountPage(r.page_info.end_cursor);
        }, 2000));
    } else {
        document.getElementById('btnLoadPostsFromAccountPage').classList.remove('pulsing');
        printMessage(chrome.i18n.getMessage('Done'));
    }
}

async function growbotFetchUserTimelineEdges(acct) {
    if (!acct || !acct.username) return [];

    var restItems = acct.edge_owner_to_timeline_media && acct.edge_owner_to_timeline_media.edges;
    if (restItems && restItems.length) {
        return restItems.map(function (item) { return { node: item.node || item }; });
    }
    try {
        await getTimelineForAcct(acct);
        restItems = acct.edge_owner_to_timeline_media && acct.edge_owner_to_timeline_media.edges;
        if (restItems && restItems.length) {
            return restItems.map(function (item) { return { node: item.node || item }; });
        }
    } catch (e) {}

    try {
        var timeline = await new Promise(function (resolve) {
            ajaxLoadUsersMedia('', false, resolve, acct);
        });
        if (timeline && timeline.edges && timeline.edges.length) {
            if (!acct.edge_owner_to_timeline_media) {
                acct.edge_owner_to_timeline_media = { count: timeline.edges.length, edges: [] };
            }
            acct.edge_owner_to_timeline_media.edges = timeline.edges.map(function (e) { return e.node || e; });
            return timeline.edges;
        }
    } catch (e) {}
    return [];
}

async function loadPostsFromAccountsQueue() {
    if (acctsQueue.length === 0) {
        printMessage('Fila de contas vazia.');
        return;
    }

    var numPosts = parseInt(document.getElementById('numberLoadPostsFromAccounts').value, 10) || 1;
    var btn = document.getElementById('btnLoadPostsFromAccountsQueue');
    if (btn) btn.classList.add('pulsing');

    var totalAdded = 0;
    for (var i = 0; i < acctsQueue.length; i++) {
        if (gblOptions.limitMediaQueue === true && mediaToLike.length >= gblOptions.maxMediaQueueLength) {
            printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
            break;
        }

        var acct = acctsQueue[i];
        var edges = await growbotFetchUserTimelineEdges(acct);
        var numToLoad = numPosts;
        if (numToLoad > edges.length) numToLoad = edges.length;

        var addedForAcct = 0;
        for (var j = 0; j < edges.length && addedForAcct < numToLoad; j++) {
            if (gblOptions.limitMediaQueue === true && mediaToLike.length >= gblOptions.maxMediaQueueLength) {
                break;
            }
            var node = edges[j].node;
            if (gblOptions.includePinnedPostForAccountMedia === false && node.timeline_pinned_user_ids && node.timeline_pinned_user_ids.length > 0) {
                continue;
            }
            var piece = Object.assign({}, node);
            piece.owner = acct;
            mediaToLike.push(piece);
            addedForAcct++;
            totalAdded++;
        }

        printMessage('Posts (' + (i + 1) + '/' + acctsQueue.length + '): @' + (acct.username || '?') + ' +' + addedForAcct);

        if (i < acctsQueue.length - 1) {
            await new Promise(function (rr) { setTimeout(rr, getRandomizedTime(gblOptions.timeDelay)); });
        }
    }

    mediaToLike = uniq(mediaToLike);
    arrayOfMediaToDiv(mediaToLike, false);

    if (btn) btn.classList.remove('pulsing');
    outputMessage(totalAdded + ' posts carregados na fila de mídia.');
    printMessage(chrome.i18n.getMessage('Done'));
}

function loadLikesForMedia(media) {

    return new Promise(function (resolve, reject) {

        let retMedia = media;

        $.ajax({
            url: 'https://www.instagram.com/api/v1/media/' + media.node.id + '/likers/',
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function (r) {

                let retLikers = [];

                if (r && r.users) {
                    for (var i = 0; i < r.users.length; i++) {
                        var a = r.users[i];
                        a['id'] = a.pk;
                        retLikers.push(a);
                    }

                    outputMessage('Loaded ' + retLikers.length + ' likers for post ' + (media.node && media.node.code ? media.node.code : media.node.id));
                    resolve(retLikers);
                } else {
                    outputMessage('Loaded 0 likers (unexpected response)');
                    resolve([]);
                }

            }).fail(function (f) {
                if (f.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(loadLikesForMedia(media));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (f.status == 400 || f.status == 403) {
                    outputMessage('Loading likers blocked (HTTP ' + f.status + '). Slowing down...');
                    resolve([]);
                } else {
                    outputMessage('Failed loading likers (HTTP ' + (f.status || 'erro') + ')');
                    resolve([]);
                }
            });

    });
}

var extensionId = chrome.i18n.getMessage("@@extension_id");

function getLikersFromMediaArray() {
    let accountsThatLiked = [];

    for (var i = 0; i < mediaForLikes.length; i++) {
        var media = mediaForLikes[i];

        for (var j = 0; j < media.data.shortcode_media.edge_liked_by.edges.length; j++) {
            var like = media.data.shortcode_media.edge_liked_by.edges[j].node;
            if (typeof like == 'undefined') {
                like = media.data.shortcode_media.edge_liked_by.edges[j];
            }
            if (accountIdsThatLiked.indexOf(like.id) == -1) {
                accountIdsThatLiked.push(like.id);
                accountsThatLiked.push(like);
            }
        }
    }

    if (acctsQueue.length == 0) {
        acctsQueue = accountsThatLiked;
    } else {
        for (var i = 0; i < accountsThatLiked.length; i++) {
            if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
                if (findAcctById(accountsThatLiked[i].id, acctsQueue) === false) {
                    acctsQueue.push(accountsThatLiked[i]);
                }
            } else {
                arrayOfUsersToDiv(accountsThatLiked, false);
                return false;
            }
        }
    }

    arrayOfUsersToDiv(accountsThatLiked, false);
}


function ajaxGetPendingFollowRequests(after) {

    alert('Sorry, but Instagram has disabled this feature :(\n\nYou can download your data from:\n\nhttps://www.instagram.com/download/request');
    return false;

    $('#btnLoadPendingRequests').addClass('pulsing');

    if (typeof after != 'string') {
        acctsQueue = [];
        after = '';
    }

    var url = 'https://www.instagram.com/accounts/access_tool/current_follow_requests?__a=1';

    if (after != '') {
        url = url + '&cursor=' + after;
    }

    $.ajax(url)
        .done(function (r) {
            var tmpQueue = [];

            var promises = [];

            $(r.data.data).each(function (edge) {

                var u = {
                    username: $(this)[0].text
                }

                var promise = new Promise(async function (resolve, reject) {
                    u = await getAdditionalDataForAcct(u);
                    acctsQueue.push(u);
                    tmpQueue.push(u);
                    resolve(u);
                });
                promises.push(promise);

            });

            var result = Promise.all(promises);

            result.then(function (data) {
                arrayOfUsersToDiv(tmpQueue, false);

                if (r.data.cursor && (acctsQueue.length < parseInt(gblOptions.maxAcctQueueLength) || gblOptions.limitQueue != true)) {
                    printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length.toString(), acctsQueue.length.toString()]));
                    ajaxGetPendingFollowRequests(r.data.cursor);
                } else {
                    $('#btnLoadPendingRequests').removeClass('pulsing');
                    printMessage(chrome.i18n.getMessage('Done'));
                }

            })


        }).fail(function (f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function () {
                    ajaxGetPendingFollowRequests(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });


}


var GROWBOT_FRIENDSHIPS_LIST_PAGE_SIZE = 48;

function getInstagramWebApiHeaders() {
    return {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'x-asbd-id': '129477',
        'x-csrftoken': getCsrfFromCookie(),
        'x-ig-app-id': '936619743392459',
        'x-requested-with': 'XMLHttpRequest',
        'x-instagram-ajax': '1010212815'
    };
}

function getInstagramWebApiFetchOptions(referrerUsername) {
    var pathUser = referrerUsername || '';
    try {
        if (!pathUser && typeof getProfileUsernameFromPath === 'function') pathUser = getProfileUsernameFromPath();
    } catch (e) {}
    return {
        method: 'GET',
        credentials: 'include',
        headers: getInstagramWebApiHeaders(),
        referrer: pathUser ? ('https://www.instagram.com/' + encodeURIComponent(pathUser) + '/') : 'https://www.instagram.com/',
        referrerPolicy: 'strict-origin-when-cross-origin'
    };
}

function growbotFriendshipsListUrl(userId, listKind, maxId) {
    var params = new URLSearchParams({
        count: String(GROWBOT_FRIENDSHIPS_LIST_PAGE_SIZE),
        search_surface: 'follow_list_page'
    });
    if (maxId) {
        params.set('max_id', String(maxId));
    }
    return 'https://www.instagram.com/api/v1/friendships/' + encodeURIComponent(String(userId)) + '/' + listKind + '/?' + params.toString();
}

async function growbotFetchFriendshipsListPage(userId, listKind, maxId, referrerUsername) {
    var response = await fetch(
        growbotFriendshipsListUrl(userId, listKind, maxId),
        getInstagramWebApiFetchOptions(referrerUsername)
    );

    if (response.status === 429) {
        var rateErr = new Error('rate limited');
        rateErr.status = 429;
        throw rateErr;
    }
    if (!response.ok) {
        throw new Error('friendships/' + listKind + ' HTTP ' + response.status);
    }

    var data = await response.json();
    if (!data || data.status !== 'ok' || !Array.isArray(data.users)) {
        throw new Error('friendships/' + listKind + ' failed');
    }
    return data;
}

function normalizeAppUserToProfilePage(u, fallbackUsername) {
    if (!u) return u;
    var followers = (u.follower_count != null) ? u.follower_count
        : (u.edge_followed_by && u.edge_followed_by.count != null ? u.edge_followed_by.count : 0);
    var following = (u.following_count != null) ? u.following_count
        : (u.edge_follow && u.edge_follow.count != null ? u.edge_follow.count : 0);
    u.id = String(u.pk != null ? u.pk : (u.id != null ? u.id : ''));
    if (!u.username) u.username = fallbackUsername;
    u.edge_followed_by = { count: followers };
    u.edge_follow = { count: following };
    if (u.follower_count == null) u.follower_count = followers;
    if (u.following_count == null) u.following_count = following;
    return u;
}

function growbotNormalizeFriendshipsListUser(rawUser) {
    return normalizeAppUserToProfilePage(Object.assign({}, rawUser), rawUser.username);
}

async function ajaxGetAllUsersFollowers(after) {
    if (!currentProfilePage || !currentProfilePage.username) {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }
    if (!currentProfilePage.id) {
        outputMessage('Não foi possível obter o ID de ' + currentProfilePage.username + ' (Instagram bloqueou a API). Recarregue o perfil, aguarde alguns minutos e tente de novo. Curtidores/comentadores já estão liberados.');
        return false;
    }
    if (typeof after != 'string') {
        after = '';

        if (gblOptions.endcursors) {

            var endCursorsForThisPageAndAction = gblOptions.endcursors;
            endCursorsForThisPageAndAction = endCursorsForThisPageAndAction.filter(e => e.action === 'loadFollowers' && e.id === currentProfilePage.id);

            if (endCursorsForThisPageAndAction.length > 0) {
                if (window.confirm('Would you like to attempt to resume where you left off?')) {
                    var objEndCursor = endCursorsForThisPageAndAction[endCursorsForThisPageAndAction.length - 1];
                    after = objEndCursor.endcursor;
                    gblOptions.truncateStart = 0;
                }
            }

        }

    }

    if (after == '' && currentProfilePage.edge_followed_by.count > gblOptions.maxAcctQueueLength && gblOptions.limitQueue == true) {
        var promptAfter = window.prompt("Account has " + currentProfilePage.edge_followed_by.count + " followers, but your queue limit is set to " + gblOptions.maxAcctQueueLength + ". \n\n Enter follower number to begin at (0 is the most recent follower).", gblOptions.truncateStart);
        if (!isNaN(parseInt(promptAfter))) {
            gblOptions.truncateStart = parseInt(promptAfter);
        }
    }

    var jsonvars = null;

    try {
        var r = await growbotFetchFriendshipsListPage(
            currentProfilePage.id,
            'followers',
            after || null,
            currentProfilePage.username
        );

        var tmpQueue = [];

        for (var i = 0; i < r.users.length; i++) {
            var u = growbotNormalizeFriendshipsListUser(r.users[i]);
            u.source_type = 'Follower';
            u.source_owner = currentProfilePage.username;
            acctsQueue.push(u);
            tmpQueue.push(u);
        }

        printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));


        if (!gblOptions.endcursors) gblOptions['endcursors'] = [];

        var todaysdate = new Date();

        if (r.next_max_id) {
            gblOptions.endcursors.push({
                id: currentProfilePage.id,
                username: currentProfilePage.username,
                action: 'loadFollowers',
                endcursor: String(r.next_max_id),
                time: todaysdate.getTime()
            });
            saveOptions();

        }

        if (r.has_more === true &&
            (acctsQueue.length < (parseInt(gblOptions.truncateStart) + parseInt(gblOptions.maxAcctQueueLength)) ||
                gblOptions.limitQueue != true ||
                currentProfilePage.edge_followed_by.count < parseInt(gblOptions.maxAcctQueueLength))
        ) {

            ajaxGetAllUsersFollowers(String(r.next_max_id));


        } else {

            truncateQueue(gblOptions.truncateStart);

            $('#btnProcessQueue').removeClass('pulsing');

            arrayOfUsersToDiv(acctsQueue, true);

            printMessage(chrome.i18n.getMessage('Done'));
            printMessage(' ');

        }


    } catch (f) {
        if (f && f.status == 429) {
            printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
            timeoutsQueue.push(setTimeout(function () {
                ajaxGetAllUsersFollowers(after);
            }, gblOptions.timeDelayAfter429RateLimit));
        } else {
            outputMessage('Falha ao carregar seguidores: ' + ((f && f.message) || 'erro') + '. Aguarde e tente de novo.');
        }
    }

}


async function ajaxLoadFollowing(after) {

    if (!currentProfilePage || !currentProfilePage.username) {
        outputMessage('Error: must be on an instagram user page (or try reloading).');
        return false;
    }
    if (!currentProfilePage.id) {
        outputMessage('Não foi possível obter o ID de ' + currentProfilePage.username + ' (Instagram bloqueou a API). Recarregue o perfil, aguarde alguns minutos e tente de novo. Curtidores/comentadores já estão liberados.');
        return false;
    }
    if (typeof after != 'string') {
        // acctsQueue = [];
        after = '';


        if (gblOptions.endcursors) {

            var endCursorsForThisPageAndAction = gblOptions.endcursors;
            endCursorsForThisPageAndAction = endCursorsForThisPageAndAction.filter(e => e.action === 'loadFollowing' && e.id === currentProfilePage.id);

            if (endCursorsForThisPageAndAction.length > 0) {
                if (window.confirm('Would you like to attempt to resume where you left off?')) {
                    var objEndCursor = endCursorsForThisPageAndAction[endCursorsForThisPageAndAction.length - 1];
                    after = objEndCursor.endcursor;
                    gblOptions.truncateStart = 0;
                }
            }

        }

    }

    if (after == '' && currentProfilePage.edge_follow.count > gblOptions.maxAcctQueueLength && gblOptions.limitQueue == true) {
        var promptAfter = window.prompt("Account is following " + currentProfilePage.edge_follow.count + " accounts, but your queue limit is set to " + gblOptions.maxAcctQueueLength + ". \n\n Enter following number to begin at (0 is the most recent following).", gblOptions.truncateStart);
        if (!isNaN(parseInt(promptAfter))) {
            gblOptions.truncateStart = parseInt(promptAfter);
        }
    }

    var jsonvars = null;

    // friendships API (v2.9.5): old GraphQL query_hash deprecated
    try {
        var r = await growbotFetchFriendshipsListPage(
            currentProfilePage.id,
            'following',
            after || null,
            currentProfilePage.username
        );

            var tmpQueue = [];

            for (var i = 0; i < r.users.length; i++) {
                var u = growbotNormalizeFriendshipsListUser(r.users[i]);
                u.source_type = 'Followed by';
                u.source_owner = currentProfilePage.username;
                acctsQueue.push(u);
                tmpQueue.push(u);
            }

            //arrayOfUsersToDiv(tmpQueue, false);

            printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));



            if (r.next_max_id) {
                var todaysdate = new Date();
                if (!gblOptions.endcursors) gblOptions['endcursors'] = [];
                gblOptions.endcursors.push({
                    id: currentProfilePage.id,
                    username: currentProfilePage.username,
                    action: 'loadFollowing',
                    endcursor: String(r.next_max_id),
                    time: todaysdate.getTime()
                });
                saveOptions();
            }

            if (r.has_more === true &&
                (acctsQueue.length < (parseInt(gblOptions.truncateStart) + parseInt(gblOptions.maxAcctQueueLength)) ||
                    gblOptions.limitQueue != true ||
                    currentProfilePage.edge_follow.count < parseInt(gblOptions.maxAcctQueueLength))
            ) {
                ajaxLoadFollowing(String(r.next_max_id));

            } else {
                truncateQueue(gblOptions.truncateStart);

                arrayOfUsersToDiv(acctsQueue, true);

                outputMessage(currentProfilePage.username + ' following loaded.  Count: ' + acctsQueue.length);
                printMessage(' ');

                loadedTheirFollowings = true;
            }

    } catch (f) {
        if (f && f.status == 429) {
            printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
            timeoutsQueue.push(setTimeout(function () {
                ajaxLoadFollowing(after);
            }, gblOptions.timeDelayAfter429RateLimit));
        } else {
            outputMessage('Falha ao carregar seguindo: ' + ((f && f.message) || 'erro') + '. Aguarde e tente de novo.');
        }
    }
}

async function ajaxGetAllMyFollowing(after) {

    var myId = '';
    try {
        if (typeof user !== 'undefined' && user && user.viewer && user.viewer.id) myId = String(user.viewer.id);
    } catch (e) {}
    if (!myId) {
        try { myId = String(getCookie('ds_user_id') || ''); } catch (e) {}
    }
    if (!myId) {
        outputMessage('Error: not logged in (or try reloading).');
        return false;
    }

    try {
        var r = await growbotFetchFriendshipsListPage(
            myId,
            'following',
            after || null,
            ''
        );

        var tmpQueue = [];

        for (var i = 0; i < r.users.length; i++) {
            var u = growbotNormalizeFriendshipsListUser(r.users[i]);
            acctsQueue.push(u);
            tmpQueue.push(u);
        }

        printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));

        if (r.has_more === true) {
            ajaxGetAllMyFollowing(String(r.next_max_id));
        } else {
            outputMessage('Your following loaded.  Count: ' + acctsQueue.length);
            printMessage(' ');

            loadedMyFollowings = true;
        }

    } catch (f) {
        if (f && f.status == 429) {
            printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
            timeoutsQueue.push(setTimeout(function () {
                ajaxGetAllMyFollowing(after);
            }, gblOptions.timeDelayAfter429RateLimit));
        } else {
            outputMessage('Falha ao carregar seu seguindo: ' + ((f && f.message) || 'erro') + '. Aguarde e tente de novo.');
        }
    }
}



function isAdditionalDataFullyLoaded(q) {
    for (var i = 0; i < q.length; i++) {
        if (!q[i].edge_followed_by) {
            return false;
        }
    }
    return true;
}


var extId = btoa('' + extensionId);

function sortQueue(q, property, asc) {

    var propertySplit = property.split('.');

    if (propertySplit.length === 1) {
        q.sort(function (a, b) {
            // propriedades não numéricas como nome de usuário
            if (isNaN(a[property])) {
                if (asc == true) {
                    return a[property].localeCompare(b[property]);
                } else {
                    return b[property].localeCompare(a[property]);
                }
            }
            // propriedades numéricas como seguidores
            if (asc == true) {
                return a[property] - b[property];
            } else {
                return b[property] - a[property];
            }
        });
    } else if (propertySplit.length === 2) {
        q.sort(function (a, b) {
            if (asc == true) {
                return a[propertySplit[0]][propertySplit[1]] - b[propertySplit[0]][propertySplit[1]];
            } else {
                return b[propertySplit[0]][propertySplit[1]] - a[propertySplit[0]][propertySplit[1]];
            }
        });
    }

    return q;
}



async function appendLastPostDateToAcct(a) {

    //  só consultar o servidor se o filtro estiver ativado ou se o usuário estiver obtendo mais dados e quiser isso
    if (
        (gblOptions.filterOptions.lastPosted[0] < 1 && gblOptions.filterOptions.lastPosted[1] > 4999) ||
        (a.is_private == true && a.followed_by_viewer == false) ||
        (document.getElementById('radioGetMoreData').checked == true && gblOptions.getLastPostDate == false)
    ) {
        // a.lastPostDateInDays = 10;
        return a;
    }

    if (a.edge_owner_to_timeline_media.count > 0) {

        if (a.edge_owner_to_timeline_media.edges.length == 0) {
            a = await getTimelineForAcct(a);
        }

        var sortedMedia = sortQueue(a.edge_owner_to_timeline_media.edges, 'taken_at', false);
        var lastMediaDate = 0;
        if (sortedMedia.length > 0 && sortedMedia[0].taken_at != 'undefined') {
            lastMediaDate = sortedMedia[0].taken_at * 1000;
        }

        a.lastPostDate = lastMediaDate;

        var date1 = new Date(lastMediaDate);
        var date2 = new Date();
        var differenceInTime = date2.getTime() - date1.getTime();
        var differenceInDays = differenceInTime / (1000 * 3600 * 24);

        a.lastPostDateInDays = differenceInDays;


    } else {
        a.lastPostDateInDays = 6000;
    }

    return a;
}

function appendFollowersRatioToAcct(a) {
    if (a.edge_follow.count > 0 && a.edge_followed_by.count > 0) {
        a.followRatio = a.edge_followed_by.count / a.edge_follow.count;
    } else if (a.edge_followed_by.count > 0) {
        a.followRatio = a.edge_followed_by.count;
    } else {
        a.followRatio = 0;
    }

    return a;
}

function appendHasProfilePicToAcct(acct) {
    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1) {
        acct.has_profile_pic = 0;
    } else {
        acct.has_profile_pic = 1;
    }

    return acct;
}

function truncateQueue(start) {
    if (isNaN(parseInt(start))) start = 0;

    if (acctsQueue.length > gblOptions.maxAcctQueueLength && gblOptions.limitQueue != false) {
        var end = (start + gblOptions.maxAcctQueueLength);

        acctsQueue = acctsQueue.slice(start, end);

    }
}

async function arrayOfMediaToDiv(q, clearDiv) {

    if (typeof clearDiv == 'undefined') clearDiv = true;

    if (clearDiv === true) {
        $('#igBotMediaQueueContainer').children().remove();
    } else {
        $('#igBotMediaQueueContainer').children().not('.igBotQueueAcct').remove();
    }

    if (gblOptions.cbShowQueueOnScreen == false) {
        $('#igBotMediaQueueContainer').append('<div style="text-align:center;">You have turned off "Show queue on screen" in Settings.  Your queue is loaded in the background.</div>');
        return false;
    }


    $('#igBotMediaQueueContainer').append('<table id="gridjsMediaQueueWrapper"></table>');



    var columns = [{
        "name": '✓',
        "data": 'id',
        "width": '40px',
        "formatter": '<input type="checkbox" id="cb_${cell}" value="${cell}" />',
        "visible": true,
    }, {
        "name": "Media",
        "data": "image_versions2.candidates",
        "width": '150px',
        "visible": true
    }, {
        "name": '@username',
        "data": 'owner.username',
        "formatter": '<a href="https://www.instagram.com/${cell}" target="_blank">@${cell}</a>',
        "width": '125px',
        "visible": true
    }, {
        "name": "Caption",
        "data": "caption.text",
        "width": '200px',
        "visible": true
    }, {
        "name": "Date Taken",
        "data": "taken_at",
        "data2": "taken_at_timestamp",
        "width": '95px',
        "visible": true
    }, {
        "name": "Type",
        "data": "media_type",
        "data2": "__typename",
        "width": '95px',
        "visible": true
    }, {
        "name": "pk",
        "data": "pk",
        "width": '95px',
        "visible": false
    }, {
        "name": "id",
        "data": "id",
        "width": '95px',
        "visible": false
    }, {
        "name": "Comment Count",
        "data": "comment_count",
        "data2": "edge_media_preview_comment.count",
        "width": '95px',
        "visible": true
    }, {
        "name": "Like Count",
        "data": "like_count",
        "data2": "edge_media_preview_like.count",
        "width": '95px',
        "visible": true
    }];



    columns = columns.filter(e => e.visible !== false);


    var sb = '<thead><tr>';

    for (var i = 0; i < columns.length; i++) {
        sb = sb + '<th data-prop="' + columns[i].data + '" style="width:' + (columns[i].width || '60px') + ';">' + columns[i].name + '</th>';
    }

    sb = sb + '</tr></thead><tbody></tbody>';
    $('#gridjsMediaQueueWrapper').append(sb);

    for (var i = 0; i < q.length; i++) {
        sb = '<tr>';
        for (var j = 0; j < columns.length; j++) {


            if (columns[j].width) {
                sb = sb + '<td column-data="' + columns[j].data + '" style="width:' + columns[j].width + ';">';
            } else {
                sb = sb + '<td column-data="' + columns[j].data + '">';
            }

            if (columns[j].data) {

                var dataPropertyToUse = columns[j].data;

                if (columns[j].data2 && q[i].hasOwnProperty(columns[j].data2.split('.')[0])) {
                    dataPropertyToUse = columns[j].data2;

                }

                var props = dataPropertyToUse.split('.');

                if (props[1]) {
                    if (props[1] == 'candidates') {
                        if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                            var candidates = q[i][props[0]][props[1]];
                            sb = sb + '<a href="https://www.instagram.com/p/' + (q[i].code || q[i].shortcode) + '" target="_blank"><img style="width:150px;" class="igBotMediaQueuePicture" data-img-id="' + q[i].id + '" src="' + candidates[0].url + '"></a></td>';
                        } else if (q[i].display_url) {
                            sb = sb + '<a href="https://www.instagram.com/p/' + (q[i].code || q[i].shortcode) + '" target="_blank"><img style="width:150px;" class="igBotMediaQueuePicture" data-img-id="' + q[i].id + '" src="' + q[i].display_url + '"></a></td>';
                        } else {
                            sb = sb + '</td>';
                        }
                    } else if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][props[0]][props[1]]) + '</td>';
                        } else {
                            sb = sb + q[i][props[0]][props[1]] + '</td>';
                        }
                    } else if (props[0] == 'caption') {
                        if (q[i].caption) {
                            sb = sb + q[i].caption + '</td>';
                        } else if (q[i].edge_media_to_caption && q[i].edge_media_to_caption.edges && q[i].edge_media_to_caption.edges.length > 0) {
                            sb = sb + q[i].edge_media_to_caption.edges[0].node.text + '</td>';
                        }

                    } else {
                        sb = sb + '-</td>';
                    }
                } else {
                    if (q[i][props[0]]) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][dataPropertyToUse]) + '</td>';
                        } else {

                            var dataString = (q[i][props[0]]);

                            if (props[0] == 'taken_at' || props[0] == 'taken_at_timestamp') {
                                var d = new Date(dataString * 1000);
                                var datePart = d.toISOString().slice(0, 10);
                                var timePart = d.toLocaleString([], {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                });
                                dataString = datePart + ' ' + timePart;
                            }

                            if (props[0] == '__typename' || props[0] == 'media_type') {
                                dataString = dataString.toString().replace('Graph', '').replace('2', 'Video').replace('8', 'Sidecar').replace('1', 'Image').replace('Sidecar', 'Slideshow');
                            }



                            sb = sb + dataString.toString() + '</td>';
                        }
                    } else {
                        sb = sb + '-</td>';
                    }
                }


            }
        }
        sb = sb + '</tr>';
        $('#gridjsMediaQueueWrapper tbody').append(sb);
    }


    $('#gridjsMediaQueueWrapper').tablesorter({

        // *** APPEARANCE ***
        // Add a theme - 'blackice', 'blue', 'dark', 'default', 'dropbox',
        // 'green', 'grey' or 'ice' stylesheets have all been loaded
        // to use 'bootstrap' or 'jui', you'll need to include 'uitheme'
        // in the widgets option - To modify the class names, extend from
        // themes variable. Look for '$.extend($.tablesorter.themes.jui'
        // at the bottom of this window
        // this option only adds a table class name 'tablesorter-{theme}'
        theme: 'blue',

        // fix the column widths
        widthFixed: true,

        // Show an indeterminate timer icon in the header when the table
        // is sorted or filtered
        showProcessing: true,

        // header layout template (HTML ok); {content} = innerHTML,
        // {icon} = <i/> (class from cssIcon)
        headerTemplate: '{content}{icon}',

        // return the modified template string
        onRenderTemplate: null, // function(index, template){ return template; },

        // called after each header cell is rendered, use index to target the column
        // customize header HTML
        onRenderHeader: function (index) {
            // the span wrapper is added by default
            $(this).find('div.tablesorter-header-inner').addClass('roundedCorners');
        },

        // *** FUNCTIONALITY ***
        // prevent text selection in header
        cancelSelection: true,

        // add tabindex to header for keyboard accessibility
        tabIndex: true,

        // other options: 'ddmmyyyy' & 'yyyymmdd'
        dateFormat: 'yyyymmdd',

        // The key used to select more than one column for multi-column
        // sorting.
        sortMultiSortKey: 'shiftKey',

        // key used to remove sorting on a column
        sortResetKey: 'ctrlKey',

        // false for German '1.234.567,89' or French '1 234 567,89'
        usNumberFormat: true,

        // If true, parsing of all table cell data will be delayed
        // until the user initializes a sort
        delayInit: false,

        // if true, server-side sorting should be performed because
        // client-side sorting will be disabled, but the ui and events
        // will still be used.
        serverSideSorting: false,

        // default setting to trigger a resort after an 'update',
        // 'addRows', 'updateCell', etc has completed
        resort: true,

        // *** SORT OPTIONS ***
        // These are detected by default,
        // but you can change or disable them
        // these can also be set using data-attributes or class names
        headers: {
            // set 'sorter : false' (no quotes) to disable the column
            0: {
                sorter: 'text'
            },
            1: {
                sorter: false
            },
        },

        // ignore case while sorting
        ignoreCase: true,

        // forces the user to have this/these column(s) sorted first
        sortForce: null,
        // initial sort order of the columns, example sortList: [[0,0],[1,0]],
        // [[columnIndex, sortDirection], ... ]
        // sortList: [
        //     [0, 0],
        //     [1, 0],
        //     [2, 0]
        // ],
        sortList: [],
        // default sort that is added to the end of the users sort
        // selection.
        sortAppend: null,

        // when sorting two rows with exactly the same content,
        // the original sort order is maintained
        sortStable: false,

        // starting sort direction 'asc' or 'desc'
        sortInitialOrder: 'asc',

        // Replace equivalent character (accented characters) to allow
        // for alphanumeric sorting
        sortLocaleCompare: false,

        // third click on the header will reset column to default - unsorted
        sortReset: true,

        // restart sort to 'sortInitialOrder' when clicking on previously
        // unsorted columns
        sortRestart: false,

        // sort empty cell to bottom, top, none, zero, emptyMax, emptyMin
        emptyTo: 'bottom',

        // sort strings in numerical column as max, min, top, bottom, zero
        stringTo: 'zero',

        // extract text from the table
        textExtraction: {
            0: function (node, table) {
                // this is how it is done by default
                return $(node).attr(table.config.textAttribute) ||
                    node.textContent ||
                    node.innerText ||
                    $(node).text() ||
                    '';
            },
            1: function (node) {
                return $(node).text();
            }
        },

        // data-attribute that contains alternate cell text
        // (used in default textExtraction function)
        textAttribute: 'data-text',

        // use custom text sorter
        // function(a,b){ return a.sort(b); } // basic sort
        textSorter: null,

        // choose overall numeric sorter
        // function(a, b, direction, maxColumnValue)
        numberSorter: null,

        // *** WIDGETS ***
        // apply widgets on tablesorter initialization
        initWidgets: true,

        // table class name template to match to include a widget
        widgetClass: 'widget-{name}',

        // include zebra and any other widgets, options:
        // 'columns', 'filter', 'stickyHeaders' & 'resizable'
        // 'uitheme' is another widget, but requires loading
        // a different skin and a jQuery UI theme.
        widgets: ['pager', 'stickyHeaders', 'storage', 'zebra', 'columns', 'filter'],

        widgetOptions: {

            // zebra widget: adding zebra striping, using content and
            // default styles - the ui css removes the background
            // from default even and odd class names included for this
            // demo to allow switching themes
            // [ 'even', 'odd' ]
            zebra: [
                'ui-widget-content even',
                'ui-state-default odd'
            ],

            // columns widget: change the default column class names
            // primary is the 1st column sorted, secondary is the 2nd, etc
            columns: [
                'primary',
                'secondary',
                'tertiary'
            ],

            // columns widget: If true, the class names from the columns
            // option will also be added to the table tfoot.
            columns_tfoot: true,

            // columns widget: If true, the class names from the columns
            // option will also be added to the table thead.
            columns_thead: true,

            // filter widget: If there are child rows in the table (rows with
            // class name from 'cssChildRow' option) and this option is true
            // and a match is found anywhere in the child row, then it will make
            // that row visible; default is false
            filter_childRows: false,

            // filter widget: If true, a filter will be added to the top of
            // each table column.
            filter_columnFilters: true,

            // filter widget: css class name added to the filter cell
            // (string or array)
            filter_cellFilter: '',

            // filter widget: css class name added to the filter row & each
            // input in the row (tablesorter-filter is ALWAYS added)
            filter_cssFilter: '',

            // filter widget: add a default column filter type
            // '~{query}' to make fuzzy searches default;
            // '{q1} AND {q2}' to make all searches use a logical AND.
            filter_defaultFilter: {},

            // filter widget: filters to exclude, per column
            filter_excludeFilter: {},

            // filter widget: jQuery selector string (or jQuery object)
            // of external filters
            filter_external: '',

            // filter widget: class added to filtered rows;
            // needed by pager plugin
            filter_filteredRow: 'filtered',

            // filter widget: add custom filter elements to the filter row
            filter_formatter: null,

            // filter widget: Customize the filter widget by adding a select
            // dropdown with content, custom options or custom filter functions
            // see http://goo.gl/HQQLW for more details
            filter_functions: null,

            // filter widget: hide filter row when table is empty
            filter_hideEmpty: true,

            // filter widget: Set this option to true to hide the filter row
            // initially. The rows is revealed by hovering over the filter
            // row or giving any filter input/select focus.
            filter_hideFilters: false,

            // filter widget: Set this option to false to keep the searches
            // case sensitive
            filter_ignoreCase: true,

            // filter widget: if true, search column content while the user
            // types (with a delay)
            filter_liveSearch: true,

            // filter widget: a header with a select dropdown & this class name
            // will only show available (visible) options within the drop down
            filter_onlyAvail: 'filter-onlyAvail',

            // filter widget: default placeholder text
            // (overridden by any header 'data-placeholder' setting)
            filter_placeholder: {
                search: '',
                select: ''
            },

            // filter widget: jQuery selector string of an element used to
            // reset the filters.
            filter_reset: null,

            // filter widget: Use the $.tablesorter.storage utility to save
            // the most recent filters
            filter_saveFilters: false,

            // filter widget: Delay in milliseconds before the filter widget
            // starts searching; This option prevents searching for every character
            // while typing and should make searching large tables faster.
            filter_searchDelay: 300,

            // filter widget: allow searching through already filtered rows in
            // special circumstances; will speed up searching in large tables if true
            filter_searchFiltered: true,

            // filter widget: include a function to return an array of values to be
            // added to the column filter select
            filter_selectSource: null,

            // filter widget: Set this option to true if filtering is performed on
            // the server-side.
            filter_serversideFiltering: false,

            // filter widget: Set this option to true to use the filter to find
            // text from the start of the column. So typing in 'a' will find
            // 'albert' but not 'frank', both have a's; default is false
            filter_startsWith: false,

            // filter widget: If true, ALL filter searches will only use parsed
            // data. To only use parsed data in specific columns, set this option
            // to false and add class name 'filter-parsed' to the header
            filter_useParsedData: false,

            // filter widget: data attribute in the header cell that contains
            // the default filter value
            filter_defaultAttrib: 'data-value',

            // filter widget: filter_selectSource array text left of the separator
            // is added to the option value, right into the option text
            filter_selectSourceSeparator: '|',

            // starting page of the pager (zero based index)
            pager_startPage: 0,

            // Number of visible rows - default is 10
            pager_size: gblOptions.mediapaginationLimit,

            // reset pager after filtering; set to desired page #
            // set to false to not change page at filter start
            pager_pageReset: 0,

            // output string - default is '{page}/{totalPages}';
            // possible variables:
            // {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
            // pager_output: '{startRow} to {endRow} ({totalRows})',
            pager_output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',

            // apply disabled classname to the pager arrows when the rows at
            // either extreme is visible - default is true
            pager_updateArrows: true,

            // Number of options to include in the pager number selector
            pager_maxOptionSize: 20,

            // Save pager page & size if the storage script is loaded
            // (requires $.tablesorter.storage in jquery.tablesorter.widgets.js)
            pager_savePages: true,

            // defines custom storage key
            pager_storageKey: 'tablesorter-media-pager',

            // if true, the table will remain the same height no matter how many
            // records are displayed. The space is made up by an empty
            // table row set to a height to compensate; default is false
            pager_fixedHeight: false,

            // count child rows towards the set page size?
            // (set true if it is a visible table row within the pager)
            // if true, child row(s) may not appear to be attached to its
            // parent row, may be split across pages or
            // may distort the table if rowspan or cellspans are included.
            pager_countChildRows: false,

            // remove rows from the table to speed up the sort of large tables.
            // setting this to false, only hides the non-visible rows; needed
            // if you plan to add/remove rows with the pager enabled.
            pager_removeRows: false,

            // css class names used by pager elements
            pager_css: {
                // class added to pager container
                container: 'tablesorter-pager',
                // error information row (don't include period at beginning)
                errorRow: 'tablesorter-errorRow',
                // class added to arrows @ extremes
                // (i.e. prev/first arrows "disabled" on first page)
                disabled: 'disabled'
            },

            // jQuery selectors
            pager_selectors: {
                // target the pager markup
                container: '.mediapager',
                // go to first page arrow
                first: '.first',
                // previous page arrow
                prev: '.prev',
                // next page arrow
                next: '.next',
                // go to last page arrow
                last: '.last',
                // go to page selector - select dropdown that sets the current page
                gotoPage: '.gotoPage',
                // location of where the "output" is displayed
                pageDisplay: '.pagedisplay',
                // page size selector - select dropdown that sets the "size" option
                pageSize: '.pagesize'
            },

            // Resizable widget: If this option is set to false, resized column
            // widths will not be saved. Previous saved values will be restored
            // on page reload
            resizable: true,

            // Resizable widget: If this option is set to true, a resizing anchor
            // will be included in the last column of the table
            resizable_addLastColumn: false,

            // Resizable widget: Set this option to the starting & reset header widths
            resizable_widths: [],

            // Resizable widget: Set this option to throttle the resizable events
            // set to true (5ms) or any number 0-10 range
            resizable_throttle: false,

            // saveSort widget: If this option is set to false, new sorts will
            // not be saved. Any previous saved sort will be restored on page
            // reload.
            saveSort: false,

            // stickyHeaders widget: extra class name added to the sticky header row
            stickyHeaders: '',

            // jQuery selector or object to attach sticky header to
            stickyHeaders_attachTo: '#igBotMediaQueueContainer',

            // jQuery selector or object to monitor horizontal scroll position
            // (defaults: xScroll > attachTo > window)
            stickyHeaders_xScroll: null,

            // jQuery selector or object to monitor vertical scroll position
            // (defaults: yScroll > attachTo > window)
            stickyHeaders_yScroll: null,

            // number or jquery selector targeting the position:fixed element
            stickyHeaders_offset: 0,

            // scroll table top into view after filtering
            stickyHeaders_filteredToTop: true,

            // added to table ID, if it exists
            stickyHeaders_cloneId: '-sticky',

            // trigger 'resize' event on headers
            stickyHeaders_addResizeEvent: true,

            // if false and a caption exist, it won't be included in the
            // sticky header
            stickyHeaders_includeCaption: true,

            // The zIndex of the stickyHeaders, allows the user to adjust this
            // to their needs
            stickyHeaders_zIndex: 2

        },

        // *** CALLBACKS ***
        // function called after tablesorter has completed initialization
        initialized: function () {

        }, // function (table) {}

        // *** extra css class names
        tableClass: '',
        cssAsc: '',
        cssDesc: '',
        cssNone: '',
        cssHeader: '',
        cssHeaderRow: '',
        // processing icon applied to header during sort/filter
        cssProcessing: '',

        // class name indiciating that a row is to be attached to the its parent
        cssChildRow: 'tablesorter-childRow',
        // if this class does not exist, the {icon} will not be added from
        // the headerTemplate
        cssIcon: 'tablesorter-icon',
        // class name added to the icon when there is no column sort
        cssIconNone: '',
        // class name added to the icon when the column has an ascending sort
        cssIconAsc: '',
        // class name added to the icon when the column has a descending sort
        cssIconDesc: '',
        // don't sort tbody with this class name
        // (only one class name allowed here!)
        cssInfoBlock: 'tablesorter-infoOnly',
        // class name added to table header which allows clicks to bubble up
        cssAllowClicks: 'tablesorter-allowClicks',
        // header row to ignore; cells within this row will not be added
        // to table.config.$headers
        cssIgnoreRow: 'tablesorter-ignoreRow',

        // *** SELECTORS ***
        // jQuery selectors used to find the header cells.
        selectorHeaders: '> thead th, > thead td',

        // jQuery selector of content within selectorHeaders
        // that is clickable to trigger a sort.
        selectorSort: 'th, td',

        // rows with this class name will be removed automatically
        // before updating the table cache - used by 'update',
        // 'addRows' and 'appendCache'
        selectorRemove: '.remove-me',

        // *** DEBUGING ***
        // send messages to console
        debug: false

    }).bind("sortEnd", function (e, t) {
        sortMediaQueueByTableSort();
        handleMediaCheckBoxes();
    });

    handleMediaCheckBoxes();
    handleImagePreload();

    if (clearDiv == true) {
        $('#mediapaginationLimit option:selected').attr("selected", null);
        $('#mediapaginationLimit option[value="' + gblOptions.mediapaginationLimit + '"]').attr("selected", "selected");
        $('#gridjsMediaQueueWrapper').trigger('pageSize', gblOptions.mediapaginationLimit);
    }

    $('#mediaqueueQuantityRow').show();
}



function handleImagePreload() {
    const images = document.querySelectorAll('#igBotQueueContainer img,#igBotMediaQueueContainer img');
    const config = {
        rootMargin: '0px 0px 50px 0px',
        threshold: 0
    };
    let loaded = 0;

    let observer = new IntersectionObserver(function (entries, self) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                preloadImage(entry.target);
                // Stop watching and load the image
                self.unobserve(entry.target);
            }
        });
    }, config);

    images.forEach(image => {

        $(image).off('click.hideGrowbotOnOpenPost').on('click.hideGrowbotOnOpenPost', function () {
            saveHiddenStatus(true);
        });


        if (image.hasAttribute('data-src')) {
            observer.observe(image);
        }
    });

    function preloadImage(img) {
        const src = img.getAttribute('data-src');
        if (!src) {
            return;
        }
        img.src = src;
        img.removeAttribute('data-src');
    }

}

function handleCheckBoxes(q) {

    let lastChecked;
    let boxes = [];

    function displaySelectedCount() {
        let boxCheckedCount = 0;
        boxes.forEach(box => {
            if (box.checked == true) boxCheckedCount++;
        });
        document.getElementById('igBotQueueSelectedCount').textContent = '' + boxCheckedCount + ' selected';
    }

    function selectAllCheckBoxes() {
        boxes.forEach(box => {
            if (document.getElementById(box.id).closest('tr').classList.contains('filtered') == false) box.checked = true;
            //box.checked = true;
        });
        displaySelectedCount();
    }

    function selectNoneCheckBoxes() {
        boxes.forEach(box => {
            box.checked = false;
        });
        displaySelectedCount();
    }

    function invertCheckBoxes() {
        boxes.forEach(box => box.checked = !box.checked);
        displaySelectedCount();
    }

    function removeSelected() {
        var useDefaultList = true;

        if (currentList == 'acctsWhiteList') {
            useDefaultList = false;
        }

        boxes.forEach(box => {
            if (box.checked) {
                if (useDefaultList == true) {
                    acctsQueue = acctsQueue.filter(u => u.id !== box.value);
                } else if (currentList == 'acctsWhiteList') {
                    acctsWhiteList = acctsWhiteList.filter(u => u.id !== box.value);
                }

                $('#' + box.value + '_container').remove();
            }
        });
        refreshBoxes();
        updateCount();
        displaySelectedCount();

        if (useDefaultList == true) {
            arrayOfUsersToDiv(acctsQueue, true);
        } else if (currentList == 'acctsWhiteList') {
            arrayOfUsersToDiv(acctsWhiteList, true);
        }
    }

    function addAcctsToWhiteList() {
        boxes.forEach(box => {
            if (box.checked) {
                var acct = findAcctById(box.value, acctsQueue);
                addAcctToWhiteList(acct);
            }
        });

        setTimeout(saveWhiteListToStorage, 2000);

        return true;
    }

    function checkIntermediateBoxes(first, second) {
        if (boxes.indexOf(first) > boxes.indexOf(second)) {
            [second, first] = [first, second];
        }
        intermediateBoxes(first, second).forEach(box => box.checked = true);
        displaySelectedCount();
    }

    function intermediateBoxes(start, end) {
        return boxes.filter((item, key) => {
            return boxes.indexOf(start) < key && key < boxes.indexOf(end);
        });
    }

    function changeBox(event) {
        if (event.shiftKey && this != lastChecked) {
            checkIntermediateBoxes(lastChecked, this);
        }
        lastChecked = this;
        displaySelectedCount();
    }

    function refreshBoxes() {
        boxes = Array.from(document.querySelectorAll('#gridjsAcctsQueueWrapper [type="checkbox"]'));
    }


    refreshBoxes();

    boxes.forEach(item => {
        $(item).off('click.changeBox').on('click.changeBox', changeBox);
    });

    $('#btnSelectAll').off('click.selectAllCheckBoxes').on('click.selectAllCheckBoxes', selectAllCheckBoxes);
    $('#btnSelectNone').off('click.selectNoneCheckBoxes').on('click.selectNoneCheckBoxes', selectNoneCheckBoxes);
    $('#btnInvertSelection').off('click.invertCheckBoxes').on('click.invertCheckBoxes', invertCheckBoxes);
    $('#btnRemoveSelected').off('click.removeSelected').on('click.removeSelected', removeSelected);
    $('#btnAddToWhiteList').off('click.addAcctsToWhiteList').on('click.addAcctsToWhiteList', addAcctsToWhiteList);
    $('#btnSaveWhiteList').off('click.saveWhiteListToStorageAndDisk').on('click.saveWhiteListToStorageAndDisk', saveWhiteListToStorageAndDisk);
    $('.close-icon').off('click.filterQueue').on('click.filterQueue', function () {
        setTimeout(filterQueue, 1);
    });
    //$('.igBotInjectedButton').off('click.displaySelectedCount').on('click.displaySelectedCount', displaySelectedCount);

    updateCount();
    displaySelectedCount();
}



function handleMediaCheckBoxes(q) {

    let lastChecked;
    let boxes = [];

    function displaySelectedCount() {
        let boxCheckedCount = 0;
        boxes.forEach(box => {
            if (box.checked == true) boxCheckedCount++;
        });
        document.getElementById('igBotmediaQueueSelectedCount').textContent = '' + boxCheckedCount + ' selected';

    }

    function selectAllCheckBoxes() {
        boxes.forEach(box => {
            if (document.getElementById(box.id).closest('tr').classList.contains('filtered') == false) box.checked = true;
            //box.checked = true;
        });
        displaySelectedCount();
    }

    function selectNoneCheckBoxes() {
        boxes.forEach(box => {
            box.checked = false;
        });
        displaySelectedCount();
    }

    function invertCheckBoxes() {
        boxes.forEach(box => box.checked = !box.checked);
        displaySelectedCount();
    }

    function removeSelected() {
        boxes.forEach(box => {
            if (box.checked) {
                mediaToLike = mediaToLike.filter(m => m.id !== box.value);
            }
        });

        refreshBoxes();
        updateCount();
        displaySelectedCount();

        arrayOfMediaToDiv(mediaToLike, true);
    }

    function checkIntermediateBoxes(first, second) {
        if (boxes.indexOf(first) > boxes.indexOf(second)) {
            [second, first] = [first, second];
        }
        intermediateBoxes(first, second).forEach(box => box.checked = true);
        displaySelectedCount();
    }

    function intermediateBoxes(start, end) {
        return boxes.filter((item, key) => {
            return boxes.indexOf(start) < key && key < boxes.indexOf(end);
        });
    }

    function changeBox(event) {
        if (event.shiftKey && this != lastChecked) {
            checkIntermediateBoxes(lastChecked, this);
        }
        lastChecked = this;
        displaySelectedCount();
    }

    function refreshBoxes() {
        boxes = Array.from(document.querySelectorAll('#gridjsMediaQueueWrapper [type="checkbox"]'));
    }

    refreshBoxes();

    boxes.forEach(item => {
        $(item).off('click.changeBox').on('click.changeBox', changeBox);
    });

    $('#btnMediaSelectAll').off('click.selectAllCheckBoxes').on('click.selectAllCheckBoxes', selectAllCheckBoxes);
    $('#btnMediaSelectNone').off('click.selectNoneCheckBoxes').on('click.selectNoneCheckBoxes', selectNoneCheckBoxes);
    $('#btnMediaInvertSelection').off('click.invertCheckBoxes').on('click.invertCheckBoxes', invertCheckBoxes);
    $('#btnMediaRemoveSelected').off('click.removeSelected').on('click.removeSelected', removeSelected);
    $('.close-icon').off('click.filterQueue').on('click.filterQueue', function () {
        setTimeout(filterQueue, 1);
    });

    updateCount();
    displaySelectedCount();
}



function alreadyAttempted(acct) {

    if (typeof acct == 'undefined') return false;

    for (var i = 0; i < acctsPreviouslyAttempted.length; i++) {
        if (acctsPreviouslyAttempted[i].id && acctsPreviouslyAttempted[i].id == acct.id) return acctsPreviouslyAttempted[i];
    }

    return false;
}

function addToAttempted(acct) {

    var acctCopy = acct;

    var d = new Date();
    acctCopy["followAttemptDate"] = '' + d.getTime();

    acctsPreviouslyAttempted.push(acctCopy);
    chrome.storage.local.set({
        acctsAttempted: acctsPreviouslyAttempted
    });
}

function ajaxFollowAllFollowings() {
    acctsQueue = theirFollowings;
    ajaxFollowAll();
}

function ajaxFollowAll() {
    if (acctsQueue.length == 0) {
        printMessage(chrome.i18n.getMessage('QueueEmpty'));
        $('#btnProcessQueue').removeClass('pulsing');


        if (document.getElementById('radioFollowAndLike').checked == true && mediaToLike.length > 0) {
            outputMessage('Loaded all media, beginning Likes...')
            likeAllMedia();
        }

        return false;
    }


    if (checkMaxActionsAndDelayIfNecessary(ajaxFollowAll) == false) {
        ajaxFollowUser(acctsQueue.shift());
    }
}

function removeAcctFromQueueDisplay(id, gray) {
    if (gray === true) {
        $('#igBotQueueContainer #' + id + '_container').css({
            'opacity': '.5'
        });
    } else {
        $('#igBotQueueContainer #' + id + '_container').fadeOut(300, function () {
            $(this).remove();
        });
    }
    updateCount();
}

function updateCount() {
    if (currentList === 'acctsWhiteList') {
        document.getElementById('igBotQueueCount').textContent = '' + acctsWhiteList.length + ' accounts';
    } else {
        document.getElementById('igBotQueueCount').textContent = '' + acctsQueue.length + ' accounts';
        document.getElementById('igBotmediaQueueCount').textContent = '' + mediaToLike.length + ' medias';
    }

    if (mediaToLike.length > 0) {
        $('#mediapaginationLimitDiv').show();
        $('#mediapaginationLimit option:selected').attr("selected", null);
        $('#mediapaginationLimit option[value="' + gblOptions.mediapaginationLimit + '"]').attr("selected", "selected");
    } else {
        $('#mediapaginationLimitDiv').hide();

    }

    if (acctsQueue.length > 0 || currentList == 'acctsWhiteList') {
        $('#paginationLimitDiv').show();
        $('#paginationLimit option:selected').attr("selected", null);
        $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");

    } else {
        $('#paginationLimitDiv').hide();
    }
}

function addStamp(id, classname, text) {

    // if (gblOptions.removeAccountsFromQueue === true) {
    //     removeAcctFromQueueDisplay(id);
    //     return false;
    // }

    if (gblOptions.showStamps === true) {
        //$('#' + id + '_container label').append('<div class="stamp-div ' + classname + '">' + text + '</div>');
        $('img.igBotQueueAcctProfilePicture[data-ig-userid="' + id + '"],img.igBotMediaQueuePicture[data-img-id="' + id + '"]').parent().append('<div class="stamp-div ' + classname + '">' + text + '</div>');
        if ($('img.igBotQueueAcctProfilePicture[data-ig-userid="' + id + '"],img.igBotMediaQueuePicture[data-img-id="' + id + '"]').parent()[0]) $('img.igBotQueueAcctProfilePicture[data-ig-userid="' + id + '"],img.igBotMediaQueuePicture[data-img-id="' + id + '"]').parent()[0].scrollIntoView();
        return true;
    }

    return false;

}

function getRandomizedTime(baseTime) {
    if (gblOptions.useRandomTimeDelay == true) {
        var minRandomTimeDelay = Math.max(0, baseTime - (baseTime * gblOptions.percentRandomTimeDelay));
        var maxRandomTimeDelay = baseTime + (baseTime * gblOptions.percentRandomTimeDelay);
        return getRandomInt(minRandomTimeDelay, maxRandomTimeDelay);
    }
    return baseTime;
}

// Mínimo garantido de 120s entre ações de SEGUIR e DEIXAR DE SEGUIR
// (mesmo com randomização ativa, nunca fica abaixo disso)
var MIN_FOLLOW_DELAY = 120000;
function getSafeActionTime(baseTime) {
    return Math.max(getRandomizedTime(baseTime), MIN_FOLLOW_DELAY);
}

function usersMediaLoaded(r) {

    var numPicsToLike = parseInt(document.getElementById('numberFollowLikeLatestPics').value);

    if (r.acct && r.edges) {

        if (numPicsToLike > r.edges.length) {
            numPicsToLike = r.edges.length;
        }

    } else {
        numPicsToLike = 0;
    }

    for (var i = 0; i < numPicsToLike; i++) {
        var pieceOfMedia = r.edges[i].node;
        pieceOfMedia.owner = r.acct;
        mediaToLike.push(pieceOfMedia);
    }

    arrayOfMediaToDiv(mediaToLike, true);

    if (alreadyLiking == false) {
        likeAllMedia();
    }

}

function ajaxFollowUser(acct) {

    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }


    var promises = [];
    let followable = true;

    if (!acct) {
        outputMessage('no account');
        return false;
    }

    var acctFromStorage = alreadyAttempted(acct);
    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);
    var acctsQueueNextUsername = '';
    if (acctsQueue.length > 0) {
        acctsQueueNextUsername = acctsQueue[0].username;
    }

    if (gblOptions.followPeopleAlreadyAttempted === false && acctFromStorage !== false) {
        acctsProcessed.push(acct);
        outputMessage(acct.username + ' already attempted ' + timeToDate(acctFromStorage.followAttemptDate) + ': skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'attempted');
        timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
        return false;
    } else if (acct.followed_by_viewer == true) {
        acctsProcessed.push(acct);
        outputMessage(acct.username + ' already being followed: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'followed');
        timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
        return false;
    } else if (acct.requested_by_viewer == true) {
        acctsProcessed.push(acct);
        outputMessage(acct.username + ' already requested: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'requested');
        timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
        return false;
    } else if (acct.is_private == true && gblOptions.followPrivateAccounts != true) {
        acctsProcessed.push(acct);
        outputMessage(acct.username + ' is private: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'private');
        timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
        return false;
    } else if (gblOptions.filterOptions.applyFiltersAutomatically == true) {
        promises.push(filterCriteriaMet(acct).then((met) => {
            if (met == false) {
                followable = false;
            }
        }));
    }

    Promise.all(promises).then(function () {

        if (followable === false) {
            acctsProcessed.push(acct);
            outputMessage(acct.username + ' did not match your filters: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);

            if (acct.assumedDeleted) {
                addStamp(acct.id, 'stamp-div-red', '404');
            } else {
                addStamp(acct.id, 'stamp-div-grey', 'filtered');
            }

            if (noAcctsLeft()) return false;
            printMessage(' ');
            timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
            return false;
        }

        waitTime = getSafeActionTime(gblOptions.timeDelay);

        $.ajax({
            //url: 'https://www.instagram.com/web/friendships/' + acct.id + '/follow/',
            url: 'https://www.instagram.com/api/v1/friendships/create/' + acct.id + '/',
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function () {

                acctsProcessed.push(acct);
                actionsTaken++;
                addStamp(acct.id, 'stamp-div-green', 'followed');
                addToAttempted(acct);

                outputMessage('Followed ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed;  waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
                timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));

                if (document.getElementById('radioFollowAndLike').checked == true) {
                    ajaxLoadUsersMedia('', false, usersMediaLoaded, acct);
                }
            })
            .fail(function (data) {
                data.status = Number(data.status);
                if (data.status !== 404) {
                    acctsQueue.unshift(acct);
                }

                if (data.status == 404) {
                    gblFollow404Count++;
                    printMessage(acct.username + ' ' + chrome.i18n.getMessage('AccountNotFound404'));
                    addStamp(acct.id, 'stamp-div-red', '404');
                    acctsProcessed.push(acct);
                    addToAttempted(acct);
                    if (gblFollow404Count >= 10) {
                        gblFollow404Count = 0;
                        outputMessage('Many 404s in a row. Login may have been invalidated - reload the page and re-login if Instagram asks, then restart the queue');
                        timeoutsQueue.push(setTimeout(ajaxFollowAll, 60000));
                    } else {
                        timeoutsQueue.push(setTimeout(ajaxFollowAll, 1000));
                    }
                } else if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    if (data.responseJSON && data.responseJSON.message) {
                        if (data.responseJSON.feedback_title) {
                            outputMessage(data.responseJSON.feedback_title);
                        }

                        if (data.responseJSON.feedback_url) {
                            outputMessage(data.responseJSON.feedback_url);
                        }

                        if (data.responseJSON.feedback_message) {
                            if (data.responseJSON.feedback_message.indexOf('blocked') > -1) {
                                outputMessage('Message from Instagram (*NOT* Growbot): ' + data.responseJSON.feedback_message);
                            }
                        }
                        // verificar se atingiu o máximo
                        if (data.responseJSON.message.indexOf('max') > -1) {
                            $('#btnProcessQueue').removeClass('pulsing');
                            alert(data.responseJSON.message);
                            alert('If you have reached the maximum number of following, please note that pending follow requests on private accounts are counted by instagram as following.  You can see your pending requests by clicking the Load Pending Follow Requests button.');
                            return false;
                        }
                    }

                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    outputMessage(data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, 5000));
                }
            });
    });
}


function ajaxLoadPostsFromHashtag(after) {

    if (typeof after != 'string') after = '';

    var hashtag = getHashtagFromUrl();

    if (hashtag == '') {
        outputMessage('Error - not on hashtag page');
        return false;
    }

    var count = 50;

    if (!isNaN(document.getElementById('txtLimitMediaQueueSize').value)) {
        count = document.getElementById('txtLimitMediaQueueSize').value;
    }


    document.getElementById('btnLikeHashtag').classList.add('pulsing');


    $.ajax({
        url: 'https://i.instagram.com/api/v1/tags/' + hashtag + '/sections/',
        data: after,
        method: 'POST',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (data) {

            if (data.more_available == true && (mediaToLike.length < parseInt(gblOptions.maxMediaQueueLength) || gblOptions.limitMediaQueue !== true)) {



                var medias = allNodes(data, 'media');
                for (var i = 0; i < medias.length; i++) {
                    mediaToLike.push(medias[i]);
                }

                mediaToLike = uniq(mediaToLike);

                printMessage('Loaded ' + mediaToLike.length + ' media out of ' + gblOptions.maxMediaQueueLength);

                outputMessage(mediaToLike.length + ' media out of ' + count + ' loaded to media queue')
                arrayOfMediaToDiv(mediaToLike, false);



                after = {
                    "max_id": data.next_max_id,
                    "page": data.next_page,
                    "next_media_ids": data.next_media_ids,
                    "tab": "recent",
                    "surface": "grid",
                    "include_persistent": 0
                }

                timeoutsQueue.push(setTimeout(function () {
                    ajaxLoadPostsFromHashtag(after);
                }, 500));

            } else {

                $('#btnLikeHashtag').removeClass('pulsing');

                arrayOfMediaToDiv(mediaToLike, true);
                printMessage(chrome.i18n.getMessage('Done'));

            }


        }).fail(function (f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function () {
                    ajaxLoadPostsFromHashtag(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });



}



function allNodes(obj, key, array) {
    array = array || [];
    if ('object' === typeof obj) {
        for (let k in obj) {
            if (k === key) {
                array.push(obj[k]);
            } else {
                allNodes(obj[k], key, array);
            }
        }
    }
    return array;
}

function uniq(arr) {


    const ids = arr.map(o => o.id)
    const filtered = arr.filter(({
        id
    }, index) => !ids.includes(id, index + 1))

    return filtered;

}


function getLocationFromUrl() {

    if (window.location.href.indexOf('/explore/locations/') == -1) {
        return '';
    }

    var tagFromUrl = window.location.href;
    tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/locations/', '');
    tagFromUrl = tagFromUrl.slice(0, tagFromUrl.indexOf('/'));

    tagFromUrl = decodeURIComponent(tagFromUrl);

    return tagFromUrl;

}


function ajaxLoadPostsFromLocation(after) {

    var location = getLocationFromUrl();

    if (location == '') {
        outputMessage('Error - not on location page');
        return false;
    }

    $('#btnLoadLocationPosts').addClass('pulsing');


    if (!after.page) {
        printMessage('Loading media from location: ' + location);

        // the first request has a different URL and is a get request
        var url = 'https://www.instagram.com/api/v1/locations/web_info/?location_id=' + location + '&show_nearby=false';
        var method = 'GET';
        after = {};
    } else {
        var url = 'https://www.instagram.com/api/v1/locations/' + location + '/sections/';
        var method = 'POST';
    }

    $.ajax({
        url: url,
        data: after,
        method: method,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (data) {

            var medias = allNodes(data, 'media');
            for (var i = 0; i < medias.length; i++) {
                mediaToLike.push(medias[i]);
            }

            mediaToLike = uniq(mediaToLike);

            printMessage('Loaded ' + mediaToLike.length + ' media out of ' + gblOptions.maxMediaQueueLength);

            arrayOfMediaToDiv(mediaToLike, false);

            // para a primeira chamada da api
            if (data.native_location_data && data.native_location_data.recent) {
                data = data.native_location_data.recent;
            }

            if (data.more_available == true && (mediaToLike.length < parseInt(gblOptions.maxMediaQueueLength) || gblOptions.limitMediaQueue !== true)) {

                after = {
                    "max_id": JSON.stringify(data.next_max_id),
                    "page": data.next_page,
                    "next_media_ids": JSON.stringify(data.next_media_ids),
                    "tab": "recent",
                    "surface": "grid",
                }

                timeoutsQueue.push(setTimeout(function () {
                    ajaxLoadPostsFromLocation(after);
                }, 200));
            } else {
                $('#btnLoadLocationPosts').removeClass('pulsing');

                printMessage(chrome.i18n.getMessage('Done'));
                printMessage(' ');
            }


        }).fail(function (f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function () {
                    ajaxLoadPostsFromLocation(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });

}



function LoadAccountsFromMedia() {

    if (mediaToLike.length == 0) {
        outputMessage('Error - no media loaded, please load media on the media queue tab');
        return false;
    }

    $('#btnLoadMediaPosters').addClass('pulsing');

    if (gblOptions.MediaIncludeLikersCommentersTagged == true) {
        var owners = allNodes(mediaToLike, 'owner');
        for (var i = 0; i < owners.length; i++) {
            var u = owners[i];

            if (u && u.pk) u.id = u.pk;
            if (u != null) acctsQueue.push(u);
        }

        var users = allNodes(mediaToLike, 'user');
        for (var i = 0; i < users.length; i++) {
            var u = users[i];
            if (u && u.pk) u.id = u.pk;
            if (u != null) acctsQueue.push(u);
        }
    } else {
        for (var i = 0; i < mediaToLike.length; i++) {
            if (mediaToLike[i].owner) {
                var u = mediaToLike[i].owner;
                if (u && u.pk) u.id = u.pk;
                if (u != null) acctsQueue.push(u);
            }
        }
    }


    acctsQueue = uniq(acctsQueue);


    // truncateQueue(gblOptions.truncateStart);


    arrayOfUsersToDiv(acctsQueue, true);

    $('#btnLoadMediaPosters').removeClass('pulsing');

    printMessage(chrome.i18n.getMessage('Done'));
    printMessage(' ');
}

async function ajaxLikeAllPostsFromFeed(after) {
    // Verificar licença antes de curtir feed
    if (!vpLicenseGuard()) return false;

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var count = '??';
    if (gblOptions.limitMediaQueue == true && !isNaN(document.getElementById('txtLimitMediaQueueSize').value)) {
        count = document.getElementById('txtLimitMediaQueueSize').value;
    }

    document.getElementById('btnLikeFeed').classList.add('pulsing');

    const fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
        "headers": {
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "priority": "u=1, i",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-asbd-id": "129477",
            "x-csrftoken": getCsrfFromCookie(),
            "x-fb-friendly-name": "PolarisProfilePostsQuery",
            "x-ig-app-id": "936619743392459"
        },
        "referrer": "https://www.instagram.com/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=t&__hs=20154.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020686322&__s=0fq4up%3Aqwk9fx%3Aztxdzb&__hsi=7479118361645267327&__dyn=7xeUjG1mxu1syUbFp41twpUnwgU7SbzEdF8aUco2qwJxS0DU2wx609vCwjE1EE2Cw8G11wBz81s8hwGxu786a3a1YwBgao6C0Mo2iyo7u3ifK0EUjwGzEaE2iwNwmE2eUlwhEe87q0oa2-azqwt8d-2u2J0bS1LwTwKG1pg2fwxyo6O1FwlEcUed6goK2O4Xxui2qi7E5y4UrwHwGwa6bBK4o&__csr=goMB1hb2tRfdQwxbpLTSRvmhQB8jpqhWHA-BmnJkhQhrGRzGcUD9yV9p9oShAQ9GmUytfhAvAijVifBpaJ5AyummmqFGWABBypaJ4pohy49yVfCG8leoFA8Ahp8Kt4BleEK8x2UhAgyim8haBXDAWUF1J28jz8jVH-2lxCE01cu9FA9w2vVlhEkdV4vIwqwhQ0mO1axlwxGE2c81DxS1Aw39U1iU1-U1EE1ie26eg16C0wXwyxqfQAu5O2K4soTp83gyU421BU4JCg4a48ybxa5abwcR0d6mU5m0icgay9UCpwB2msg3K05Gcw06si0D80kDw&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=NAcODTLMt5kxM-9MlWOVJnE0CiZb6vhOikbp1xwiOVjWF9npxxboJ3g%3A17843683126168011%3A1741209447&jazoest=26370&lsd=kulaA_fnsLsmyiVZWRxfLZ&__spin_r=1020686322&__spin_b=trunk&__spin_t=1741367942&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisFeedRootPaginationCachedQuery_subscribe&variables=%7B" + after + "%22before%22%3Anull%2C%22data%22%3A%7B%22device_id%22%3A%22E1F25225-A6AE-44CF-9EC8-932EC7E261CB%22%2C%22is_async_ads_double_request%22%3A%220%22%2C%22is_async_ads_in_headload_enabled%22%3A%220%22%2C%22is_async_ads_rti%22%3A%220%22%2C%22rti_delivery_backend%22%3A%220%22%7D%2C%22first%22%3A12%2C%22last%22%3Anull%2C%22variant%22%3A%22home%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisShareSheetV3relayprovider%22%3Afalse%7D&server_timestamps=true&doc_id=28982951317985068",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    });

    var jsonData = await fetchMedia.json();
    var r = jsonData.data.xdt_api__v1__feed__timeline__connection;

    if (r.edges) {
        for (var i = 0; i < r.edges.length; i++) {
            var mediaNode = r.edges[i].node.media;
            if (gblOptions.includeSuggestedPostsFromFeed == true || (mediaNode && mediaNode != null && mediaNode.owner && mediaNode.owner != null && mediaNode.owner.friendship_status && mediaNode.owner.friendship_status.following == true)) {
                if (mediaNode && mediaNode.id) mediaToLike.push(mediaNode);
            }
        }
        var hasNextPage = r.page_info.has_next_page;
        if (hasNextPage == true) {
            after = r.page_info.end_cursor;
        }
        arrayOfMediaToDiv(mediaToLike, false);
    } else {
        printMessage(' ');
        printMessage(' ');
        outputMessage('Error liking feed - please report to growbotautomator@gmail.com');
        printMessage(' ');
        printMessage(' ');
    }

    if ((hasNextPage == true && after != '') && (gblOptions.limitMediaQueue == false || mediaToLike.length < gblOptions.maxMediaQueueLength)) {
        outputMessage(mediaToLike.length + ' media out of ' + count + ' loaded to media queue.')
        timeoutsQueue.push(setTimeout(function () {
            ajaxLikeAllPostsFromFeed(after);
        }, 500));
    } else {
        document.getElementById('btnLikeFeed').classList.remove('pulsing');
        printMessage('Done.');
    }


}

async function watchReels() {
    // Verificar licença antes de assistir reels
    if (!vpLicenseGuard()) return false;

    var reels = mediaToLike.filter(e => e.media_type == 2 || e.is_video == true);

    for (var i = 0; i < reels.length; i++) {

        reels[i].SaveWhenWatchingReel = gblOptions.SaveWhenWatchingReel;
        reels[i].LikeWhenWatchingReel = gblOptions.LikeWhenWatchingReel;

        var done = await watchReel(reels[i]);

        addStamp(reels[i].id, 'stamp-div-green', 'watched');

        if (timeoutsQueue.length == 0) break;

    }

}

function watchReel(reel) {

    return new Promise(function (resolve, reject) {

        chrome.runtime.sendMessage({
            "openReelTab": reel
        });

        timeoutsQueue.push(
            setTimeout(function () {
                resolve(true);
            }, ((reel.video_duration || 20) * 1000) + 5)
        );

    });

}

function likeAllMedia() {
    // Verificar licença antes de curtir mídia
    if (!vpLicenseGuard()) { alreadyLiking = false; return false; }

    alreadyLiking = true;
    if (gblOptions.showLikesInQueue === true) {
        handleImagePreload();
        handleMediaCheckBoxes(mediaToLike);
    }

    if (mediaToLike.length == 0) {
        $('#btnLikeFeed,#btnLikeHashtag').removeClass('pulsing');
        alreadyLiking = false;
        return false;
    }

    var media = mediaToLike.shift();
    var id = media.id;

    for (var i = 0; i < previousLikes.length; i++) {
        if (id == previousLikes[i]) {
            outputMessage('Already liked, moving on...');
            addStamp(media.id, 'stamp-div-grey', 'skipped');

            timeoutsQueue.push(setTimeout(likeAllMedia, 1));
            return false;
        }
    }

    likeMedia(media);
}

function likeMedia(media) {

    var idToLike = getMediaIdForLike(media);
    var actorId = getInstagramActorId();
    var lsd = getInstagramLsdToken();
    var fbDtsg = getInstagramFbDtsg();
    var jazoest = getInstagramJazoest(fbDtsg);

    if (!idToLike) {
        outputMessage('Like skipped: missing media id');
        timeoutsQueue.push(setTimeout(likeAllMedia, 1));
        return false;
    }
    if (!actorId || !lsd || !fbDtsg) {
        outputMessage('Like failed: missing Instagram session tokens (reload instagram.com and try again)');
        mediaToLike.unshift(media);
        timeoutsQueue.push(setTimeout(likeAllMedia, 5000));
        return false;
    }

    var mutationVariables = {
        input: {
            media_id: idToLike,
            actor_id: actorId,
            client_mutation_id: "1"
        }
    };

    var body = [
        'av=' + encodeURIComponent(actorId),
        '__d=www',
        '__user=0',
        '__a=1',
        '__comet_req=7',
        'fb_dtsg=' + encodeURIComponent(fbDtsg),
        'jazoest=' + encodeURIComponent(jazoest),
        'lsd=' + encodeURIComponent(lsd),
        'fb_api_caller_class=RelayModern',
        'fb_api_req_friendly_name=PolarisAPILikePostMutation',
        'server_timestamps=true',
        'variables=' + encodeURIComponent(JSON.stringify(mutationVariables)),
        'doc_id=27232073366423857'
    ];

    $.ajax({
        url: 'https://www.instagram.com/api/graphql',
        method: 'POST',
        data: body.join('&'),
        dataType: 'json',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-asbd-id', '359341');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            xhr.setRequestHeader('x-fb-friendly-name', 'PolarisAPILikePostMutation');
            xhr.setRequestHeader('x-fb-lsd', lsd);
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (data, textStatus, xhr) {
            var parsed = parseInstagramGraphqlLikeResult(data);
            if (!parsed.ok) {
                var responseSnippet = '';
                try {
                    responseSnippet = JSON.stringify(data).substring(0, 300);
                } catch (e) {
                    responseSnippet = xhr && xhr.responseText ? xhr.responseText.substring(0, 300) : parsed.message;
                }
                handleLikeMediaFailure(media, xhr && xhr.status ? xhr.status : 'graphql', responseSnippet || parsed.message);
                return;
            }
            handleLikeMediaSuccess(media);
        })
        .fail(function (xhr) {
            var status = xhr && typeof xhr.status !== 'undefined' ? xhr.status : '';
            var responseText = xhr && xhr.responseText ? xhr.responseText : '';
            var responseSnippet = responseText ? responseText.substring(0, 300) : '';
            handleLikeMediaFailure(media, status, responseSnippet);
        });
}

async function populateAllQueueUsersInfo(q) {
    for (var i = 0; i < q.length; i++) {
        q[i] = await getAdditionalDataForAcct(q[i]);

        var $$tr = $('#cb_' + q[i].id).parents('tr[role="row"]');

        for (const [key, value] of Object.entries(q[i])) {

            var cols = gbDefaultColumns;
            cols = cols.filter(c => c.data == key);

            var $$td = $$tr.children('td[column-data="' + key + '"]');
            if ($$td.html() == '' || $$td.text() == '-' || $$td.attr('column-data') == 'external_url') {
                $$td.text(value);
                if (cols[0] && cols[0].formatter && typeof value != 'undefined' && value != null) {
                    $$td.html(cols[0].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, value));
                }
            }
        }

        printMessage(chrome.i18n.getMessage('DataLoaded', [(i + 1), q.length]));
    }

    acctsQueue = q;

    if (window.confirm('Delete accounts which were not found?')) {
        var newq = q;
        newq = newq.filter(e => e.hasOwnProperty('assumedDeleted') == false);
        acctsQueue = newq;
    }

    arrayOfUsersToDiv(acctsQueue, true);

    if (window.confirm(chrome.i18n.getMessage('FinishedAdditionalData'))) {
        saveQueueToStorageAndDisk();
    }

    $('#btnProcessQueue').removeClass('pulsing');
}

function maxActionsExceeded() {
    if (gblOptions.maxPerEnabled == true && (actionsTaken >= gblOptions.maxPerActions)) {
        var todaysdate = new Date();
        maxActionsDelayStartTime = todaysdate.getTime();

        return true;
    }
    return false;
}

function maxActionsDelayRemaining() {
    var todaysdate = new Date();
    var today = todaysdate.getTime();
    var timeSinceActionsMaxed;
    timeSinceActionsMaxed = today - maxActionsDelayStartTime;

    return (gblOptions.maxPerPeriod - timeSinceActionsMaxed);
}

function checkMaxActionsAndDelayIfNecessary(callback) {
    if (maxActionsExceeded() && maxActionsDelayRemaining() > 0) {
        timeoutsQueue.push(setTimeout(callback, maxActionsDelayRemaining()));
        outputMessage('Max actions exceeded, waiting ' + millisecondsToHumanReadable(maxActionsDelayRemaining(), true))

        actionsTaken = 0;

        return true;
    }

    return false;
}


function ajaxRemoveOrBlockAll() {
    // Verificar licença antes de remover/bloquear
    if (!vpLicenseGuard()) return false;
    if (checkMaxActionsAndDelayIfNecessary(ajaxRemoveOrBlockAll) == false) {
        ajaxRemoveOrBlockAcct(acctsQueue.pop());
    }
}


function viewStories() {
    // Verificar licença antes de ver stories
    if (!vpLicenseGuard()) return false;
    if (checkMaxActionsAndDelayIfNecessary(viewStories) == false) {
        viewStory(acctsQueue.pop());
    }
}

async function viewStory(acct) {

    acct = await getAdditionalDataForAcct(acct);

    if (acct.is_private === true && acct.followed_by_viewer === false) {
        addStamp(acct.id, 'stamp-div-grey', 'private');
        outputMessage('Skipping ' + acct.username + ' because it is a private account');
        timeoutsQueue.push(setTimeout(viewStories, gblOptions.timeDelayAfterSkip));
        return false;
    }

    if (acct.assumedDeleted == true) {
        addStamp(acct.id, 'stamp-div-red', '404');
        outputMessage('Skipping ' + acct.username + ' because it is missing');
        timeoutsQueue.push(setTimeout(viewStories, gblOptions.timeDelayAfterSkip));
        return false;
    }

    chrome.runtime.sendMessage({
        "openStoryTab": {
            "username": acct.username,
            "LikeWhenWatchingStory": document.getElementById('cbViewStoryLike').checked,
            "acct": acct
        }
    });

    // closedStoryTab(acct);

}

function closedStoryTab(request) {

    var acct = request.acct;

    if (request.viewed == true) {
        addStamp(acct.id, 'stamp-div-green', 'Viewed Story');
    } else {
        addStamp(acct.id, 'stamp-div-grey', 'No Story');
    }

    if (noAcctsLeft()) {
        return false;
    }

    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var waitTime = getRandomizedTime(gblOptions.timeDelay);

    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to view ' + acctsQueue[acctsQueue.length - 1].username + ' story');
    timeoutsQueue.push(setTimeout(viewStories, waitTime));
    return false;
}

function ajaxUnfollowAll() {
    // Verificar licença antes de desseguir
    if (!vpLicenseGuard()) return false;
    if (checkMaxActionsAndDelayIfNecessary(ajaxUnfollowAll) == false) {
        ajaxUnfollowAcct(acctsQueue.pop());
    }
}

function quickUnfollowAcct(acct) {
    $.ajax({
        url: 'https://www.instagram.com/web/friendships/' + acct.id + '/unfollow/',
        method: 'POST',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function () {
            outputMessage('Unfollowed ' + acct.username + ' (' + acct.id + ') using button');
            $('.igBotInjectedLinkWhitelist[data-username="' + acct.username + '"]').parents('article').fadeOut();
        })
        .fail(function (data) {
            if (data.status == 403) {
                alert('soft rate limit encountered, failed to unfollow ' + acct.username);
            } else if (data.status == 400) {
                alert('hard rate limit encountered, failed to unfollow ' + acct.username);
            } else {
                alert('Error ' + data.status + ', failed to unfollow ' + acct.username);
            }
        })
}

function ajaxUnfollowAcct(acct) {
    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var promises = [];
    let unfollowable = true;

    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);

    if (typeof acct == 'undefined') {
        noAcctsLeft();
        return false;
    }

    if (containsObject(acct, acctsWhiteList) == true) {
        outputMessage(acct.username + ' is whitelisted, skipping');
        addStamp(acct.id, 'stamp-div-grey', 'whitelisted');
        acctsProcessed.push(acct);
        setTimeout(ajaxUnfollowAll, 1);
        return false;
    }


    if (gblOptions.dontUnFollowNonGrowbot === true) {
        var acctFromStorage = alreadyAttempted(acct);
        if (acctFromStorage === false) {
            outputMessage(acct.username + ' was followed outside of Growbot, skipping');
            addStamp(acct.id, 'stamp-div-grey', 'non-growbot');
            acctsProcessed.push(acct);
            setTimeout(ajaxUnfollowAll, 1);
            return false;
        }
    }

    if (gblOptions.dontUnFollowFilters == true || gblOptions.dontUnFollowFollowers == true || gblOptions.unFollowIfOld == true) {
        promises.push(filterCriteriaMetForUnfollowing(acct).then((met) => {
            if (met == false) {
                unfollowable = false;
            }
        }));
    }

    Promise.all(promises).then(function () {
        if (unfollowable === false) {
            acctsProcessed.push(acct);
            outputMessage(acct.username + ' skipped (matches your filters)');

            if (acct.assumedDeleted) {
                addStamp(acct.id, 'stamp-div-red', '404');

            } else {
                addStamp(acct.id, 'stamp-div-grey', 'matches filters');
            }


            if (noAcctsLeft()) {
                return false;
            } else {
                outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to unfollow ' + acctsQueue[acctsQueue.length - 1].username);
                timeoutsQueue.push(setTimeout(ajaxUnfollowAll, waitTime));
                return false;
            }
        }

        waitTime = getSafeActionTime(gblOptions.timeDelay);

        $.ajax({
            //url: 'https://www.instagram.com/web/friendships/' + acct.id + '/unfollow/',
            url: 'https://www.instagram.com/api/v1/friendships/destroy/' + acct.id + '/',
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function () {

                acctsProcessed.push(acct);
                actionsTaken++;
                addStamp(acct.id, 'stamp-div-green', 'unfollowed');

                outputMessage('Unfollowed ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed, ' + acctsQueue.length + ' left to go');


                if (noAcctsLeft()) {
                    return false;
                } else {
                    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to unfollow ' + acctsQueue[acctsQueue.length - 1].username);
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, waitTime));
                }

            })
            .fail(function (data) {
                data.status = Number(data.status);
                if (data.status !== 404) {
                    acctsQueue.push(acct);
                }

                if (data.status == 404) {
                    gblUnfollow404Count++;
                    printMessage(acct.username + ' ' + chrome.i18n.getMessage('AccountNotFound404'));
                    addStamp(acct.id, 'stamp-div-red', '404');
                    if (gblUnfollow404Count >= 10) {
                        gblUnfollow404Count = 0;
                        outputMessage('Many 404s in a row. Login may have been invalidated - reload the page and re-login if Instagram asks, then restart the queue');
                        timeoutsQueue.push(setTimeout(ajaxUnfollowAll, 60000));
                    } else {
                        timeoutsQueue.push(setTimeout(ajaxUnfollowAll, 1000));
                    }
                } else if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    outputMessage(data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, 5000));
                }
            })
    });

}

function ajaxRemoveOrBlockAcct(acct) {
    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var promises = [];
    let removable = true;

    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);

    if (typeof acct == 'undefined') {
        noAcctsLeft();
        return false;
    }

    if (containsObject(acct, acctsWhiteList) == true) {
        outputMessage(acct.username + ' is whitelisted, skipping');
        addStamp(acct.id, 'stamp-div-grey', 'whitelisted');
        acctsProcessed.push(acct);
        setTimeout(ajaxRemoveOrBlockAll, 1);
        return false;
    }

    if (gblOptions.dontRemoveOrBlockFilters == true) {
        promises.push(filterCriteriaMetForRemoveOrBlock(acct).then((met) => {
            if (met == false) {
                removable = false;
            }
        }));
    }

    Promise.all(promises).then(function () {

        var removeOrBlockEndpoint = '/remove_follower/';
        var removeOrBlockString = 'Remove';
        var removedOrBlockedString = 'Removed';


        if (document.getElementById('radioBlock').checked === true) {
            removeOrBlockEndpoint = '/block/';
            removeOrBlockString = 'Block'
            removedOrBlockedString = 'Blocked';
        }

        if (removable === false) {
            acctsProcessed.push(acct);

            outputMessage(acct.username + ' skipped (matches your filters)');
            addStamp(acct.id, 'stamp-div-grey', 'matches filters');


            if (noAcctsLeft()) {
                return false;
            } else {
                outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to ' + removeOrBlockString + ' ' + acctsQueue[acctsQueue.length - 1].username);
                timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, waitTime));
                return false;
            }
        }

        waitTime = getRandomizedTime(gblOptions.timeDelay);

        $.ajax({
            url: 'https://www.instagram.com/web/friendships/' + acct.id + removeOrBlockEndpoint,
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function () {
                acctsProcessed.push(acct);
                actionsTaken++;
                addStamp(acct.id, 'stamp-div-green', removedOrBlockedString);

                outputMessage(removedOrBlockedString + ' ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed, ' + acctsQueue.length + ' left to go');

                if (noAcctsLeft()) {
                    return false;
                } else {
                    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to ' + removeOrBlockString + ' ' + acctsQueue[acctsQueue.length - 1].username);
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, waitTime));
                }

            })
            .fail(function (data) {
                acctsQueue.push(acct);
                if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    outputMessage(data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, 5000));
                }
            })
    });

}

function noAcctsLeft() {
    if (acctsQueue.length === 0) {
        outputMessage('No accounts left!');
        $('#btnProcessQueue').removeClass('pulsing');
        return true;
    }
    return false;
}

function injectIcon() {
    var imgURL = chrome.runtime.getURL("icon_48.png");

    $('#instabotIcon').remove();

    $('body').prepend('<div id="instabotIcon" title="Hide or Show Growbot"></div>');

    $('#instabotIcon').css({
        'top': '0px',
        'right': '0px',
        'background-image': 'url("' + imgURL + '")'
    }).click(toggleControlsDiv);
}

function injectVersionNumber() {
    var versionEl = document.getElementById('igBotExtensionVersion');
    var headingEl = document.getElementById('h1GrowbotHeading');
    if (versionEl) versionEl.textContent = chrome.runtime.getManifest().version;
    if (headingEl) headingEl.textContent = 'Vísion Plus Automatizador ' + chrome.runtime.getManifest().version;
}

function hideControlsDiv(save) {

    $('#igBotInjectedContainer').hide();
    shakeInstabotIcon();

    if (save && save == false) return true;

    saveHiddenStatus(true);
}

function shakeInstabotIcon() {
    $('#instabotIcon').shake(50, 2, 8);
}

function toggleControlsDiv() {
    $('#igBotInjectedContainer').toggle({
        effect: "scale",
        direction: "both",
        origin: ["top", "center"],
        complete: function () {
            setTimeout(function () {
                var isVisible = $('#igBotInjectedContainer').is(":visible");
                saveHiddenStatus(!isVisible);
            }, 100);
        }
    });
}

function openControlsDiv() {
    try {
        var igContainer = document.getElementById('igBotInjectedContainer');
        if (igContainer && igContainer.style.getPropertyValue('display') === 'none') {
            igContainer.style.removeProperty('display');
        }
    } catch(e) {}
    
    var isVisible = $('#igBotInjectedContainer').is(":visible");
    if (isVisible == false) {
        toggleControlsDiv();
    }
}

function injectControlsDiv() {

    if (shouldLoadGrowbotOnThisPage() == false) return false;

    $('#igBotInjectedContainer').remove();

    $.get(chrome.runtime.getURL('growbot.html'), function (data) {
        $('body').prepend($.parseHTML(data));
        localizeExtension();

        chrome.storage.local.get("growbotLog", function (data) {
            if (typeof data.growbotLog != 'undefined') {
                var logFromStorage = data.growbotLog;
                var fakeConsole = document.getElementById('txtConsole');
                fakeConsole.textContent = logFromStorage + '\n\n';
                fakeConsole.scrollTop = fakeConsole.scrollHeight;
                includeLogInMailToLinks();
            }
        });


        loadOptions();
        loadWhiteList();
        loadPreviousAttempts();
        injectVersionNumber();
        loadActionsQueue();


        ready(igExternalVars.qsForConvenienceButtons, function (element) {
            return addNewConvenienceLinks(element);
        });
        ready(igExternalVars.qsForConvenienceButtonsProfile, function (element) {
            return addNewConvenienceLinks(element, {
                isProfile: true
            });
        });
        setTimeout(function () {
            ensureProfileConvenienceLinks();
        }, 500);
        getHiddenStatus(hiddenStatusCallback);


        setTimeout(function () {
            if (gblOptions.loadQueueOnStartup == true) {
                loadQueueFromLocal();
            }
        }, 1000);

        // Garante a sincronização das configurações de IA após a injeção do HTML
        setTimeout(syncAiSettings, 1500);

    });
}

function localizeExtension() {
    $('#igBotInjectedContainer [localeMessage]').each(function () {
        var localeMessage = chrome.i18n.getMessage($(this).attr('localeMessage'));
        if (localeMessage.length > 0) {
            $(this).text(localeMessage);
        }
    });

    $('#igBotInjectedContainer [localeReplaceString]').each(function () {
        $(this).text($(this).text().replace($(this).attr('localeReplaceString'), chrome.i18n.getMessage($(this).attr('localeReplaceString').replace(/ /g, '_'))));
    });
}

function buildMessagesJson() {
    var jsonbuilder = '';

    $('#igBotInjectedContainer [localeMessage]').each(function () {
        var titlestr = '';
        if ($(this).attr('title')) {
            titlestr = ', "title": "' + $(this).attr('title') + '"';
        }
        var str2add = '"' + $(this).attr('localeMessage') + '": { "message": "' + $(this).html() + '"' + titlestr + '},'
        if (jsonbuilder.indexOf(str2add) == -1) jsonbuilder = jsonbuilder + str2add;

        if ($(this).html() == '') {
            alert($(this).attr('localeMessage'));
        }
    });
}

(function (win) {
    'use strict';

    var listeners = [],
        doc = win.document,
        MutationObserver = win.MutationObserver || win.WebKitMutationObserver,
        observer;

    function ready(selector, fn) {
        // Armazenar o seletor e callback para ser monitorado
        listeners.push({
            selector: selector,
            fn: fn
        });
        if (!observer) {
            // Observar mudanças no documento
            observer = new MutationObserver(check);
            observer.observe(doc.documentElement, {
                childList: true,
                subtree: true
            });
        }
        // Verificar se o elemento está atualmente no DOM
        check();
    }

    function check() {
        // Verificar o DOM em busca de elementos correspondentes a um seletor armazenado
        for (var i = 0, len = listeners.length, listener, elements; i < len; i++) {
            listener = listeners[i];
            // Consultar elementos correspondentes ao seletor especificado
            elements = doc.querySelectorAll(listener.selector);
            for (var j = 0, jLen = elements.length, element; j < jLen; j++) {
                element = elements[j];
                // Garantir que o callback não seja invocado com o
                // mesmo elemento mais de uma vez
                if (!element.ready) {
                    var result = listener.fn.call(element, element);
                    if (result !== false) {
                        element.ready = true;
                    }
                }
            }
        }
    }

    // Expor `ready`
    win.ready = ready;

})(this);



function ajaxLikeAll() {
    if (noAcctsLeft() == false) {
        getUsersMedia(acctsQueue.shift());
    } else {
        outputMessage('Done loading media, beginning likes...');
        likeAllMedia();
    }
}

function getUsersMedia(acct) {

    var acctsQueueNextUsername = '';
    removeAcctFromQueueDisplay(acct.id, true);
    if (noAcctsLeft() === false) {
        acctsQueueNextUsername = acctsQueue[0].username;
    }

    ajaxLoadUsersMedia('', false, usersMediaLoaded, acct);

    var waitTime = getRandomizedTime(gblOptions.timeDelay);

    outputMessage('Adding media for ' + acct.username + ' (' + acct.id + ') to like queue;  waiting  ' + (waitTime / 1000) + ' seconds to process ' + acctsQueueNextUsername);

    timeoutsQueue.push(setTimeout(ajaxLikeAll, waitTime));
}

function initProcessQueue() {
    // ============ VERIFICAÇÃO DE LICENÇA ANTES DE QUALQUER AÇÃO ============
    if (!vpLicenseGuard()) {
        return false;
    }

    var todaysdate = new Date();
    maxActionsDelayStartTime = todaysdate.getTime();

    $('#btnProcessQueue').addClass('pulsing');

    if (document.getElementById('radioFollow').checked === true || document.getElementById('radioFollowAndLike').checked === true) {
        ajaxFollowAll();
    } else if (document.getElementById('radioUnFollow').checked === true) {
        initUnfollowMyFollowers();
    } else if (document.getElementById('radioLikeOnly').checked === true) {
        ajaxLikeAll();
    } else if (document.getElementById('radioBlock').checked === true || document.getElementById('radioRemoveFromFollowers').checked === true) {
        ajaxRemoveOrBlockAll();
    } else if (document.getElementById('radioGetMoreData').checked === true) {

        var safeDelaySeconds = 1;

        if (acctsQueue.length > 100) safeDelaySeconds = 2;
        if (acctsQueue.length > 500) safeDelaySeconds = 3;
        if (acctsQueue.length > 1000) safeDelaySeconds = 4;
        if (acctsQueue.length > 2000) safeDelaySeconds = 5;
        if (acctsQueue.length > 3000) safeDelaySeconds = 6;
        if (acctsQueue.length > 4000) safeDelaySeconds = 10;



        if (acctsQueue.length > 40 && (gblOptions.useTimeDelayAfterAdditionalInfo == false || document.getElementById('texttimeDelayAfterAdditionalInfo').value < safeDelaySeconds)) {

            dialog({
                no: "No",
                yes: "Yes",
                question: "WARNING: <br><br>Low or no delay set after loading data for each account. <br><br> Set " + safeDelaySeconds + " second delay?"
            }, function () {
                document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked = true;
                document.getElementById('texttimeDelayAfterAdditionalInfo').value = safeDelaySeconds;
                saveOptions();

                populateAllQueueUsersInfo(acctsQueue);

            }, function () {
                populateAllQueueUsersInfo(acctsQueue);
            })
        } else {
            populateAllQueueUsersInfo(acctsQueue);
        }



    } else if (document.getElementById('radioViewStory').checked === true) {
        viewStories();
    }
}

function bindEvents() {


    $('#btnAddScheduledAction').off('click.btnAddScheduledAction').on('click.btnAddScheduledAction', btnAddScheduledAction);
    $('#btnVpScheduleQueue').off('click.vpDistSchedule').on('click.vpDistSchedule', vpScheduleQueueDistributed);
    $('#btnVpUploadFolder').off('click.vpUploadFolder').on('click.vpUploadFolder', vpUploadFolderToQueue);
    $('#btnVpQueueStatus').off('click.vpQueueStatus').on('click.vpQueueStatus', vpRefreshQueueStatus);
    $('#btnVpDiagnosePostador').off('click.vpDiagnose').on('click.vpDiagnose', function (e) { try { e.preventDefault(); } catch (ex) {} vpDiagnosePostador(); });
    // Limpa flag de loop do build antigo (fix3 navegava para @create); fix4+ não usa mais.
    try { chrome.storage.local.remove('vp_auto_post_after_nav', function () {}); } catch (e) {}
    try { chrome.storage.local.set({ 'vp_ai_posting_lock': 0 }); window.__vp_posting_in_progress = false; } catch (e) {}
    try {
        window.__vp_post_mode = window.__vp_post_mode || 'folder';
        chrome.storage.local.get(['vp_post_mode', 'vp_reels_only'], function (d) {
            window.__vp_post_mode = (d && d.vp_post_mode) || 'folder';
            var r = document.querySelector('input[name="vp_post_mode"][value="' + window.__vp_post_mode + '"]');
            if (r) r.checked = true;
            try {
                window.__vp_reels_only = (d && typeof d.vp_reels_only !== 'undefined') ? !!d.vp_reels_only : true;
                var rc = document.getElementById('vp_reels_only');
                if (rc) rc.checked = window.__vp_reels_only;
            } catch (e) { window.__vp_reels_only = true; }
        });
    } catch (e) { window.__vp_post_mode = 'folder'; }
    $(document).off('change.vpPostMode').on('change.vpPostMode', 'input[name="vp_post_mode"]', function () {
        window.__vp_post_mode = $(this).val();
        try { chrome.storage.local.set({ vp_post_mode: window.__vp_post_mode }); } catch (e) {}
        outputMessage('Modo do postador: ' + (window.__vp_post_mode === 'folder' ? 'Pasta do servidor (foto+txt)' : 'IA (gerar imagem+legenda)'));
    });
    $(document).off('change.vpReelsOnly').on('change.vpReelsOnly', '#vp_reels_only', function () {
        window.__vp_reels_only = $(this).is(':checked');
        try { chrome.storage.local.set({ vp_reels_only: window.__vp_reels_only }); } catch (e) {}
        outputMessage('Modo reels exclusivo: ' + (window.__vp_reels_only ? 'ON (só vídeos)' : 'OFF (foto + vídeo)'));
    });
    try {
        chrome.storage.local.get('vp_resume_folder_post', function (d) {
            if (d && d.vp_resume_folder_post) {
                chrome.storage.local.remove('vp_resume_folder_post', function () {});
                setTimeout(function () {
                    if (!window.__vp_posting_in_progress) {
                        outputMessage('⏳ Retomando post da fila após sair da tela de criação...');
                        vpPostFromFolderQueue(true);
                    }
                }, 4000);
            }
        });
        chrome.storage.local.get('vp_auto_post_after_nav', function (d) {
            if (d && d.vp_auto_post_after_nav) {
                chrome.storage.local.remove('vp_auto_post_after_nav', function () {});
                setTimeout(function () {
                    outputMessage('⏳ Página /create carregada, retomando post da fila...');
                    try { chrome.storage.local.set({ 'vp_ai_posting_lock': 0 }); } catch (e) {}
                    window.__vp_posting_in_progress = false;
                    vpPostFromFolderQueue(true);
                }, 4000);
            }
        });
    } catch (e) {}
    $('#btnVpClearDone').off('click.vpClearDone').on('click.vpClearDone', function () { vpClearScheduledActions(true); });
    $('#btnVpClearAll').off('click.vpClearAll').on('click.vpClearAll', function () { if (window.confirm('Excluir TODOS os agendamentos?')) vpClearScheduledActions(false); });
    $('#btnVpScheduleTarget').off('click.vpTargetSchedule').on('click.vpTargetSchedule', vpScheduleTargetFollowLike);
    $('#btnVpScheduleFeedComment').off('click.vpFeedCommentSchedule').on('click.vpFeedCommentSchedule', vpScheduleFeedComment);

    $('#igBotInjectedContainer #btnProcessQueue').click(initProcessQueue);

    $('#igBotInjectedContainer input[type="checkbox"], #igBotInjectedContainer select').off('change.checkboxSaveOptions').on('change.checkboxSaveOptions', saveOptions);
    $('#igBotInjectedContainer input[type="text"],#igBotInjectedContainer input[type="number"]').bind('keyup input', saveOptions);
    $('details').off('toggle.detailsToggle').on('toggle.detailsToggle', saveOptions);

    $('#igBotInjectedContainer #btnStop,#igBotInjectedContainer #btnStop2').click(function () {
        for (var i = 0; i < timeoutsQueue.length; i++) {
            clearTimeout(timeoutsQueue[i]);
        }

        timeoutsQueue = [];

        $('#igBotInjectedContainer *').removeClass('pulsing');
        outputMessage('Stopped all pending actions');
    });

    $('#btnLoadAccountsFromMedia').off('click.LoadAccountsFromMedia').on('click.LoadAccountsFromMedia', LoadAccountsFromMedia);

    $('#btnLoadPostsFromAccountsQueue').off('click.loadPostsFromAccts').on('click.loadPostsFromAccts', loadPostsFromAccountsQueue);

    $('#igBotInjectedContainer #btnLikeFeed').click(ajaxLikeAllPostsFromFeed);

    $('#btnLikeMediaQueue').off('click.likeAllMedia').on('click.likeAllMedia', likeAllMedia);

    $('#btnLoadLocationPosts').off('click.ajaxLoadPostsFromLocation').on('click.ajaxLoadPostsFromLocation', ajaxLoadPostsFromLocation);

    $('#btnLoadPendingRequests').click(ajaxGetPendingFollowRequests);
    $('#btnLoadSavedQueue').click(loadSavedQueue);
    $('#btnViewWhiteList').click(viewWhiteList);
    $('#btnSaveQueueToStorage').click(saveQueueToStorageAndDisk);
    $('#btnExportQueue').click(exportQueue);


    if (getCurrentPageUsername() != '') {
        setCurrentPageUsername();
    } else {
        $('#igBotInjectedContainer #btnGetAllUsersFollowers').off('click.setCurrentPageUsername').on('click.setCurrentPageUsername', setCurrentPageUsername);
        $('#igBotInjectedContainer #btnGetAllUsersFollowing').off('click.setCurrentPageUsername').on('click.setCurrentPageUsername', setCurrentPageUsername);
    }

    setCurrentPageHashtag();


    $('#btnApplyFilter').off('click.ApplyFilter').on('click.ApplyFilter', function () {
        $('li.tab1').click();
        applyFiltersManually();
    });

    $('#btnFindSubscription').off('click.relinkSubscription').on('click.relinkSubscription', relinkSubscription);

    $('#igBotMediaQueueContainer').off('click.setCurrentList').on('click.setCurrentList', function () {
        currentList = 'mediaToLike';
    });
    $('#igBotQueueContainer').off('click.setCurrentList').on('click.setCurrentList', function () {
        if (currentList != 'acctsWhiteList') {
            currentList = 'acctsQueue';
        }
    });


    $(document).on('click.convenienceUnFollow', 'a.igBotInjectedLinkUnfollow', function () {
        $(this).off('click.convenienceUnFollow').css({
            "color": "white"
        }).append('<div class="igBotLoader"></div>');
        convenienceLinkUnfollowAcct($(this).attr('data-username'));
    });

    $(document).on('click.convenienceWhitelist', 'a.igBotInjectedLinkWhitelist', function () {
        $(this).off('click.convenienceWhitelist').css({
            "color": "white"
        }).append('<div class="igBotLoader"></div>');
        convenienceLinkWhitelistAcct($(this).attr('data-username'));
    });

    $('li.tab5').off('click.scrollLog').on('click.scrollLog', scrollLog);

    $('#btnTrimLog').click(trimLog);

    $('#btnWatchReels').off('click.watchReels').on('click.watchReels', watchReels);

    $('#btnLoadThisPost').off('click.LoadThisPost').on('click.LoadThisPost', loadCurrentPostAsMedia);


    $('nav ul li').off('click.rememberTab').on('click.rememberTab', function () {
        gblOptions.lastTab = $(this).attr('class');
        saveOptions();
    });

}

function applyTooltips() {
    $('#igBotInjectedContainer *[title], #instabotIcon').tooltip({
        show: null,
        track: true,
        hide: null
    });

}

async function applyFiltersManually() {

    if (isAdditionalDataFullyLoaded(acctsQueue) === false && acctsQueue.length > 50 && gblOptions.useTimeDelayAfterAdditionalInfo == false) {
        if (!window.confirm('Applying filters requires loading additional data about each account.\n\nLoading this data can trigger rate limits from instagram.\n\nYou should strongly consider setting a delay in the Settings.\n\nProceed with filtering anyway?')) {
            return false;
        }
    }

    for (let i = acctsQueue.length - 1; i > -1; i--) {
        if (await filterCriteriaMet(acctsQueue[i]) === false) {
            outputMessage(acctsQueue[i].username + ' removed from queue (did not match your filters)');
            addStamp(acctsQueue[i].id, 'stamp-div-grey', 'removed');
            acctsQueue.splice(i, 1);
        }
    }

    outputMessage('Filters applied.');
    if (window.confirm('Filters applied.  Save queue now?')) saveQueueToStorageAndDisk();

}

function getExtendedDataInfoForAccount(a) {

    return new Promise(function (resolve, reject) {

        $.ajax({
            url: 'https://i.instagram.com/api/v1/users/' + a.id + '/info/',
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function (r) {


                outputMessage('Loaded user info for ' + a.username + ' to get email address');

                for (var key in r.user) {
                    if (a.hasOwnProperty(key) === false) {
                        a[key] = r.user[key];
                    }
                }

                resolve(a);


            }).fail(function (data) {
                if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function () {
                            resolve(getExtendedDataInfoForAccount(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}



// deve fazer isso se o Filtro de Última Postagem estiver ativado ou se o modo de Curtir estiver ativado
function getTimelineForAcct(a) {

    return new Promise(function (resolve, reject) {

        $.ajax({
            url: 'https://www.instagram.com/api/v1/feed/user/' + a.username + '/username/?count=12',
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(function (r) {


                outputMessage('Loaded post data for ' + a.username + ' to determine last post date');

                a.edge_owner_to_timeline_media.edges = r.items;

                resolve(a);

            }).fail(function (data) {
                if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function () {
                            resolve(getTimelineForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getTimelineForAcct(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}


function getAdditionalDataForAcct(a, urlprefix) {
    if (!urlprefix) urlprefix = urlAcctInfo;
    return new Promise(function (resolve, reject) {

        if (a.edge_followed_by || a["edge_followed_by.count"]) {
            a = appendFollowersRatioToAcct(a);
            a = appendLastPostDateToAcct(a);
            resolve(a);
            return a;
        }

        $.ajax({
            url: '' + urlprefix + a.username,
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
            .done(async function (r) {
                var u = extractJSONfromUserPageHTML(r);

                if (u == false) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        outputMessage('Could not load more info, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function () {
                            resolve(getAdditionalDataForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('Could not load more info, account assumed missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0;
                        resolve(a);
                        return false;
                    }

                }

                a = u;

                a = appendFollowersRatioToAcct(a);
                a = await appendLastPostDateToAcct(a);

                if (gblOptions.getExtendedData == true) {
                    a = await getExtendedDataInfoForAccount(a);
                }

                outputMessage('Loaded additional data for ' + a.username);

                if (gblOptions.useTimeDelayAfterAdditionalInfo == true) {
                    setTimeout(function () {
                        resolve(a);
                    }, gblOptions.timeDelayAfterAdditionalInfo);
                    printMessage(chrome.i18n.getMessage('TimeDelay', [(gblOptions.timeDelayAfterAdditionalInfo / 1000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(a);
                    }, gblOptions.timeDelayAfterAdditionalInfo));
                } else {
                    resolve(a);
                }

                gbl404attempt = 0;

            }).fail(function (data) {
                if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function () {
                            resolve(getAdditionalDataForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function () {
                        resolve(getAdditionalDataForAcct(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}


async function filterCriteriaMet(acct) {

    var filtered = false;

    if (acct.profile_pic_url && acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
        outputMessage(acct.username + ' filtered - has no profile picture')
        filtered = true;
    }

    if (acct.profile_pic_url && acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
        outputMessage(acct.username + ' filtered - has profile picture')
        filtered = true;
    }

    if (acct.followed_by_viewer == true && gblOptions.filterOptions.followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is followed by you')
        filtered = true;
    }

    if (acct.followed_by_viewer == false && gblOptions.filterOptions.non_followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is not followed by you')
        filtered = true;
    }

    if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
        outputMessage(acct.username + ' filtered - account is verified')
        filtered = true;
    }
    if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
        outputMessage(acct.username + ' filtered - account is not verified')
        filtered = true;
    }

    if (filtered === true) {
        return false;
    }

    if (!acct.edge_followed_by) acct = await getAdditionalDataForAcct(acct);

    if (acct.assumedDeleted) {
        outputMessage('Account may have been deleted');
        return false;
    }

    if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
        outputMessage(acct.username + ' filtered - too few followers')
        filtered = true;
    }
    if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
        outputMessage(acct.username + ' filtered - too many followers')
        filtered = true;
    }
    if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
        outputMessage(acct.username + ' filtered - too few following')
        filtered = true;
    }
    if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
        outputMessage(acct.username + ' filtered - too many following')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
        outputMessage(acct.username + ' filtered - too few mutual followers')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
        outputMessage(acct.username + ' filtered - too many mutual followers')
        filtered = true;
    }

    if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
        outputMessage(acct.username + ' filtered - follow ratio too low')
        filtered = true;
    }
    if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
        outputMessage(acct.username + ' filtered - follow ratio too high')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
        outputMessage(acct.username + ' filtered - too few posts')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
        outputMessage(acct.username + ' filtered - too many posts')
        filtered = true;
    }
    if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
        outputMessage(acct.username + ' filtered - posted too recently')
        filtered = true;
    }

    // os dados não saem corretamente para contas privadas, então pular este filtro se a conta for privada
    if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
        outputMessage(acct.username + ' filtered - posted too long ago')
        filtered = true;
    }
    if (acct.is_private == true && gblOptions.filterOptions.private == false) {
        outputMessage(acct.username + ' filtered - account is private')
        filtered = true;
    }
    if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
        outputMessage(acct.username + ' filtered - account is public')
        filtered = true;
    }

    if (acct.follows_viewer == true && gblOptions.filterOptions.follows_me == false) {
        outputMessage(acct.username + ' filtered - account follows you')
        filtered = true;
    }
    if (acct.follows_viewer == false && gblOptions.filterOptions.non_follows_me == false) {
        outputMessage(acct.username + ' filtered - account does not follow you')
        filtered = true;
    }
    if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is a business account')
        filtered = true;
    }
    if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is not a business account')
        filtered = true;
    }
    if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account joined recently')
        filtered = true;
    }
    if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account did not join recently')
        filtered = true;
    }

    if (gblOptions.filterOptions.bio_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                }
            }
        }

        if (bioContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
        }
    }

    if (gblOptions.filterOptions.bio_not_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                    outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                }
            }
        }

        if (bioContains == true) {
            filtered = true;
        }
    }


    if (gblOptions.filterOptions.external_url_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
            for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                }
            }
        }

        if (externalUrlContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
        }
    }

    if (gblOptions.filterOptions.external_url_not_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlNotContainsStrings = gblOptions.filterOptions.external_url_not_contains_text.split(',');
            for (var i = 0; i < externalUrlNotContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlNotContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                    outputMessage(acct.username + ' filtered - external url contains ' + externalUrlNotContainsStrings[i].toLowerCase());
                }
            }
        }

        if (externalUrlContains == true) {
            filtered = true;
        }
    }

    if (gblOptions.filterOptions.business_category_name_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                }
            }
        }

        if (BusinessCategoryNameContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
        }
    }

    if (gblOptions.filterOptions.business_category_name_not_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                    outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                }
            }
        }

        if (BusinessCategoryNameContains == true) {
            filtered = true;
        }
    }


    if (filtered === true) {
        return false;
    } else {
        return true;
    }

}

async function filterCriteriaMetForUnfollowing(acct) {

    if (gblOptions.unFollowFresh === false || gblOptions.dontUnFollowNonGrowbot === true || gblOptions.unFollowIfOld === true) {
        var acctFromStorage = alreadyAttempted(acct);

        if (gblOptions.dontUnFollowNonGrowbot === true && acctFromStorage === false) {
            outputMessage(acct.username + ' was followed outside of Growbot, skipping');
            addStamp(acct.id, 'stamp-div-grey', 'non-growbot');
            return false;
        }

        var timeSinceFollowed = today - acctFromStorage.followAttemptDate;

        if (acctFromStorage != false && acctFromStorage.followAttemptDate && gblOptions.unFollowFresh == false && timeSinceFollowed < gblOptions.unFollowDelay) {
            outputMessage(acct.username + ' was followed too recently to unfollow ' + millisecondsToHumanReadable(timeSinceFollowed, true));
            addStamp(acct.id, 'stamp-div-grey', 'too recent');
            return false;
        }
    }

    if (gblOptions.dontUnFollowFilters === true) {

        var filtered = false;

        if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
            outputMessage(acct.username + ' filtered - has no profile picture')
            filtered = true;
        }

        if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
            outputMessage(acct.username + ' filtered - has profile picture')
            filtered = true;
        }

        if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
            outputMessage(acct.username + ' filtered - account is verified')
            filtered = true;
        }
        if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
            outputMessage(acct.username + ' filtered - account is not verified')
            filtered = true;
        }
    }


    if (!acct.edge_followed_by) acct = await getAdditionalDataForAcct(acct);

    if (gblOptions.dontUnFollowFollowers === true) {
        if (acct.follows_viewer == true) {
            if (gblOptions.unFollowIfOld == true && timeSinceFollowed > gblOptions.unFollowIfOlderThan) {
                outputMessage(acct.username + ' was followed more than ' + millisecondsToHumanReadable(gblOptions.unFollowIfOlderThan, false).days + ' days ago, OK to unfollow')
                return true;
            } else {
                outputMessage(acct.username + ' is one of your followers, skipping');
                addStamp(acct.id, 'stamp-div-grey', 'follows you');
                return false;
            }
        }
    }


    if (acct.assumedDeleted) return false;

    if (gblOptions.dontUnFollowFilters === true) {

        if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
            outputMessage(acct.username + ' filtered - too few followers')
            filtered = true;
        }
        if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
            outputMessage(acct.username + ' filtered - too many followers')
            filtered = true;
        }
        if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
            outputMessage(acct.username + ' filtered - too few following')
            filtered = true;
        }
        if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
            outputMessage(acct.username + ' filtered - too many following')
            filtered = true;
        }
        if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
            outputMessage(acct.username + ' filtered - too few mutual followers')
            filtered = true;
        }
        if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
            outputMessage(acct.username + ' filtered - too many mutual followers')
            filtered = true;
        }
        if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
            outputMessage(acct.username + ' filtered - follow ratio too low')
            filtered = true;
        }
        if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
            outputMessage(acct.username + ' filtered - follow ratio too high')
            filtered = true;
        }
        if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
            outputMessage(acct.username + ' filtered - too few posts')
            filtered = true;
        }
        if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
            outputMessage(acct.username + ' filtered - too many posts')
            filtered = true;
        }
        if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
            outputMessage(acct.username + ' filtered - posted too recently')
            filtered = true;
        }
        if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
            outputMessage(acct.username + ' filtered - posted too long ago')
            filtered = true;
        }
        if (acct.is_private == true && gblOptions.filterOptions.private == false) {
            outputMessage(acct.username + ' filtered - account is private')
            filtered = true;
        }
        if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
            outputMessage(acct.username + ' filtered - account is public')
            filtered = true;
        }
        if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
            outputMessage(acct.username + ' filtered - account is a business account')
            filtered = true;
        }
        if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
            outputMessage(acct.username + ' filtered - account is not a business account')
            filtered = true;
        }
        if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
            outputMessage(acct.username + ' filtered - account joined recently')
            filtered = true;
        }
        if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
            outputMessage(acct.username + ' filtered - account did not join recently')
            filtered = true;
        }

        if (gblOptions.filterOptions.bio_contains == true) {
            var bioContains = false;

            if (acct.biography) {
                var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
                for (var i = 0; i < bioContainsStrings.length; i++) {
                    if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                        bioContains = true;
                    }
                }
            }

            if (bioContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
            }
        }

        if (gblOptions.filterOptions.bio_not_contains == true) {
            var bioContains = false;

            if (acct.biography) {
                var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
                for (var i = 0; i < bioContainsStrings.length; i++) {
                    if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                        bioContains = true;
                        outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (bioContains == true) {
                filtered = true;
            }
        }


        if (gblOptions.filterOptions.external_url_contains == true) {
            var externalUrlContains = false;

            if (acct.external_url) {
                var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
                for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                    if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                        externalUrlContains = true;
                    }
                }
            }

            if (externalUrlContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
            }
        }

        if (gblOptions.filterOptions.external_url_not_contains == true) {
            var externalUrlContains = false;

            if (acct.external_url) {
                var externalUrlNotContainsStrings = gblOptions.filterOptions.external_url_not_contains_text.split(',');
                for (var i = 0; i < externalUrlNotContainsStrings.length; i++) {
                    if (acct.external_url.toLowerCase().indexOf(externalUrlNotContainsStrings[i].toLowerCase()) > -1) {
                        externalUrlContains = true;
                        outputMessage(acct.username + ' filtered - external url contains ' + externalUrlNotContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (externalUrlContains == true) {
                filtered = true;
            }
        }


        if (gblOptions.filterOptions.business_category_name_contains == true) {
            var BusinessCategoryNameContains = false;

            if (acct.business_category_name) {
                var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
                for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                    if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                        BusinessCategoryNameContains = true;
                    }
                }
            }

            if (BusinessCategoryNameContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
            }
        }

        if (gblOptions.filterOptions.business_category_name_not_contains == true) {
            var BusinessCategoryNameContains = false;

            if (acct.business_category_name) {
                var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
                for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                    if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                        BusinessCategoryNameContains = true;
                        outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (BusinessCategoryNameContains == true) {
                filtered = true;
            }
        }


    }

    return filtered;

}

async function filterCriteriaMetForRemoveOrBlock(acct) {

    var filtered = false;

    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
        outputMessage(acct.username + ' filtered - has no profile picture')
        filtered = true;
    }

    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
        outputMessage(acct.username + ' filtered - has profile picture')
        filtered = true;
    }

    if (acct.followed_by_viewer == true && gblOptions.filterOptions.followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is followed by you')
        filtered = true;
    }

    if (acct.followed_by_viewer == false && gblOptions.filterOptions.non_followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is not followed by you')
        filtered = true;
    }

    if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
        outputMessage(acct.username + ' filtered - account is verified')
        filtered = true;
    }
    if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
        outputMessage(acct.username + ' filtered - account is not verified')
        filtered = true;
    }

    if (!acct.edge_followed_by) acct = await getAdditionalDataForAcct(acct);

    if (acct.assumedDeleted) return false;

    if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
        outputMessage(acct.username + ' filtered - too few followers')
        filtered = true;
    }
    if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
        outputMessage(acct.username + ' filtered - too many followers')
        filtered = true;
    }
    if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
        outputMessage(acct.username + ' filtered - too few following')
        filtered = true;
    }
    if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
        outputMessage(acct.username + ' filtered - too many following')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
        outputMessage(acct.username + ' filtered - too few mutual followers')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
        outputMessage(acct.username + ' filtered - too many mutual followers')
        filtered = true;
    }
    if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
        outputMessage(acct.username + ' filtered - follow ratio too low')
        filtered = true;
    }
    if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
        outputMessage(acct.username + ' filtered - follow ratio too high')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
        outputMessage(acct.username + ' filtered - too few posts')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
        outputMessage(acct.username + ' filtered - too many posts')
        filtered = true;
    }
    if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
        outputMessage(acct.username + ' filtered - posted too recently')
        filtered = true;
    }
    if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
        outputMessage(acct.username + ' filtered - posted too long ago')
        filtered = true;
    }
    if (acct.is_private == true && gblOptions.filterOptions.private == false) {
        outputMessage(acct.username + ' filtered - account is private')
        filtered = true;
    }
    if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
        outputMessage(acct.username + ' filtered - account is public')
        filtered = true;
    }
    if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is a business account')
        filtered = true;
    }
    if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is not a business account')
        filtered = true;
    }
    if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account joined recently')
        filtered = true;
    }
    if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account did not join recently')
        filtered = true;
    }

    if (gblOptions.filterOptions.bio_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                }
            }
        }

        if (bioContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
        }
    }

    if (gblOptions.filterOptions.bio_not_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                    outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                }
            }
        }

        if (bioContains == true) {
            filtered = true;
        }
    }

    if (gblOptions.filterOptions.external_url_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
            for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                }
            }
        }

        if (externalUrlContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
        }
    }

    if (gblOptions.filterOptions.external_url_not_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                    outputMessage(acct.username + ' filtered - external url contains ' + externalUrlContainsStrings[i].toLowerCase());
                }
            }
        }

        if (externalUrlContains == true) {
            filtered = true;
        }
    }



    if (gblOptions.filterOptions.business_category_name_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                }
            }
        }

        if (BusinessCategoryNameContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
        }
    }

    if (gblOptions.filterOptions.business_category_name_not_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                    outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                }
            }
        }

        if (BusinessCategoryNameContains == true) {
            filtered = true;
        }
    }


    return filtered;

}


function vpBindNumericFilters() {
    var numericFilters = [
        { key: 'followers', minId: 'flt_followers_min', maxId: 'flt_followers_max', isFloat: false },
        { key: 'following', minId: 'flt_following_min', maxId: 'flt_following_max', isFloat: false },
        { key: 'followRatio', minId: 'flt_followRatio_min', maxId: 'flt_followRatio_max', isFloat: true },
        { key: 'mutualFollowedBy', minId: 'flt_mutualFollowedBy_min', maxId: 'flt_mutualFollowedBy_max', isFloat: false },
        { key: 'posts', minId: 'flt_posts_min', maxId: 'flt_posts_max', isFloat: false },
        { key: 'lastPosted', minId: 'flt_lastPosted_min', maxId: 'flt_lastPosted_max', isFloat: false }
    ];

    function currentValues(f) {
        var dflt = defaultFilterOptions[f.key];
        var cur = (gblOptions.filterOptions && gblOptions.filterOptions[f.key]) || dflt;
        return [Number(cur[0]), Number(cur[1])];
    }

    numericFilters.forEach(function (f) {
        var vals = currentValues(f);
        var minEl = document.getElementById(f.minId);
        var maxEl = document.getElementById(f.maxId);
        if (minEl) minEl.value = vals[0];
        if (maxEl) maxEl.value = vals[1];
    });

    function updateFilterOptionsFromInputs() {
        if (!gblOptions.filterOptions) gblOptions.filterOptions = {};
        numericFilters.forEach(function (f) {
            var dflt = defaultFilterOptions[f.key];
            var minEl = document.getElementById(f.minId);
            var maxEl = document.getElementById(f.maxId);
            var mn = f.isFloat ? parseFloat(minEl.value) : parseInt(minEl.value, 10);
            var mx = f.isFloat ? parseFloat(maxEl.value) : parseInt(maxEl.value, 10);
            if (!isFinite(mn)) mn = dflt[0];
            if (!isFinite(mx)) mx = dflt[1];
            if (mn > mx) {
                var t = mn; mn = mx; mx = t;
                minEl.value = mn;
                maxEl.value = mx;
            }
            gblOptions.filterOptions[f.key] = [mn, mx];
        });
        saveOptions();
    }

    numericFilters.forEach(function (f) {
        var minEl = document.getElementById(f.minId);
        var maxEl = document.getElementById(f.maxId);
        if (minEl) minEl.addEventListener('change', updateFilterOptionsFromInputs);
        if (maxEl) maxEl.addEventListener('change', updateFilterOptionsFromInputs);
    });

    $('#btnResetFilter').off('click.resetVpFilters').on('click.resetVpFilters', function () {
        if (!gblOptions.filterOptions) gblOptions.filterOptions = {};
        numericFilters.forEach(function (f) {
            gblOptions.filterOptions[f.key] = defaultFilterOptions[f.key].slice();
            document.getElementById(f.minId).value = defaultFilterOptions[f.key][0];
            document.getElementById(f.maxId).value = defaultFilterOptions[f.key][1];
        });
        saveOptions();
    });
}

function bindNoUiSliders() {

    vpBindNumericFilters();
    return;

    var sliderElements = ['followersSlider', 'followingSlider', 'followRatioSlider', 'mutualFollowedBySlider', 'postsSlider', 'lastPostedSlider'];

    for (var i = 0; i < sliderElements.length; i++) {

        var currentSlider = document.getElementById(sliderElements[i]);

        //gambiarra?
        var fromOptions = gblOptions.filterOptions[sliderElements[i].replace('Slider', '')];

        var dFO = defaultFilterOptions[sliderElements[i].replace('Slider', '')];

        if (sliderElements[i] == 'followRatioSlider') {
            noUiSlider.create(currentSlider, {
                start: fromOptions,
                range: {
                    'min': [dFO[0]],
                    '5%': [0],
                    '10%': [0.25],
                    '15%': [0.5],
                    '20%': [0.75],
                    '25%': [1],
                    '30%': [1.25],
                    '35%': [1.5],
                    '40%': [1.75],
                    '45%': [2],
                    '50%': [3],
                    '55%': [4],
                    'max': [dFO[1]]
                },
                //pips: { mode: 'values', values: [-7500, 0, 0.5,.75, 1,1.25,1.5,1.75,2,3,4, 10000], density: 10, stepped: true, format: wNumb({decimals:2}) },
                pips: {
                    mode: 'range',
                    density: 10,
                    stepped: true,
                    format: wNumb({
                        decimals: 2
                    })
                },
                connect: [false, true, false]
            });
        } else if (sliderElements[i] == 'followersSlider' || sliderElements[i] == 'mutualFollowedBySlider') {
            noUiSlider.create(currentSlider, {
                start: fromOptions,
                range: {
                    'min': [dFO[0]],
                    '5%': [10],
                    '20%': [100],
                    '50%': [5000],
                    '70%': [10000],
                    '80%': [100000],
                    '90%': [1000000],
                    'max': [dFO[1]]
                },
                //pips: { mode: 'values', values: [-7500, 0, 0.5,.75, 1,1.25,1.5,1.75,2,3,4, 10000], density: 10, stepped: true, format: wNumb({decimals:2}) },
                pips: {
                    mode: 'range',
                    density: 10,
                    stepped: true
                },
                connect: [false, true, false],
                format: wNumb({
                    decimals: 0
                })
            });

        } else {
            noUiSlider.create(currentSlider, {
                start: fromOptions,
                range: {
                    'min': [dFO[0]],
                    '5%': [10],
                    '20%': [100],
                    'max': [dFO[1]]
                },
                pips: {
                    mode: 'range',
                    density: 5
                },
                connect: [false, true, false],
                format: wNumb({
                    decimals: 0
                })
            });
        }

        currentSlider.noUiSlider.on('set', updateFilterOptions);


        function sp(event) {
            event.stopPropagation();
        }

        function setTooltipInputWidth(input) {
            input.style.width = ((input.value.length + 1) * 6) + 'px';
        }

        function makeTT(i, slider) {
            var tooltip = document.createElement('div'),
                input = document.createElement('input');

            // Add the input to the tooltip
            tooltip.className = 'noUi-tooltip';
            tooltip.appendChild(input);

            // On change, set the slider
            input.addEventListener('change', function () {
                var values = [null, null];
                values[i] = this.value;
                slider.noUiSlider.set(values)
                setTooltipInputWidth(this);
            });

            input.addEventListener('focus', function () {
                $(slider.tooltipInputs[0]).closest('.noUi-origin')[0].style.zIndex = 4;
                $(slider.tooltipInputs[1]).closest('.noUi-origin')[0].style.zIndex = 4;

                $(this).closest('.noUi-origin')[0].style.zIndex = 5;

            })

            // Catch all selections and make sure they don't reach the handle
            input.addEventListener('mousedown', sp);
            input.addEventListener('touchstart', sp);
            input.addEventListener('pointerdown', sp);
            input.addEventListener('MSPointerDown', sp);

            // Find the lower/upper slider handle and insert the tooltip
            slider.querySelector(i ? '.noUi-handle-upper' : '.noUi-handle-lower').appendChild(tooltip);

            return input;
        }

        // An 0/1 indexed array of input elements
        currentSlider.tooltipInputs = [makeTT(0, currentSlider), makeTT(1, currentSlider)];

        // When the slider changes, update the tooltip
        currentSlider.noUiSlider.on('update', function (values, handle) {
            this.target.tooltipInputs[handle].value = values[handle];
            setTooltipInputWidth(this.target.tooltipInputs[handle]);
        });

    }


    function updateFilterOptions() {
        for (var i = 0; i < sliderElements.length; i++) {
            var currentSlider = document.getElementById(sliderElements[i]);
            gblOptions.filterOptions[sliderElements[i].replace('Slider', '')] = currentSlider.noUiSlider.get().map(Number);
        }
        saveOptions();
    }

    function resetFilterSliders() {
        for (var i = 0; i < sliderElements.length; i++) {
            document.getElementById(sliderElements[i]).noUiSlider.reset();
        }
    }


    $('#btnResetFilter').click(resetFilterSliders);

}

function setCurrentPageUsername() {
    var uname = getCurrentPageUsername();
    if (uname == '' && typeof ensureStubProfile === 'function') {
        try {
            if (ensureStubProfile() === true) uname = getCurrentPageUsername();
        } catch (e) {}
    }
    if (uname != '') {
        $('#btnGetAllUsersFollowers')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCurrentFollowers', uname))
            .off('click.ajaxGetAllUsersFollowers')
            .on('click.ajaxGetAllUsersFollowers', ajaxGetAllUsersFollowers);
        $('#btnGetAllUsersFollowing')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCurrentFollowing', uname))
            .off('click.ajaxLoadFollowing')
            .on('click.ajaxLoadFollowing', ajaxLoadFollowing);

        $('#btnGetCommenters').removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCommenters', uname))
            .off('click.getCommenters')
            .on('click.getCommenters', ajaxLoadAllUsersCommenters);

        $('#btnGetLikers')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadLikers', uname))
            .off('click.getLikers')
            .on('click.getLikers', ajaxLoadAllUsersLikers);

        $('#btnLoadPostsFromAccountPage')
            .removeClass('inactive')
            .text('Carregar Postagens de ' + uname)
            .off('click.loadAccountPosts')
            .on('click.loadAccountPosts', function () { ajaxLoadPostsFromAccountPage(''); });

    } else {

        $('#igBotInjectedContainer #btnGetAllUsersFollowers,#igBotInjectedContainer #btnGetAllUsersFollowing').click(function () {
            outputMessage('Error: must be on an instagram user page (or try reloading).');
        }).addClass('inactive');
    }
}

function checkUsernameFreshness() {
    if ($(igExternalVars.qsForProfilePageUsername).text() != getCurrentPageUsername()) {
        ajaxGetCurrentPageUserInfo();
        return false;
    }
    return true;
}

function getCurrentPageUsername() {
    if (currentProfilePage != false && currentProfilePage) {
        return currentProfilePage.username;
    } else {
        ajaxGetCurrentPageUserInfo();
        return '';
    }
}

function getProfileIdFromPage(username) {
    if (!username) return '';
    try {
        var norm = String(username).toLowerCase();
        var scripts = document.querySelectorAll('script[type="application/json"]');
        for (var i = 0; i < scripts.length; i++) {
            var txt = scripts[i].textContent || '';
            if (txt.indexOf(username) === -1) continue;
            try {
                var j = JSON.parse(txt);
                var found = findProfileIdInJson(j, norm);
                if (found) return found;
            } catch (e) {}
        }
        var html = document.documentElement ? document.documentElement.innerHTML : '';
        if (html && html.indexOf(username) > -1) {
            var patterns = [
                new RegExp('"username"\\s*:\\s*"' + username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^}]{0,800}"pk"\\s*:\\s*"(\\d+)"'),
                new RegExp('"pk"\\s*:\\s*"(\\d+)"[^}]{0,800}"username"\\s*:\\s*"' + username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"'),
                new RegExp('"username"\\s*:\\s*"' + username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^}]{0,800}"id"\\s*:\\s*"(\\d{5,})"'),
                /"profilePage_[^"]*"\s*:\s*\{"id"\s*:\s*"(\d+)"/,
                /instagram:\/\/user\?username=[^&]+&id=(\d+)/
            ];
            for (var p = 0; p < patterns.length; p++) {
                var m = html.match(patterns[p]);
                if (m && m[1]) return m[1];
            }
        }
    } catch (e) {}
    return '';
}

function findProfileIdInJson(obj, normUsername) {
    try {
        if (!obj || typeof obj !== 'object') return '';
        if (obj.username && String(obj.username).toLowerCase() === normUsername) {
            if (obj.pk) return String(obj.pk);
            if (obj.id && /^\d{5,}$/.test(String(obj.id))) return String(obj.id);
            if (obj.user && obj.user.pk) return String(obj.user.pk);
        }
        if (obj.owner && obj.owner.username && String(obj.owner.username).toLowerCase() === normUsername) {
            if (obj.owner.pk) return String(obj.owner.pk);
            if (obj.owner.id) return String(obj.owner.id);
        }
        for (var k in obj) {
            if (!obj.hasOwnProperty(k)) continue;
            var v = obj[k];
            if (v && typeof v === 'object') {
                var r = findProfileIdInJson(v, normUsername);
                if (r) return r;
            }
        }
    } catch (e) {}
    return '';
}

function ensureStubProfile() {
    try {
        if (currentProfilePage && currentProfilePage.username) return true;
        var pathUser = '';
        if (typeof getProfileUsernameFromPath === 'function') pathUser = getProfileUsernameFromPath();
        if (!pathUser) {
            var parts = (window.location.pathname || '').split('/').filter(function (p) { return p.length > 0; });
            if (parts.length === 1) pathUser = parts[0];
        }
        if (!pathUser) return false;
        var pid = getProfileIdFromPage(pathUser);
        currentProfilePage = {
            username: pathUser,
            id: pid || '',
            edge_followed_by: { count: 0 },
            edge_follow: { count: 0 },
            is_private: false,
            followed_by_viewer: false,
            stub: true
        };
        setCurrentPageUsername();
        if (pid) {
            outputMessage('Perfil detectado pela página: ' + pathUser + ' (ID ' + pid + '). Seguidores/seguindo liberados; se falhar, o Instagram pode ter bloqueado a listagem.');
        } else {
            outputMessage('Perfil detectado pela URL: ' + pathUser + '. Curtidores/comentadores liberados; seguidores/seguindo precisam do ID (bloqueado pelo Instagram).');
        }
        return true;
    } catch (e) { return false; }
}

function getLoggedInViewerPk() {
    try {
        if (typeof user !== 'undefined' && user && user.viewer) {
            if (user.viewer.pk != null) return String(user.viewer.pk);
            if (user.viewer.id != null) return String(user.viewer.id);
        }
    } catch (e) {}
    try {
        var dsUserId = getCookie('ds_user_id');
        if (dsUserId) return String(dsUserId);
    } catch (e) {}
    return '';
}

function isViewerPkForDifferentProfile(pk, targetUsername) {
    var viewerPk = getLoggedInViewerPk();
    if (!viewerPk || String(pk) !== viewerPk) return false;
    try {
        if (typeof user !== 'undefined' && user && user.viewer && user.viewer.username) {
            return normalizeConvenienceUsername(user.viewer.username) !== normalizeConvenienceUsername(targetUsername);
        }
    } catch (e) {}
    try {
        return normalizeConvenienceUsername(getProfileUsernameFromPath()) !== normalizeConvenienceUsername(targetUsername);
    } catch (e) {}
    return false;
}

function extractUserPkNearUsernameInText(text, username) {
    if (!text) return '';
    var escaped = String(username).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var patterns = [
        new RegExp('"username":"' + escaped + '"[^}]{0,1200}?"pk":"?(\\d+)"?', 'i'),
        new RegExp('"pk":"?(\\d+)"?[^}]{0,1200}?"username":"' + escaped + '"', 'i'),
        new RegExp('"username":"' + escaped + '"[^}]*"id":"(\\d+)"'),
        new RegExp('"id":"(\\d+)"[^}]*"username":"' + escaped + '"'),
        new RegExp('"pk":"?(\\d+)"?[^}]*"username":"' + escaped + '"')
    ];
    for (var i = 0; i < patterns.length; i++) {
        var match = text.match(patterns[i]);
        if (match && match[1]) return String(match[1]);
    }
    return '';
}

function extractOwnerUserIdFromProfileHtml(text) {
    if (!text) return '';
    var patterns = [
        /<meta[^>]+property=["']instapp:owner_user_id["'][^>]+content=["'](\d+)["']/i,
        /<meta[^>]+content=["'](\d+)["'][^>]+property=["']instapp:owner_user_id["']/i,
        /"owner_id"\s*:\s*"?(\d+)"?/i,
        /"profile_id"\s*:\s*"?(\d+)"?/i,
        /"instapp:owner_user_id"\s*:\s*"?(\d+)"?/i
    ];
    for (var i = 0; i < patterns.length; i++) {
        var match = text.match(patterns[i]);
        if (match && match[1]) return String(match[1]);
    }
    return '';
}

function extractUserIdFromProfileHtml(html, username) {
    if (!html) return '';
    var usernameNorm = normalizeConvenienceUsername(username);
    if (typeof html === 'object') {
        try {
            var apiUser = extractJSONfromUserPageHTML(html);
            if (apiUser && apiUser.id && normalizeConvenienceUsername(apiUser.username) === usernameNorm) {
                return String(apiUser.id);
            }
        } catch (e) {}
        return '';
    }
    var ownerId = extractOwnerUserIdFromProfileHtml(html);
    if (ownerId && !isViewerPkForDifferentProfile(ownerId, username)) return ownerId;
    var fromText = extractUserPkNearUsernameInText(html, username);
    if (fromText && !isViewerPkForDifferentProfile(fromText, username)) return fromText;
    try {
        var scriptRe = /<script[^>]*>([\s\S]*?)<\/script>/gi;
        var scriptMatch;
        while ((scriptMatch = scriptRe.exec(html)) !== null) {
            var chunk = scriptMatch[1];
            if (chunk.indexOf(username) === -1) continue;
            var scriptId = extractUserPkNearUsernameInText(chunk, username);
            if (scriptId && !isViewerPkForDifferentProfile(scriptId, username)) return scriptId;
        }
    } catch (e) {}
    try {
        var user2 = extractJSONfromUserPageHTML(html);
        if (user2 && user2.id && normalizeConvenienceUsername(user2.username) === usernameNorm) {
            return String(user2.id);
        }
    } catch (e) {}
    return '';
}

async function resolveInstagramUserIdViaTopsearch(username) {
    var fetchOptions = getInstagramWebApiFetchOptions(username);
    var response = await fetch('https://www.instagram.com/web/search/topsearch/?query=' + encodeURIComponent(username), fetchOptions);
    if (!response.ok) {
        throw new Error('topsearch HTTP ' + response.status + ' for ' + username);
    }
    var data = await response.json();
    var users = data && data.users ? data.users : [];
    var usernameNorm = normalizeConvenienceUsername(username);
    for (var i = 0; i < users.length; i++) {
        var u = users[i] && users[i].user;
        if (!u) continue;
        if (normalizeConvenienceUsername(u.username) === usernameNorm) {
            var pk = u.pk != null ? u.pk : (u.pk_id != null ? u.pk_id : u.id);
            if (pk != null && !isViewerPkForDifferentProfile(pk, username)) return String(pk);
        }
    }
    throw new Error('topsearch found no exact match for ' + username);
}

async function fetchInstagramUserInfoById(userid, username) {
    var infoResponse = await fetch("https://www.instagram.com/api/v1/users/" + userid + "/info/", getInstagramWebApiFetchOptions(username));
    if (!infoResponse.ok) {
        throw new Error('users/info HTTP ' + infoResponse.status + ' for ' + username);
    }
    var infoContentType = '';
    try { infoContentType = infoResponse.headers.get('content-type') || ''; } catch (e) {}
    if (infoContentType.indexOf('json') === -1) {
        throw new Error('users/info returned non-JSON response for ' + username);
    }
    var infoData = await infoResponse.json();
    if (infoData && infoData.status === 'fail') {
        throw new Error('users/info failed for ' + username + ': ' + (infoData.message || 'unknown error'));
    }
    if (!infoData || !infoData.user) {
        throw new Error('users/info returned no user for ' + username);
    }
    var returnedUsername = infoData.user.username;
    if (returnedUsername && normalizeConvenienceUsername(returnedUsername) !== normalizeConvenienceUsername(username)) {
        throw new Error('users/info username mismatch for ' + username);
    }
    var profile = normalizeAppUserToProfilePage(infoData.user, username);
    if (isViewerPkForDifferentProfile(profile.id, username)) {
        throw new Error('users/info returned logged-in viewer id for ' + username);
    }
    return profile;
}

async function getProfileViaWebApiMultiSource(username) {
    var seen = {};
    var sources = [
        function () {
            try {
                if (normalizeConvenienceUsername(getProfileUsernameFromPath()) !== normalizeConvenienceUsername(username)) return [];
                var docHtml = document.documentElement && document.documentElement.innerHTML ? document.documentElement.innerHTML : '';
                var docId = extractUserIdFromProfileHtml(docHtml, username);
                return docId ? [docId] : [];
            } catch (e) { return []; }
        },
        async function () {
            try {
                var profileResponse = await fetch('https://www.instagram.com/' + encodeURIComponent(username) + '/', getInstagramWebApiFetchOptions(username));
                if (profileResponse.ok) {
                    var profileHtml = await profileResponse.text();
                    var htmlId = extractUserIdFromProfileHtml(profileHtml, username);
                    if (htmlId) return [htmlId];
                }
            } catch (e) {}
            return [];
        },
        async function () {
            try { return [await resolveInstagramUserIdViaTopsearch(username)]; }
            catch (e) { return []; }
        }
    ];
    for (var s = 0; s < sources.length; s++) {
        var ids = [];
        try { ids = await sources[s](); } catch (e) { continue; }
        for (var i = 0; i < ids.length; i++) {
            var id = String(ids[i] || '').trim();
            if (!id || seen[id]) continue;
            seen[id] = true;
            if (isViewerPkForDifferentProfile(id, username)) continue;
            try {
                var profile = await fetchInstagramUserInfoById(id, username);
                if (profile) return profile;
            } catch (e) {}
        }
    }
    return false;
}

function getQueryParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function shortcodeToInstaID(Shortcode) {
    var char;
    var id = BigInt(0);
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    for (var i = 0; i < Shortcode.length; i++) {
        char = Shortcode[i];
        var mul = BigInt(BigInt(id) * BigInt(64));
        id = BigInt(BigInt(mul) + BigInt(alphabet.indexOf(char)));
    }

    var stringId = id.toString().replace('n', '');

    return stringId;
}


async function loadCurrentPostAsMedia() {

    var url = window.location.href;

    var shorty;

    if (url.indexOf('/p/') > 0) {
        shorty = url.substring(url.indexOf('/p/') + 3, url.length);
    } else if (url.indexOf('/reel/') > 0) {
        shorty = url.substring(url.indexOf('/reel/') + 6, url.length);
    } else {
        printMessage('Error: must be on post page');
        return false;
    }

    shorty = shorty.substring(0, shorty.indexOf('/'));


    var mediaId = shortcodeToInstaID(shorty);
    if (shorty.length > 15) {
        const response = await fetch(url);
        var HTML_String = await response.text();
        HTML_String = HTML_String.substring(HTML_String.indexOf('instagram://media?id=') + 21, HTML_String.length)
        mediaId = HTML_String.substring(0, HTML_String.indexOf('"'));
    }

    $.ajax({
        url: "https://www.instagram.com/api/v1/media/" + mediaId + "/info/",
        method: 'GET',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (r) {

            if (r && r.items && r.items[0]) {


                $.ajax({
                    url: "https://www.instagram.com/api/v1/media/" + mediaId + "/comments/?can_support_threading=true&permalink_enabled=false",
                    method: 'GET',
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                        xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                        xhr.setRequestHeader('x-asbd-id', '129477');
                        xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                    },
                    xhrFields: {
                        withCredentials: true
                    }
                })
                    .done(function (c) {

                        r.items[0].comments = c.comments;

                        mediaToLike.push(r.items[0]);
                        arrayOfMediaToDiv(mediaToLike, true);
                        printMessage('Loaded media: ' + shorty);

                    });



            }

        }).fail(function (f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(loadCurrentPostAsMedia, gblOptions.timeDelayAfter429RateLimit));
            }
        });


}



async function getUserInfoFromGraphQL(username) {

    return new Promise(async function (resolve, reject) {

        try {
            if (!username) { resolve(false); return; }

            try {
                var webProfile = await getProfileViaWebApiMultiSource(username);
                if (webProfile) { resolve(webProfile); return; }
            } catch (e) {}

            var csrftoken = getCsrfFromCookie() || '';
            var lsd = (typeof getInstagramLsdToken === 'function' ? getInstagramLsdToken() : '') || '';
            var fbDtsg = (typeof getInstagramFbDtsg === 'function' ? getInstagramFbDtsg() : '') || '';
            var jazoest = (typeof getInstagramJazoest === 'function' ? getInstagramJazoest(fbDtsg) : '') || '';
            var actorId = (typeof getInstagramActorId === 'function' ? getInstagramActorId() : '') || '';
            if (!actorId) actorId = '0';
            if (!lsd) lsd = 'AV';
            if (!fbDtsg) fbDtsg = 'NA';
            if (!jazoest) jazoest = '22075';

            var commonHeaders = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/x-www-form-urlencoded",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "359341",
                "x-csrftoken": csrftoken,
                "x-ig-app-id": "936619743392459"
            };

            var fetch1 = await fetch("https://www.instagram.com/graphql/query", {
                "headers": Object.assign({}, commonHeaders, {
                    "x-fb-friendly-name": "PolarisProfilePostsQuery",
                    "x-fb-lsd": lsd
                }),
                "referrer": "https://www.instagram.com/" + username + "/",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": "av=" + encodeURIComponent(actorId) + "&__d=www&__user=0&__a=1&__req=8&__hs=20159.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020831374&__s=sblxde%3Agvogj7%3A6ksx3t&__hsi=7481052854246233508&__dyn=7xe5WwlEnwn8K2Wmm1twpUnwgU7S6EeUaUco38w5ux609vCwjE1EE2Cw8G11wBw5Zx62G3i1ywOwa90Fw4Hw9O0Lbwae4UaEW2G0AEco5G0zEnwhE3Mw5NyES1Twoob82ZwrUdUbGw4mwr86C1mwrd6goK10xKi2K7E5y4UrwHwcObBxm&__csr=&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=" + encodeURIComponent(fbDtsg) + "&jazoest=" + encodeURIComponent(jazoest) + "&lsd=" + encodeURIComponent(lsd) + "&__spin_r=1020831374&__spin_b=trunk&__spin_t=1741818351&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B%22data%22%3A%7B%22count%22%3A12%2C%22include_reel_media_seen_timestamp%22%3Atrue%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + encodeURIComponent(username) + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisShareSheetV3relayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=9507655305965624",
                "method": "POST",
                "mode": "cors",
                "credentials": "include"
            });

            if (!fetch1.ok) { resolve(false); return; }
            var ct1 = fetch1.headers.get('content-type') || '';
            if (ct1.indexOf('application/json') === -1) {
                var t1 = await fetch1.text();
                if (t1.indexOf('<!DOCTYPE') > -1 || t1.indexOf('<html') > -1) { resolve(false); return; }
                try { var pj1 = JSON.parse(t1); } catch (e) { resolve(false); return; }
                var jsondata1 = pj1;
            } else {
                var jsondata1 = await fetch1.json();
            }

            var userid = null;
            try {
                userid = jsondata1.data.xdt_api__v1__feed__user_timeline_graphql_connection.edges[0].node.owner.pk;
            } catch (e) { userid = null; }
            if (!userid) { resolve(false); return; }



            var fetched = await fetch("https://www.instagram.com/graphql/query", {
                "headers": Object.assign({}, commonHeaders, {
                    "x-fb-friendly-name": "PolarisProfilePageContentQuery",
                    "x-fb-lsd": lsd
                }),
                "referrer": "https://www.instagram.com/" + username + "/",
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": "av=" + encodeURIComponent(actorId) + "&__d=www&__user=0&__a=1&__req=4&__hs=20159.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020831374&__s=sblxde%3Agvogj7%3A6ksx3t&__hsi=7481052854246233508&__dyn=7xe5WwlEnwn8K2Wmm1twpUnwgU7S6EeUaUco38w5ux609vCwjE1EE2Cw8G11wBw5Zx62G3i1ywOwa90Fw4Hw9O0Lbwae4UaEW2G0AEco5G0zEnwhE3Mw5NyES1Twoob82ZwrUdUbGw4mwr86C1mwrd6goK10xKi2K7E5y4UrwHwcObBxm&__csr=&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=" + encodeURIComponent(fbDtsg) + "&jazoest=" + encodeURIComponent(jazoest) + "&lsd=" + encodeURIComponent(lsd) + "&__spin_r=1020831374&__spin_b=trunk&__spin_t=1741818351&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePageContentQuery&variables=%7B%22id%22%3A%22" + encodeURIComponent(userid) + "%22%2C%22render_surface%22%3A%22PROFILE%22%7D&server_timestamps=true&doc_id=28812098038405011",
                "method": "POST",
                "mode": "cors",
                "credentials": "include"
            });

            if (!fetched.ok) { resolve(false); return; }
            var ct2 = fetched.headers.get('content-type') || '';
            var jsondata = null;
            if (ct2.indexOf('application/json') === -1) {
                var t2 = await fetched.text();
                try { jsondata = JSON.parse(t2); } catch (e) { resolve(false); return; }
            } else {
                jsondata = await fetched.json();
            }

            if (jsondata && jsondata.data && jsondata.data.user) {
                resolve(jsondata.data.user);
            } else {
                resolve(false);
            }
        } catch (e) {
            try { console.warn('getUserInfoFromGraphQL fallback failed:', e); } catch (e2) {}
            resolve(false);
        }
    });
}



function ajaxGetCurrentPageUserInfo(urlprefix) {

    if (typeof gbProfileLoading !== 'undefined' && gbProfileLoading === true) return false;
    if (typeof gbProfileLastErrorAt !== 'undefined' && (Date.now() - gbProfileLastErrorAt) < 20000) {
        if (typeof ensureStubProfile === 'function') { try { ensureStubProfile(); } catch (e) {} }
        return false;
    }
    gbProfileLoading = true;

    if (!urlprefix) {
        urlprefix = urlAcctInfo;
    }

    var username = $.trim($(igExternalVars.qsForProfilePageUsername).text() || '');
    if (username == '' && typeof getProfileUsernameFromPath === 'function') username = getProfileUsernameFromPath();
    if (username == '') username = window.location.pathname.split('/')[1] || '';
    if (username == 'explore' || username == 'stories' || username === 'accounts' || username === 'direct' || username === 'reel') username = '';

    if (username == 'p') username = getQueryParameterByName('taken-by') || getUsernameFromPostHtml();

    if (username.indexOf('Edit Profile') > -1) username = username.replace('Edit Profile', '');

    if ((currentProfilePage == false && username != '') || (username != '' && currentProfilePage.username != username)) {



        $.ajax({
            url: '' + urlprefix + username,
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        }).fail(async function (err) {
            gbProfileLoading = false;
            if (err.status === 429) {
                gbProfileLastErrorAt = Date.now();
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                setTimeout(function () { gbProfileLoading = false; ajaxGetCurrentPageUserInfo(); }, (gblOptions.timeDelayAfter429RateLimit / 60000));
                clearInterval(usernameCheckInterval);
                return;
            }

            if (err.status === 400 || err.status === 403) {
                gbProfileLastErrorAt = Date.now();
                clearInterval(usernameCheckInterval);

                try {
                    var backupUser = await getUserInfoFromGraphQL(username);
                    if (backupUser) {
                        currentProfilePage = backupUser;
                        setCurrentPageUsername();
                        startUserNameFreshnessInterval();
                        outputMessage('Current profile: ' + username);
                        outputMessage('Instagram has temporarily blocked you from the API which loads data about profiles. Using backup method... but you should really slow down');
                        return;
                    }
                } catch (e) {
                    try { console.warn('backup profile lookup failed', e); } catch (e2) {}
                }

                outputMessage('Instagram bloqueou a API de perfil (HTTP ' + err.status + '). Tentando detecção local...');
                try {
                    if (typeof ensureStubProfile === 'function' && ensureStubProfile() === true) {
                        startUserNameFreshnessInterval();
                        return;
                    }
                } catch (e) {}
                setTimeout(function () { gbProfileLoading = false; ajaxGetCurrentPageUserInfo(urlprefix); }, 45000);
                startUserNameFreshnessInterval();
                return;

            }

            gbProfileLastErrorAt = Date.now();
            outputMessage('Falha ao carregar perfil (HTTP ' + (err.status || 'erro') + '). Tentando novamente...');
            setTimeout(function () { gbProfileLoading = false; ajaxGetCurrentPageUserInfo(urlprefix); }, 30000);


        }).done(function (data) {
            gbProfileLoading = false;
            currentProfilePage = extractJSONfromUserPageHTML(data);

            if (currentProfilePage !== false) {
                setCurrentPageUsername();
                startUserNameFreshnessInterval();
                outputMessage('Current profile: ' + username);

            } else {
                //outputMessage('Error loading current user page');
                clearInterval(usernameCheckInterval);
                ajaxGetCurrentPageUserInfo(urlAcctInfo2);
            }


        });
    }
}

function getUsernameFromPostHtml() {
    return $('header._aaqw a.x1i10hfl:first').text();
}

function extractJSONfromUserPageHTML(data) {

    var pureJSON = data.data;
    if (pureJSON && pureJSON.user) {
        return pureJSON.user;
    }

    if (data && data.user) {
        var scriptSection = data.substring(data.indexOf('<script type="text/javascript">window._sharedData = ') + 52, data.indexOf(';</script>', data.indexOf('<script type="text/javascript">window._sharedData = ')));
        var scriptSectionAdditional = data.substring(data.indexOf('{', data.indexOf('<script type="text/javascript">window.__additionalDataLoaded(')), data.indexOf(');</script>', data.indexOf('<script type="text/javascript">window.__additionalDataLoaded(')));

        if (data.indexOf('<script type="text/javascript">window._sharedData = ') < 0 && data.indexOf('<script type="text/javascript">window.__additionalDataLoaded(') < 0) {
            return false;;
        }

        var jsondata = JSON.parse(scriptSection);
        if (jsondata && jsondata.entry_data && jsondata.entry_data.ProfilePage && jsondata.entry_data.ProfilePage.length > 0 && jsondata.entry_data.ProfilePage[0].hasOwnProperty('graphql')) {
            var user = jsondata.entry_data.ProfilePage[0].graphql.user;
            return user;
        }

        var jsondataAdditional = JSON.parse(scriptSectionAdditional);
        if (jsondataAdditional && jsondataAdditional.hasOwnProperty('graphql')) {
            var user = jsondataAdditional.graphql.user;
            return user;
        }
    }
    return false;

}


function setCurrentPageHashtag() {
    var hashtagFromUrl = getHashtagFromUrl();

    if (hashtagFromUrl != '') {

        $('#igBotInjectedContainer #btnLikeHashtag')
            .removeClass('inactive')
            .off('click.hashtagButtonError')
            .off('click.ajaxLoadPostsFromHashtag')
            .on('click.ajaxLoadPostsFromHashtag', ajaxLoadPostsFromHashtag)
            .text('Load Posts from #' + hashtagFromUrl);

    } else {


        $('#igBotInjectedContainer #btnLikeHashtag')
            .addClass('inactive')
            .off('click.ajaxLoadPostsFromHashtag')
            .off('click.hashtagButtonError')
            .on('click.hashtagButtonError', function () {
                outputMessage('Error: must be on an instagram hashtag page');
            });
    }
}



function setCurrentPageLocation() {
    var locationFromUrl = getLocationFromUrl();

    if (locationFromUrl != '') {

        $('#igBotInjectedContainer #btnLoadLocationPosts')
            .removeClass('inactive')
            .off('click.locationButtonError')
            .off('click.ajaxLoadPostsFromLocation')
            .on('click.ajaxLoadPostsFromLocation', ajaxLoadPostsFromLocation);


    } else {

        $('#igBotInjectedContainer #btnLoadLocationPosts')
            .addClass('inactive')
            .off('click.ajaxLoadPostsFromLocation')
            .off('click.locationButtonError')
            .on('click.locationButtonError', function () {
                outputMessage('Error: must be on an instagram location page');
            });
    }
}

function getHashtagFromUrl() {

    if ((window.location.href.indexOf('/explore/tags/') == -1) && (window.location.href.indexOf('/explore/search/keyword/?q=%23') == -1)) {
        return '';
    }

    var tagFromUrl = window.location.href;

    if (tagFromUrl.indexOf('/explore/tags/') > -1) {
        tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/tags/', '');
        tagFromUrl = tagFromUrl.slice(0, tagFromUrl.indexOf('/'));
    }

    if (tagFromUrl.indexOf('/explore/search/keyword/?q=%23') > -1) {
        tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/search/keyword/?q=%23', '');
    }

    tagFromUrl = decodeURIComponent(tagFromUrl);

    return tagFromUrl;
}


function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function saveHiddenStatus(hiddenStatus) {
    chrome.storage.sync.set({
        'igBotHidden': hiddenStatus
    });
}

function getHiddenStatus(callback) {

    chrome.storage.sync.get('igBotHidden', function (object) {

        var hiddenStatus = false;

        if (typeof object['igBotHidden'] != 'undefined') {
            hiddenStatus = object['igBotHidden'];
        } else {
            hiddenStatus = false;
        }

        callback(hiddenStatus);

    });

}

function hiddenStatusCallback(hiddenStatus) {
    if (hiddenStatus == true) {
        hideControlsDiv();
    } else {
        openControlsDiv();
    }
}


$.fn.shake = function shake(interval, distance, times) {
    interval = interval || 100;
    distance = distance || 10;
    times = times || 4;

    for (var iter = 0; iter < (times + 1); iter++) {
        //this.animate({ left: ((iter%2==0 ? distance : distance*-1))}, interval);
        this.animate({
            top: ((iter % 2 == 0 ? distance : distance * -1))
        }, interval);
        this.animate({
            top: ''
        }, interval);
    }
}

function userUpdateListener() {
    chrome.runtime.onMessage.addListener(
        function (request, sender, sendResponse) {

            // Coordenadas frescas do botão + (para clique real após hover expandir o menu)
            if (request.vpGetCreateCoords) {
                try {
                    var all = vpCollectCreateCandidates();
                    var best = null, bestArea = Infinity;
                    for (var ci = 0; ci < all.length; ci++) {
                        try {
                            var rci = all[ci].getBoundingClientRect();
                            var area = (rci.width || 0) * (rci.height || 0);
                            if (area > 100 && area < bestArea) { bestArea = area; best = all[ci]; }
                        } catch (e) {}
                    }
                    if (!best) { try { best = findCreateButton(); } catch (e) {} }
                    if (best && best.getBoundingClientRect) {
                        var rc = best.getBoundingClientRect();
                        sendResponse({ success: true, x: Math.round(rc.left + rc.width / 2), y: Math.round(rc.top + rc.height / 2), tag: best.tagName, w: Math.round(rc.width), h: Math.round(rc.height) });
                    } else {
                        sendResponse({ success: false });
                    }
                } catch (e) {
                    try { sendResponse({ success: false }); } catch (e2) {}
                }
                return true;
            }

            if (request.extension_updated) {
                waitForElement('li.tab6', document,
                    function () {
                        clickNotNow(true);
                        $('li.tab6 label').css({
                            'color': 'green'
                        }).click()
                            .delay(100).fadeOut().fadeIn('slow')
                            .delay(100).fadeOut().fadeIn('slow')
                            .delay(100).fadeOut().fadeIn('slow')
                            .delay(100).fadeOut().fadeIn('slow')
                            .delay(100).fadeOut().fadeIn('slow')
                            .delay(100).fadeOut().fadeIn('slow');
                    }, false);

            }

            if (request.clickSomething) {
                // A FAZER, manter seletores aqui em vez de enviar requisição "parent" do backgroundscript
                if (request.clickViewStory) {

                    var tabId = request.tabId;

                    var intervalCloseWhenDone = setInterval(function () {

                        var currentUrl = window.location.href;

                        if (currentUrl.indexOf('/stories/') == -1) {
                            clearInterval(intervalCloseWhenDone);

                            chrome.runtime.sendMessage({
                                "closeStoryTab": {
                                    "tabId": tabId
                                }
                            });
                        }
                    }, 250);

                    var intervalClickViewStory = setInterval(function () {
                        var currentUrl = window.location.href;
                        var matchingElement = $('div[role="button"]:not(:has(svg))');

                        if (currentUrl.indexOf('/stories/') > -1 && matchingElement.length > 0) {
                            clearInterval(intervalClickViewStory);
                            matchingElement.click();

                            chrome.runtime.sendMessage({
                                "viewedStory": true
                            });
                            console.log('clicked view story');
                        }
                    }, 250);

                } else if (request.parent) {
                    $(request.clickSomething).parents(request.parent).click();
                    console.log('clicked  ' + request.clickSomething + ' parent');
                } else {
                    $(request.clickSomething).click();
                    console.log('clicked  ' + request.clickSomething);
                }

                return true;
            }

            if (request.closedStory) {
                closedStoryTab(request);
            }

            // ============ RESULTADO DA VERIFICAÇÃO DE LICENÇA VISION PLUS ============
            if (request.licenseResult) {
                var lr = request.licenseResult;
                instabot_has_license = lr.licensed;

                // Atualizar tab7 "Seu Plano/Contrato" com informações dinâmicas
                updateTab7LicenseInfo(lr);

                // Remover overlay anterior se existir
                var oldOverlay = document.getElementById('vp-license-overlay');
                if (oldOverlay) oldOverlay.remove();

                if (!lr.licensed) {
                    // Licença expirada ou não encontrada — bloquear a extensão
                    var siteUrl = lr.siteUrl || 'https://visionhubweb.com.br';
                    if (siteUrl.startsWith('/')) siteUrl = 'https://visionhubweb.com.br' + siteUrl;

                    var overlayHtml = '<div id="vp-license-overlay" style="'
                        + 'position:absolute; top:0; left:0; right:0; bottom:0;'
                        + 'background:rgba(10,10,20,0.97); z-index:999999;'
                        + 'display:flex; flex-direction:column; align-items:center; justify-content:center;'
                        + 'font-family:Inter,Arial,sans-serif; color:#e0e0f0;'
                        + 'pointer-events:all; cursor:not-allowed;'
                        + '">' 
                        + '<div style="text-align:center; max-width:450px; padding:40px; pointer-events:auto; cursor:default;">' 
                        + '<div style="font-size:60px; margin-bottom:20px;">\uD83D\uDD12</div>' 
                        + '<h2 style="font-size:26px; font-weight:800; margin-bottom:12px; background:linear-gradient(135deg,#6c5ce7,#a29bfe);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">Vision Plus</h2>'
                        + '<p style="font-size:16px; color:#a0a0b8; margin-bottom:8px;">' + (lr.message || 'Sua licen\u00e7a expirou.') + '</p>';

                    if (lr.status === 'not_found') {
                        overlayHtml += '<p style="font-size:14px; color:#6a6a88; margin-bottom:28px;">Crie sua conta no site para ativar a extens\u00e3o.</p>'
                        + '<a href="' + siteUrl + '" target="_blank" style="display:inline-block; padding:14px 32px; background:linear-gradient(135deg,#6c5ce7,#a29bfe); color:#fff; border-radius:12px; font-weight:600; font-size:15px; text-decoration:none; box-shadow:0 4px 20px rgba(108,92,231,0.4); cursor:pointer; pointer-events:auto;">Criar Conta Gr\u00e1tis</a>';
                    } else {
                        overlayHtml += '<p style="font-size:14px; color:#6a6a88; margin-bottom:28px;">Renove sua assinatura para continuar usando.</p>'
                        + '<a href="' + siteUrl + '" target="_blank" style="display:inline-block; padding:14px 32px; background:linear-gradient(135deg,#6c5ce7,#a29bfe); color:#fff; border-radius:12px; font-weight:600; font-size:15px; text-decoration:none; box-shadow:0 4px 20px rgba(108,92,231,0.4); cursor:pointer; pointer-events:auto;">Renovar Assinatura</a>';
                    }

                    overlayHtml += '</div></div>';

                    // Inserir overlay no container principal da extensão para bloquear TODA interação
                    var controlsDiv = document.getElementById('igBotInjectedContainer');
                    if (!controlsDiv) controlsDiv = document.getElementById('igBotControlsDiv');
                    if (controlsDiv) {
                        controlsDiv.style.position = 'relative';
                        controlsDiv.insertAdjacentHTML('beforeend', overlayHtml);
                    }
                } else {
                    // Licença ativa — mostrar mensagem de status
                    console.log('Vision Plus: Licen\u00e7a ativa - ' + (lr.message || ''));
                }
            }

            if (request.toggleGrowbot == true) {
                toggleControlsDiv();
            }

            if (request.openGrowbot == true) {
                openControlsDiv();
            }

            if (request.hideGrowbot == true) {
                hideControlsDiv(false); // don't save the hidden status
            }

            sendResponse({
                response: 'beep beep'
            });
        }
    );
}


// ============ ATUALIZAR TAB7 COM INFORMAÇÕES DA LICENÇA ============
function updateTab7LicenseInfo(lr) {
    var iconEl = document.getElementById('vp-license-icon');
    var titleEl = document.getElementById('vp-license-title');
    var subtitleEl = document.getElementById('vp-license-subtitle');
    var planEl = document.getElementById('vp-detail-plan');
    var expiryEl = document.getElementById('vp-detail-expiry');
    var daysEl = document.getElementById('vp-detail-days');
    var actionEl = document.getElementById('vp-license-action');

    if (!iconEl || !titleEl) return; // Elementos ainda não carregados

    var planLabels = {
        trial: 'Teste Grátis',
        trimestral: 'Trimestral',
        semestral: 'Semestral',
        anual: 'Anual',
        admin: 'Admin ∞'
    };

    function formatDateBR(dateStr) {
        if (!dateStr) return '-';
        var d = new Date(dateStr);
        return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    if (lr.licensed) {
        // ====== LICENÇA ATIVA ======
        if (lr.status === 'trial') {
            iconEl.textContent = '⏳';
            titleEl.textContent = 'PERÍODO DE TESTE GRÁTIS';
            titleEl.style.color = '#74b9ff';
            subtitleEl.textContent = lr.message || 'Aproveite todas as funcionalidades durante o teste.';
            planEl.textContent = 'Trial (7 dias)';
        } else if (lr.status === 'admin') {
            iconEl.textContent = '👑';
            titleEl.textContent = 'CONTA ADMINISTRADOR';
            titleEl.style.color = '#fdcb6e';
            subtitleEl.textContent = 'Acesso permanente e ilimitado.';
            planEl.textContent = 'Admin ∞';
        } else {
            iconEl.textContent = '✅';
            titleEl.textContent = 'PLANO ' + (planLabels[lr.status] || lr.status).toUpperCase() + ' ATIVO';
            titleEl.style.color = '#00b894';
            subtitleEl.textContent = lr.message || 'Sua assinatura está ativa.';
            planEl.textContent = planLabels[lr.status] || lr.status;
        }

        expiryEl.textContent = formatDateBR(lr.expiresAt);
        daysEl.textContent = (lr.daysLeft || 0) + ' dias';

        // Esconder botão de compra quando ativo
        if (actionEl) actionEl.style.display = 'none';

    } else {
        // ====== LICENÇA EXPIRADA ======
        iconEl.textContent = '🔒';
        titleEl.textContent = 'SEU TESTE GRATUITO TERMINOU';
        titleEl.style.color = '#e74c3c';
        subtitleEl.textContent = lr.message || 'Contrate um plano para continuar usando a extensão.';
        planEl.textContent = 'Expirado';
        expiryEl.textContent = '-';
        daysEl.textContent = '0 dias';

        // Mostrar botão de compra
        if (actionEl) actionEl.style.display = 'block';
    }
}


function getObjectWithKey(theObject, theKey) {
    var result = null;
    if (theObject instanceof Array) {
        for (var i = 0; i < theObject.length; i++) {
            result = getObjectWithKey(theObject[i], theKey);
            if (result) {
                break;
            }
        }
    } else {
        for (var prop in theObject) {
            if (prop == theKey) {
                //if(theObject[prop] == 1) {
                return theObject;
                // }
            }
            if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
                result = getObjectWithKey(theObject[prop], theKey);
                if (result) {
                    break;
                }
            }
        }
    }
    return result;
}

function getObjectWithKeyAndValue(theObject, theKey, theValue) {
    var result = null;
    if (theObject instanceof Array) {
        for (var i = 0; i < theObject.length; i++) {
            result = getObjectWithKeyAndValue(theObject[i], theKey, theValue);
            if (result) {
                break;
            }
        }
    } else {
        for (var prop in theObject) {
            if (prop == theKey) {
                if (theObject[prop] == theValue) {

                    return theObject;
                }
            }
            if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
                result = getObjectWithKeyAndValue(theObject[prop], theKey, theValue);
                if (result) {
                    break;
                }
            }
        }
    }
    return result;
}

function extractUserInfoFromScriptTags() {
    var scriptTags = document.getElementsByTagName('script');
    for (var i = 0; i < scriptTags.length; i++) {
        if (scriptTags[i].innerHTML.indexOf('"username":"') > -1) {
            var foundObject = getObjectWithKeyAndValue(JSON.parse(scriptTags[i].innerHTML), 'id', getCookie('ds_user_id'));
            if (foundObject && foundObject.username) {
                user = {
                    "csrf_token": getCookie('csrftoken'),
                    "viewer": foundObject,
                    "viewerId": foundObject.id
                }
                return true;
            }
        }
    }

    return false;
}


function getBackgroundInfo() {
    if (user && user.viewer && user.viewer.username != null) {
        // não precisa fazer nada
    } else {
        if (extractUserInfoFromScriptTags() === false) {
            //outputMessage('Erro ao carregar sua conta. Você pode estar temporariamente bloqueado pelo Instagram, ou não logado. Tente atualizar a página. Se não funcionar, faça uma pausa no uso do Growbot por pelo menos 48 horas.');
            return false;
        }
    }

    $.ajax({
        url: '' + urlAcctInfo + user.viewer.username,
        method: 'GET',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
        },
        xhrFields: {
            withCredentials: true
        }
    })
        .done(function (r) {
            var u = extractJSONfromUserPageHTML(r);

            if (!u.edge_followed_by) {
                outputMessage('Error loading your account.  You may be temporarily blocked by Instagram.  You can try refreshing the page.  If that does not work, please take a break from using Growbot for at least 48 hours.');
                return false;
            } else {
                outputMessage('Current IG User: ' + u.username);
                var statusDiv = document.getElementById('igBotStatusDiv');
                statusDiv.innerHTML = statusDiv.innerHTML.replace(u.username, '<a href="https://www.instagram.com/' + u.username + '/">' + u.username + '</a>');
            }

            chrome.runtime.sendMessage({
                "updatewanted": true,
                "ig_user": user.viewer,
                "ig_user_account_stats": {
                    "date": new Date().toUTCString(),
                    "followers": u.edge_followed_by.count,
                    "following": u.edge_follow.count,
                    "posts": u.edge_owner_to_timeline_media.count
                }
            });
        })
        .fail(function (data) {
            chrome.runtime.sendMessage({
                "updatewanted": true,
                "ig_user": user.viewer,
                "ig_user_account_stats": {}
            });
        });

    // Solicitar verificação de licença após detectar o usuário do Instagram
    if (user && user.viewer && user.viewer.username) {
        window.__vp_current_ig_username = user.viewer.username;
        chrome.runtime.sendMessage({ "checkLicense": user.viewer.username });
        setTimeout(syncAiSettings, 1000); // Sincroniza configurações de IA com um pequeno delay
    }

    // Verificação periódica da licença (a cada 30 minutos)
    if (!window._vpLicenseInterval) {
        window._vpLicenseInterval = setInterval(function() {
            if (user && user.viewer && user.viewer.username) {
                chrome.runtime.sendMessage({ "checkLicense": user.viewer.username });
            }
        }, 30 * 60 * 1000);
    }

}

function dialog(messages, yesCallback, noCallback) {

    $('#igBotDialogQuestion').html(messages.question);

    $('#btnDialogOK').text(messages.yes).off('click.dialogyes').on('click.dialogyes', function () {
        yesCallback();
        document.getElementById('igBotDialog').style.display = 'none'
    });
    $('#btnDialogCancel').text(messages.no).off('click.dialogcancel').on('click.dialogcancel', function () {
        noCallback();
        document.getElementById('igBotDialog').style.display = 'none'
    });

    document.getElementById('igBotDialog').style.display = 'block'
}

(function (global, factory) {
    if (typeof define === "function" && define.amd) {
        define([], factory);
    } else if (typeof exports !== "undefined") {
        factory();
    } else {
        var mod = {
            exports: {}
        };
        factory();
        global.FileSaver = mod.exports;
    }
})(this, function () {
    "use strict";

    /*
     * FileSaver.js
     * Uma implementação de saveAs() do FileSaver.
     *
     * Por Eli Grey, http://eligrey.com
     *
     * Licença : https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md (MIT)
     * fonte   : http://purl.eligrey.com/github/FileSaver.js
     */
    // A única maneira de obter o escopo global em todos os ambientes
    // https://stackoverflow.com/q/3277182/1008999
    var _global = typeof window === 'object' && window.window === window ? window : typeof self === 'object' && self.self === self ? self : typeof global === 'object' && global.global === global ? global : void 0;

    function bom(blob, opts) {
        if (typeof opts === 'undefined') opts = {
            autoBom: false
        };
        else if (typeof opts !== 'object') {
            console.warn('Depricated: Expected third argument to be a object');
            opts = {
                autoBom: !opts
            };
        } // adicionar BOM para tipos UTF-8 XML e text/* (incluindo HTML)
        // nota: seu navegador converterá automaticamente UTF-16 U+FEFF para EF BB BF

        if (opts.autoBom && (/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i).test(blob.type)) {
            return new Blob([String.fromCharCode(0xFEFF), blob], {
                type: blob.type
            });
        }

        return blob;
    }

    function download(url, name, opts) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.responseType = 'blob';

        xhr.onload = function () {
            saveAs(xhr.response, name, opts);
        };

        xhr.onerror = function () {
            console.error('could not download file');
        };

        xhr.send();
    }

    function corsEnabled(url) {
        var xhr = new XMLHttpRequest(); // use sync to avoid popup blocker

        xhr.open('HEAD', url, false);
        xhr.send();
        return xhr.status >= 200 && xhr.status <= 299;
    } // `a.click()` doesn't work for all browsers (#465)


    function click(node) {
        try {
            node.dispatchEvent(new MouseEvent('click'));
        } catch (e) {
            var evt = document.createEvent('MouseEvents');
            evt.initMouseEvent('click', true, true, window, 0, 0, 0, 80, 20, false, false, false, false, 0, null);
            node.dispatchEvent(evt);
        }
    }

    var saveAs = _global.saveAs || ( // probably in some web worker
        typeof window !== 'object' || window !== _global ? function saveAs() { }
            /* sem operação */
            // Usar atributo download primeiro se possível (#193 Lumia mobile)
            :
            'download' in HTMLAnchorElement.prototype ? function saveAs(blob, name, opts) {
                var URL = _global.URL || _global.webkitURL;
                var a = document.createElement('a');
                name = name || blob.name || 'download';
                a.download = name;
                a.rel = 'noopener'; // tabnabbing
                // detectar extensões do chrome e apps empacotados
                // a.target = '_blank'

                if (typeof blob === 'string') {
                    // Suporte a links regulares
                    a.href = blob;

                    if (a.origin !== location.origin) {
                        corsEnabled(a.href) ? download(blob, name, opts) : click(a, a.target = '_blank');
                    } else {
                        click(a);
                    }
                } else {
                    // Suporte a blobs
                    a.href = URL.createObjectURL(blob);
                    setTimeout(function () {
                        URL.revokeObjectURL(a.href);
                    }, 4E4); // 40s

                    setTimeout(function () {
                        click(a);
                    }, 0);
                }
            } // Use msSaveOrOpenBlob as a second approach
                :
                'msSaveOrOpenBlob' in navigator ? function saveAs(blob, name, opts) {
                    name = name || blob.name || 'download';

                    if (typeof blob === 'string') {
                        if (corsEnabled(blob)) {
                            download(blob, name, opts);
                        } else {
                            var a = document.createElement('a');
                            a.href = blob;
                            a.target = '_blank';
                            setTimeout(function () {
                                click(a);
                            });
                        }
                    } else {
                        navigator.msSaveOrOpenBlob(bom(blob, opts), name);
                    }
                } // Fallback to using FileReader and a popup
                    :
                    function saveAs(blob, name, opts, popup) {
                        // Abrir um popup imediatamente para contornar o bloqueador de popups
                        // Geralmente só disponível em interação do usuário e o fileReader é assíncrono então...
                        popup = popup || open('', '_blank');

                        if (popup) {
                            popup.document.title = popup.document.body.innerText = 'downloading...';
                        }

                        if (typeof blob === 'string') return download(blob, name, opts);
                        var force = blob.type === 'application/octet-stream';

                        var isSafari = /constructor/i.test(_global.HTMLElement) || _global.safari;

                        var isChromeIOS = /CriOS\/[\d]+/.test(navigator.userAgent);

                        if ((isChromeIOS || force && isSafari) && typeof FileReader === 'object') {
                            // Safari não permite download de URLs blob
                            var reader = new FileReader();

                            reader.onloadend = function () {
                                var url = reader.result;
                                url = isChromeIOS ? url : url.replace(/^data:[^;]*;/, 'data:attachment/file;');
                                if (popup) popup.location.href = url;
                                else location = url;
                                popup = null; // reverse-tabnabbing #460
                            };

                            reader.readAsDataURL(blob);
                        } else {
                            var URL = _global.URL || _global.webkitURL;
                            var url = URL.createObjectURL(blob);
                            if (popup) popup.location = url;
                            else location.href = url;
                            popup = null; // reverse-tabnabbing #460

                            setTimeout(function () {
                                URL.revokeObjectURL(url);
                            }, 4E4); // 40s
                        }
                    });
    _global.saveAs = saveAs.saveAs = saveAs;

    if (typeof module !== 'undefined') {
        module.exports = saveAs;
    }
});

function monitorButtonConditions() {

    if (acctsQueue.length > 0 || currentList == 'acctsWhiteList') {
        $('.needsQueueAccts').removeClass('inactive');

        if (currentList == 'acctsWhiteList') {
            $('#btnSaveQueueToStorage, #btnExportQueue').hide();
            $('#btnSaveWhiteList').css({
                'display': 'flex'
            });
        } else {
            $('#btnSaveQueueToStorage, #btnExportQueue').css({
                'display': 'flex'
            });
            $('#btnSaveWhiteList').hide();
        }

        if ($('#igBotQueueContainer input:checked').length > 0) {
            $('.needsSelectedAccts').removeClass('inactive');
        } else {
            $('.needsSelectedAccts').addClass('inactive');
        }
    } else {
        $('#btnSaveQueueToStorage, #btnExportQueue').hide();
        $('.needsQueueAccts,.needsSelectedAccts').addClass('inactive');
        $('#queueQuantityRow').hide();
    }

    if (mediaToLike.length > 0) {
        $('.needsMedia').removeClass('inactive');

        if ($('#igBotMediaQueueContainer input:checked').length > 0) {
            $('.needsSelectedMedia').removeClass('inactive');
        } else {
            $('.needsSelectedMedia').addClass('inactive');
        }
    } else {
        $('.needsMedia,.needsSelectedMedia').addClass('inactive');
    }


    if (window.location.href.indexOf("/p/") > -1 || window.location.href.indexOf("/reel/") > -1) {
        $('#btnLoadThisPost').removeClass('inactive');
    } else {
        $('#btnLoadThisPost').addClass('inactive');
    }


    if (timeoutsQueue.length > 0) {
        $('#btnStop,#igBotInjectedContainer #btnStop2').removeClass('inactive').show();
    } else {
        $('#btnStop,#igBotInjectedContainer #btnStop2').addClass('inactive').hide();
    }

    setCurrentPageHashtag();
    setCurrentPageLocation();

    clickNotNow();

    applyTooltips();

}

function showRelink() {
    $('li.tab4 label').click();
    $('#relinkSubscription').attr('open', 'open');
}

function startUserNameFreshnessInterval() {
    clearInterval(usernameCheckInterval);
    usernameCheckInterval = setInterval(function () {

        if ($('#instabotIcon').length == 0) {
            injectIcon();
            shakeInstabotIcon();
        }

        if ($('#igBotInjectedContainer .pulsing').length > 0) {
            $('#instabotIcon').addClass('pulsing');
        } else {
            $('#instabotIcon').removeClass('pulsing');
        }

        checkUsernameFreshness();
    }, 2000);
}

function clickNotNow(override) {
    if (gblOptions.clickNotNow == true || override) {
        var NotNow = $('button:contains("Not Now")');
        if (NotNow.length > 0) {
            outputMessage('Clicked "Not Now" on notifications question');
            NotNow.click();
        }

        NotNow = $('div[role="button"]:contains("Not now")');
        if (NotNow.length > 0) {
            outputMessage('Clicked "Not Now" on save account question');
            NotNow.click();
        }
    }
}

function relinkSubscription() {
    // Função desativada — servidor antigo não está mais disponível
    $('#resultFindSubscription').text('Esta função não está mais disponível.');
}


async function arrayOfUsersToDiv(q, clearDiv) {

    if (typeof clearDiv == 'undefined') clearDiv = true;

    if (clearDiv === true) {
        $('#igBotQueueContainer').children().remove();
    } else {
        $('#igBotQueueContainer').children().not('.igBotQueueAcct').remove();
    }

    if (gblOptions.cbRemoveUnusedColumns == true) {
        for (var i = 0; i < q.length; i++) {
            q[i] = removeAccountPropertiesByColumnCheckboxes(q[i]);
        }
    }

    if (gblOptions.cbShowQueueOnScreen == false) {
        $('#igBotQueueContainer').append('<div style="text-align:center;">You have turned off "Show queue on screen" in Settings.  Your queue is loaded in the background.</div>');
        return false;
    }


    $('#igBotQueueContainer').append('<table id="gridjsAcctsQueueWrapper"></table>');



    var columns = gblOptions.queueColumns;
    columns = columns.filter(e => e.visible !== false);


    var sb = '<thead><tr>';

    for (var i = 0; i < columns.length; i++) {
        sb = sb + '<th data-prop="' + columns[i].data + '" style="width:' + (columns[i].width || '60px') + ';">' + columns[i].name + '</th>';
    }

    sb = sb + '</tr></thead><tbody></tbody>';
    $('#gridjsAcctsQueueWrapper').append(sb);



    for (var i = 0; i < q.length; i++) {
        sb = '<tr>';
        for (var j = 0; j < columns.length; j++) {


            if (columns[j].width) {
                sb = sb + '<td column-data="' + columns[j].data + '" style="width:' + columns[j].width + ';">';
            } else {
                sb = sb + '<td column-data="' + columns[j].data + '">';
            }


            if (columns[j].data) {
                var props = columns[j].data.split('.');


                if (props[1] == 'count' && typeof q[i].edge_followed_by != 'object') {

                    if (q[i][columns[j].data]) {
                        sb = sb + q[i][columns[j].data] + '</td>';

                    } else {
                        sb = sb + '0</td>';

                    }


                } else if (props[1] && q[i].edge_followed_by) {
                    if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                        sb = sb + q[i][props[0]][props[1]] + '</td>';
                    } else {
                        sb = sb + '-</td>';
                    }
                } else {

                    if (typeof q[i][props[0]] != 'undefined' && q[i][props[0]] !== null) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][columns[j].data]) + '</td>';
                        } else {

                            var dataString = q[i][props[0]];

                            if (columns[j].data == 'biography') {

                                var langString = dataString;

                                if (q[i].edge_owner_to_timeline_media && q[i].edge_owner_to_timeline_media.edges && q[i].edge_owner_to_timeline_media.edges.length > 0) {
                                    for (var ci = 0; ci < q[i].edge_owner_to_timeline_media.edges.length; ci++) {

                                        if (q[i].edge_owner_to_timeline_media.edges[ci] && q[i].edge_owner_to_timeline_media.edges[ci].caption && q[i].edge_owner_to_timeline_media.edges[ci].caption.text) {
                                            langString = langString + ' ' + q[i].edge_owner_to_timeline_media.edges[ci].caption.text;
                                        }

                                    }
                                }


                                q[i] = await detectLanguage(langString, q[i]);
                            }

                            if (typeof dataString === 'number' && dataString.toString().indexOf('.') > -1) {
                                dataString = dataString.toFixed(3);
                            }

                            if (columns[j].bool && dataString == '') {
                                dataString = 'false';
                            }



                            sb = sb + dataString + '</td>';
                        }
                    } else {
                        sb = sb + '-</td>';
                    }
                }


            }
        }
        sb = sb + '</tr>';
        $('#gridjsAcctsQueueWrapper tbody').append(sb);
    }


    $('#gridjsAcctsQueueWrapper').tablesorter({

        // *** APPEARANCE ***
        // Add a theme - 'blackice', 'blue', 'dark', 'default', 'dropbox',
        // 'green', 'grey' or 'ice' stylesheets have all been loaded
        // to use 'bootstrap' or 'jui', you'll need to include 'uitheme'
        // in the widgets option - To modify the class names, extend from
        // themes variable. Look for '$.extend($.tablesorter.themes.jui'
        // at the bottom of this window
        // this option only adds a table class name 'tablesorter-{theme}'
        theme: 'blue',

        // fix the column widths
        widthFixed: true,

        // Show an indeterminate timer icon in the header when the table
        // is sorted or filtered
        showProcessing: true,

        // header layout template (HTML ok); {content} = innerHTML,
        // {icon} = <i/> (class from cssIcon)
        headerTemplate: '{content}{icon}',

        // return the modified template string
        onRenderTemplate: null, // function(index, template){ return template; },

        // called after each header cell is rendered, use index to target the column
        // customize header HTML
        onRenderHeader: function (index) {
            // the span wrapper is added by default
            $(this).find('div.tablesorter-header-inner').addClass('roundedCorners');
        },

        // *** FUNCTIONALITY ***
        // prevent text selection in header
        cancelSelection: true,

        // add tabindex to header for keyboard accessibility
        tabIndex: true,

        // other options: 'ddmmyyyy' & 'yyyymmdd'
        dateFormat: 'yyyymmdd',

        // The key used to select more than one column for multi-column
        // sorting.
        sortMultiSortKey: 'shiftKey',

        // key used to remove sorting on a column
        sortResetKey: 'ctrlKey',

        // false for German '1.234.567,89' or French '1 234 567,89'
        usNumberFormat: true,

        // If true, parsing of all table cell data will be delayed
        // until the user initializes a sort
        delayInit: false,

        // if true, server-side sorting should be performed because
        // client-side sorting will be disabled, but the ui and events
        // will still be used.
        serverSideSorting: false,

        // default setting to trigger a resort after an 'update',
        // 'addRows', 'updateCell', etc has completed
        resort: true,

        // *** SORT OPTIONS ***
        // These are detected by default,
        // but you can change or disable them
        // these can also be set using data-attributes or class names
        headers: {
            // set 'sorter : false' (no quotes) to disable the column
            0: {
                sorter: 'text'
            },
            1: {
                sorter: false
            },
        },

        // ignore case while sorting
        ignoreCase: true,

        // forces the user to have this/these column(s) sorted first
        sortForce: null,
        // initial sort order of the columns, example sortList: [[0,0],[1,0]],
        // [[columnIndex, sortDirection], ... ]
        // sortList: [
        //     [0, 0],
        //     [1, 0],
        //     [2, 0]
        // ],
        sortList: [],
        // default sort that is added to the end of the users sort
        // selection.
        sortAppend: null,

        // when sorting two rows with exactly the same content,
        // the original sort order is maintained
        sortStable: false,

        // starting sort direction 'asc' or 'desc'
        sortInitialOrder: 'asc',

        // Replace equivalent character (accented characters) to allow
        // for alphanumeric sorting
        sortLocaleCompare: false,

        // third click on the header will reset column to default - unsorted
        sortReset: true,

        // restart sort to 'sortInitialOrder' when clicking on previously
        // unsorted columns
        sortRestart: false,

        // sort empty cell to bottom, top, none, zero, emptyMax, emptyMin
        emptyTo: 'bottom',

        // sort strings in numerical column as max, min, top, bottom, zero
        stringTo: 'zero',

        // extract text from the table
        textExtraction: {
            0: function (node, table) {
                // this is how it is done by default
                return $(node).attr(table.config.textAttribute) ||
                    node.textContent ||
                    node.innerText ||
                    $(node).text() ||
                    '';
            },
            1: function (node) {
                return $(node).text();
            }
        },

        // data-attribute that contains alternate cell text
        // (used in default textExtraction function)
        textAttribute: 'data-text',

        // use custom text sorter
        // function(a,b){ return a.sort(b); } // basic sort
        textSorter: null,

        // choose overall numeric sorter
        // function(a, b, direction, maxColumnValue)
        numberSorter: null,

        // *** WIDGETS ***
        // apply widgets on tablesorter initialization
        initWidgets: true,

        // table class name template to match to include a widget
        widgetClass: 'widget-{name}',

        // include zebra and any other widgets, options:
        // 'columns', 'filter', 'stickyHeaders' & 'resizable'
        // 'uitheme' is another widget, but requires loading
        // a different skin and a jQuery UI theme.
        widgets: ['pager', 'stickyHeaders', 'storage', 'zebra', 'columns', 'filter'],

        widgetOptions: {

            // zebra widget: adding zebra striping, using content and
            // default styles - the ui css removes the background
            // from default even and odd class names included for this
            // demo to allow switching themes
            // [ 'even', 'odd' ]
            zebra: [
                'ui-widget-content even',
                'ui-state-default odd'
            ],

            // columns widget: change the default column class names
            // primary is the 1st column sorted, secondary is the 2nd, etc
            columns: [
                'primary',
                'secondary',
                'tertiary'
            ],

            // columns widget: If true, the class names from the columns
            // option will also be added to the table tfoot.
            columns_tfoot: true,

            // columns widget: If true, the class names from the columns
            // option will also be added to the table thead.
            columns_thead: true,

            // filter widget: If there are child rows in the table (rows with
            // class name from 'cssChildRow' option) and this option is true
            // and a match is found anywhere in the child row, then it will make
            // that row visible; default is false
            filter_childRows: false,

            // filter widget: If true, a filter will be added to the top of
            // each table column.
            filter_columnFilters: true,

            // filter widget: css class name added to the filter cell
            // (string or array)
            filter_cellFilter: '',

            // filter widget: css class name added to the filter row & each
            // input in the row (tablesorter-filter is ALWAYS added)
            filter_cssFilter: '',

            // filter widget: add a default column filter type
            // '~{query}' to make fuzzy searches default;
            // '{q1} AND {q2}' to make all searches use a logical AND.
            filter_defaultFilter: {},

            // filter widget: filters to exclude, per column
            filter_excludeFilter: {},

            // filter widget: jQuery selector string (or jQuery object)
            // of external filters
            filter_external: '',

            // filter widget: class added to filtered rows;
            // needed by pager plugin
            filter_filteredRow: 'filtered',

            // filter widget: add custom filter elements to the filter row
            filter_formatter: null,

            // filter widget: Customize the filter widget by adding a select
            // dropdown with content, custom options or custom filter functions
            // see http://goo.gl/HQQLW for more details
            filter_functions: null,

            // filter widget: hide filter row when table is empty
            filter_hideEmpty: true,

            // filter widget: Set this option to true to hide the filter row
            // initially. The rows is revealed by hovering over the filter
            // row or giving any filter input/select focus.
            filter_hideFilters: false,

            // filter widget: Set this option to false to keep the searches
            // case sensitive
            filter_ignoreCase: true,

            // filter widget: if true, search column content while the user
            // types (with a delay)
            filter_liveSearch: true,

            // filter widget: a header with a select dropdown & this class name
            // will only show available (visible) options within the drop down
            filter_onlyAvail: 'filter-onlyAvail',

            // filter widget: default placeholder text
            // (overridden by any header 'data-placeholder' setting)
            filter_placeholder: {
                search: '',
                select: ''
            },

            // filter widget: jQuery selector string of an element used to
            // reset the filters.
            filter_reset: null,

            // filter widget: Use the $.tablesorter.storage utility to save
            // the most recent filters
            filter_saveFilters: false,

            // filter widget: Delay in milliseconds before the filter widget
            // starts searching; This option prevents searching for every character
            // while typing and should make searching large tables faster.
            filter_searchDelay: 300,

            // filter widget: allow searching through already filtered rows in
            // special circumstances; will speed up searching in large tables if true
            filter_searchFiltered: true,

            // filter widget: include a function to return an array of values to be
            // added to the column filter select
            filter_selectSource: null,

            // filter widget: Set this option to true if filtering is performed on
            // the server-side.
            filter_serversideFiltering: false,

            // filter widget: Set this option to true to use the filter to find
            // text from the start of the column. So typing in 'a' will find
            // 'albert' but not 'frank', both have a's; default is false
            filter_startsWith: false,

            // filter widget: If true, ALL filter searches will only use parsed
            // data. To only use parsed data in specific columns, set this option
            // to false and add class name 'filter-parsed' to the header
            filter_useParsedData: false,

            // filter widget: data attribute in the header cell that contains
            // the default filter value
            filter_defaultAttrib: 'data-value',

            // filter widget: filter_selectSource array text left of the separator
            // is added to the option value, right into the option text
            filter_selectSourceSeparator: '|',

            // starting page of the pager (zero based index)
            pager_startPage: 0,

            // Number of visible rows - default is 10
            pager_size: gblOptions.paginationLimit,

            // reset pager after filtering; set to desired page #
            // set to false to not change page at filter start
            pager_pageReset: 0,

            // output string - default is '{page}/{totalPages}';
            // possible variables:
            // {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
            // pager_output: '{startRow} to {endRow} ({totalRows})',
            pager_output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',

            // apply disabled classname to the pager arrows when the rows at
            // either extreme is visible - default is true
            pager_updateArrows: true,

            // Number of options to include in the pager number selector
            pager_maxOptionSize: 20,

            // Save pager page & size if the storage script is loaded
            // (requires $.tablesorter.storage in jquery.tablesorter.widgets.js)
            pager_savePages: true,

            // defines custom storage key
            pager_storageKey: 'tablesorter-pager',

            // if true, the table will remain the same height no matter how many
            // records are displayed. The space is made up by an empty
            // table row set to a height to compensate; default is false
            pager_fixedHeight: false,

            // count child rows towards the set page size?
            // (set true if it is a visible table row within the pager)
            // if true, child row(s) may not appear to be attached to its
            // parent row, may be split across pages or
            // may distort the table if rowspan or cellspans are included.
            pager_countChildRows: false,

            // remove rows from the table to speed up the sort of large tables.
            // setting this to false, only hides the non-visible rows; needed
            // if you plan to add/remove rows with the pager enabled.
            pager_removeRows: false,

            // css class names used by pager elements
            pager_css: {
                // class added to pager container
                container: 'tablesorter-pager',
                // error information row (don't include period at beginning)
                errorRow: 'tablesorter-errorRow',
                // class added to arrows @ extremes
                // (i.e. prev/first arrows "disabled" on first page)
                disabled: 'disabled'
            },

            // jQuery selectors
            pager_selectors: {
                // target the pager markup
                container: '.pager',
                // go to first page arrow
                first: '.first',
                // previous page arrow
                prev: '.prev',
                // next page arrow
                next: '.next',
                // go to last page arrow
                last: '.last',
                // go to page selector - select dropdown that sets the current page
                gotoPage: '.gotoPage',
                // location of where the "output" is displayed
                pageDisplay: '.pagedisplay',
                // page size selector - select dropdown that sets the "size" option
                pageSize: '.pagesize'
            },

            // Resizable widget: If this option is set to false, resized column
            // widths will not be saved. Previous saved values will be restored
            // on page reload
            resizable: true,

            // Resizable widget: If this option is set to true, a resizing anchor
            // will be included in the last column of the table
            resizable_addLastColumn: false,

            // Resizable widget: Set this option to the starting & reset header widths
            resizable_widths: [],

            // Resizable widget: Set this option to throttle the resizable events
            // set to true (5ms) or any number 0-10 range
            resizable_throttle: false,

            // saveSort widget: If this option is set to false, new sorts will
            // not be saved. Any previous saved sort will be restored on page
            // reload.
            saveSort: false,

            // stickyHeaders widget: extra class name added to the sticky header row
            stickyHeaders: '',

            // jQuery selector or object to attach sticky header to
            stickyHeaders_attachTo: '#igBotQueueContainer',

            // jQuery selector or object to monitor horizontal scroll position
            // (defaults: xScroll > attachTo > window)
            stickyHeaders_xScroll: null,

            // jQuery selector or object to monitor vertical scroll position
            // (defaults: yScroll > attachTo > window)
            stickyHeaders_yScroll: null,

            // number or jquery selector targeting the position:fixed element
            stickyHeaders_offset: 0,

            // scroll table top into view after filtering
            stickyHeaders_filteredToTop: true,

            // added to table ID, if it exists
            stickyHeaders_cloneId: '-sticky',

            // trigger 'resize' event on headers
            stickyHeaders_addResizeEvent: true,

            // if false and a caption exist, it won't be included in the
            // sticky header
            stickyHeaders_includeCaption: true,

            // The zIndex of the stickyHeaders, allows the user to adjust this
            // to their needs
            stickyHeaders_zIndex: 2

        },

        // *** CALLBACKS ***
        // function called after tablesorter has completed initialization
        initialized: function () {

        }, // function (table) {}

        // *** extra css class names
        tableClass: '',
        cssAsc: '',
        cssDesc: '',
        cssNone: '',
        cssHeader: '',
        cssHeaderRow: '',
        // processing icon applied to header during sort/filter
        cssProcessing: '',

        // class name indiciating that a row is to be attached to the its parent
        cssChildRow: 'tablesorter-childRow',
        // if this class does not exist, the {icon} will not be added from
        // the headerTemplate
        cssIcon: 'tablesorter-icon',
        // class name added to the icon when there is no column sort
        cssIconNone: '',
        // class name added to the icon when the column has an ascending sort
        cssIconAsc: '',
        // class name added to the icon when the column has a descending sort
        cssIconDesc: '',
        // don't sort tbody with this class name
        // (only one class name allowed here!)
        cssInfoBlock: 'tablesorter-infoOnly',
        // class name added to table header which allows clicks to bubble up
        cssAllowClicks: 'tablesorter-allowClicks',
        // header row to ignore; cells within this row will not be added
        // to table.config.$headers
        cssIgnoreRow: 'tablesorter-ignoreRow',

        // *** SELECTORS ***
        // jQuery selectors used to find the header cells.
        selectorHeaders: '> thead th, > thead td',

        // jQuery selector of content within selectorHeaders
        // that is clickable to trigger a sort.
        selectorSort: 'th, td',

        // rows with this class name will be removed automatically
        // before updating the table cache - used by 'update',
        // 'addRows' and 'appendCache'
        selectorRemove: '.remove-me',

        // *** DEBUGING ***
        // send messages to console
        debug: false

    }).bind("sortEnd", function (e, t) {
        sortQueueByTableSort();
        handleCheckBoxes();
    });



    handleCheckBoxes();
    handleImagePreload();

    if (clearDiv == true) {
        $('#paginationLimit option:selected').attr("selected", null);
        $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");
        $('#gridjsAcctsQueueWrapper').trigger('pageSize', gblOptions.paginationLimit);
    }

    $('#queueQuantityRow').show();
}


function exportQueue() {

    saveText(generateFileName() + ".csv", exportToCsv(acctsQueue));

}

async function detectLanguage(dataString, a) {
    let langInfo = await chrome.i18n.detectLanguage(dataString);

    const languageNames = new Intl.DisplayNames(['en'], {
        type: 'language'
    });

    var highestPercentage = 0;

    a['languageCount'] = langInfo.languages.length;

    for (const lang of langInfo.languages) {

        if (lang.percentage > highestPercentage) {
            a['languageCode'] = lang.language;
            a['languageName'] = languageNames.of(lang.language);
            a['languagePercentage'] = lang.percentage;
        }

        highestPercentage = lang.percentage;
    }

    return a;

}


function removeAccountPropertiesByColumnCheckboxes(a) {
    var visibleColumns = gblOptions.queueColumns;
    visibleColumns = visibleColumns.filter(e => e.visible !== false);

    var acctCopy = {};

    for (var j = 0; j < visibleColumns.length; j++) {

        var props = visibleColumns[j].data.split('.');

        if (props[1] && a.edge_followed_by) {
            if (a[props[0]] && a[props[0]][props[1]]) {
                // acctCopy[visibleColumns[j].data] = a[props[0]][props[1]];
                acctCopy[props[0]] = {
                    [props[1]]: a[props[0]][props[1]]
                }
            }
        } else {
            if (a[visibleColumns[j].data]) {
                if (Array.isArray(a[visibleColumns[j].data]) == true) {
                    acctCopy[visibleColumns[j].data] = a[visibleColumns[j].data].join('/');

                } else {
                    acctCopy[visibleColumns[j].data] = a[visibleColumns[j].data];
                }
            } else {
                acctCopy[visibleColumns[j].data] = '';
            }
        }
    }

    return acctCopy;

}


function exportToCsv(q) {

    var items = [];

    var visibleColumns = gblOptions.queueColumns;
    visibleColumns = visibleColumns.filter(e => e.visible !== false);

    for (var i = 0; i < q.length; i++) {
        var acctCopy = removeAccountPropertiesByColumnCheckboxes(q[i]);

        items.push(acctCopy);

    }

    const header = Object.keys(items[0]);
    const headerString = header.join(',');
    // handle null or undefined values here
    const replacer = function (key, value) {
        return value === null ? '' : value
    }
    const rowItems = items.map((row) =>
        header
            .map((fieldName) => JSON.stringify(row[fieldName], replacer))
            .join(',')
    );
    // join header and body, and break into separate lines
    const csv = [headerString, ...rowItems].join('\r\n');
    return csv;
}

function sortQueueByTableSort() {
    var sortingArr = [];
    $('#gridjsAcctsQueueWrapper input[type="checkbox"]').each(function () {
        sortingArr.push($(this).val())
    });

    acctsQueue.sort(function (a, b) {
        return sortingArr.indexOf(a.id) - sortingArr.indexOf(b.id);
    });
}

function sortMediaQueueByTableSort() {
    var sortingArr = [];
    $('#gridjsMediaQueueWrapper input[type="checkbox"]').each(function () {
        sortingArr.push($(this).val())
    });

    mediaToLike.sort(function (a, b) {
        return sortingArr.indexOf(a.id) - sortingArr.indexOf(b.id);
    });
}

function pretarkt(str) {
    if ((str !== attarkt(1) + attarkt(2) + attarkt(3) + attarkt(91)) && (str !== stringArrayExtensionId() + attarkt(69))) return false;
    return true;
}

function attarkt(nummer) {

    if (nummer == 1) return 'cGNvZW';

    if (nummer == 3) return 'VtamJtaWFsY2lkaW9pZm0';

    if (nummer == 2) return 'lvZmFsa25haGdoaW';

    return '=';
}


function stringArrayExtensionId() {
    var arr = [
        "Y",
        "W",
        "J",
        "o",
        "Y",
        "2",
        "d",
        "v",
        "a",
        "2",
        "1",
        "u",
        "Z",
        "G",
        "J",
        "p",
        "Z",
        "W",
        "d",
        "t",
        "b",
        "W",
        "J",
        "q",
        "Z",
        "m",
        "Z",
        "k",
        "b",
        "H",
        "B",
        "p",
        "a",
        "G",
        "d",
        "k",
        "b",
        "W",
        "V",
        "l",
        "a",
        "m",
        "Y",
    ];
    return '' + arr.join('');
}

function shouldLoadGrowbotOnThisPage() {

    var shouldLoad = true;

    var forbiddenStrings = ["Sorry, this page isn't available.",
        "There's an issue and the page could not be loaded.",
        "Reload page",
        "Log in"
    ];

    if (window.location.href.indexOf('.instagram.com') === -1) shouldLoad = false;
    if (window.location.href.indexOf('/developer/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/challenge/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/auth_platform/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/accounts/') > -1 && window.location.href.indexOf('/accounts/onetap/') == -1) shouldLoad = false;
    if (document.getElementById('loginForm')) shouldLoad = false;

    var divButtons = document.querySelectorAll('div[role="button"], span');

    for (var i = 0; i < divButtons.length; i++) {
        if (forbiddenStrings.includes(divButtons[i].innerText)) {
            shouldLoad = false;
        }
    }

    if (shouldLoad === false) {
        console.log('Cannot load Growbot on this page');

        navigation.addEventListener("navigate", e => {
            setTimeout(waitForDomReady, 2000);
        });
    }

    //  if (pretarkt((extId)) == false) shouldLoad = false;

    return shouldLoad;
}


// ============ ROTINAS DE INTERAÇÃO (ALVO / FEED) ============

function ajaxLikePost(mediaPk) {
    var idToLike = String(mediaPk || '');
    if (idToLike.indexOf('_') > -1) idToLike = idToLike.split('_')[0];
    var actorId = (typeof getInstagramActorId === 'function' ? getInstagramActorId() : '') || '';
    var lsd = (typeof getInstagramLsdToken === 'function' ? getInstagramLsdToken() : '') || '';
    var fbDtsg = (typeof getInstagramFbDtsg === 'function' ? getInstagramFbDtsg() : '') || '';
    var jazoest = (typeof getInstagramJazoest === 'function' ? getInstagramJazoest(fbDtsg) : '') || '';
    if (!actorId && typeof getCookie === 'function') {
        var dsUserId = getCookie('ds_user_id');
        if (dsUserId) actorId = '178414' + String(dsUserId);
    }
    var mutationVariables = {
        input: {
            media_id: idToLike,
            actor_id: actorId,
            client_mutation_id: "1"
        }
    };
    var body = [
        'av=' + encodeURIComponent(actorId),
        '__d=www',
        '__user=0',
        '__a=1',
        '__comet_req=7',
        'fb_dtsg=' + encodeURIComponent(fbDtsg),
        'jazoest=' + encodeURIComponent(jazoest),
        'lsd=' + encodeURIComponent(lsd),
        'fb_api_caller_class=RelayModern',
        'fb_api_req_friendly_name=PolarisAPILikePostMutation',
        'server_timestamps=true',
        'variables=' + encodeURIComponent(JSON.stringify(mutationVariables)),
        'doc_id=27232073366423857'
    ];
    return $.ajax({
        url: 'https://www.instagram.com/api/graphql',
        method: 'POST',
        data: body.join('&'),
        dataType: 'json',
        beforeSend: function (xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
            xhr.setRequestHeader('x-asbd-id', '359341');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            xhr.setRequestHeader('x-fb-friendly-name', 'PolarisAPILikePostMutation');
            xhr.setRequestHeader('x-fb-lsd', lsd);
        },
        xhrFields: { withCredentials: true }
    });
}

function ajaxCommentOnMedia(mediaPk, text) {
    return $.ajax({
        url: 'https://www.instagram.com/api/v1/web/comments/' + mediaPk + '/add/',
        method: 'POST',
        data: { comment_text: text },
        headers: {
            'X-Csrftoken': getCsrfFromCookie(),
            'X-Instagram-AJAX': '1010212815',
            'X-IG-App-ID': '936619743392459',
            'X-Requested-With': 'XMLHttpRequest'
        },
        xhrFields: { withCredentials: true }
    });
}

var targetLcQueue = [];
async function initLikeAndCommentTarget() {
    if (!vpLicenseGuard()) return false;
    
    let mode = $('input[name="lcMode"]:checked').val();
    let targetCount = parseInt($('#txtActionTargetCount').val()) || 10;
    
    if (mode === 'target') {
        let targetUserInput = $('#txtActionTargetProfile').val().replace('@','').trim();
        if (!targetUserInput) { alert("Insira o username alvo!"); return; }
        
        outputMessage("Carregando posts de: " + targetUserInput);
        $.ajax({
            url: 'https://www.instagram.com/api/v1/feed/user/' + targetUserInput + '/username/?count=' + targetCount,
            method: 'GET',
            headers: { 
                'x-ig-app-id': '936619743392459',
                'x-csrftoken': getCsrfFromCookie(),
                'x-requested-with': 'XMLHttpRequest'
            },
            xhrFields: { withCredentials: true }
        }).done(function(res) {
            if(res && res.items) {
                targetLcQueue = res.items.slice(0, targetCount);
                outputMessage(targetLcQueue.length + " posts carregados do alvo. Iniciando interações...");
                processNextTargetLc();
            } else {
                outputMessage("Erro: Não foi possível carregar posts do alvo.");
            }
        }).fail(() => outputMessage("Erro ao buscar perfil alvo"));
    } else {
        outputMessage("Carregando posts do seu Feed (Home)...");
        $.ajax({
            url: 'https://www.instagram.com/api/v1/feed/timeline/',
            method: 'GET',
            headers: { 
                'x-ig-app-id': '936619743392459',
                'x-csrftoken': getCsrfFromCookie(),
                'x-requested-with': 'XMLHttpRequest'
            },
            xhrFields: { withCredentials: true }
        }).done(function(res) {
            if(res && res.feed_items) {
                // Filtrar apenas itens que são media
                targetLcQueue = res.feed_items
                    .filter(i => i.media_or_ad && !i.media_or_ad.dr_ad_type)
                    .map(i => i.media_or_ad)
                    .slice(0, targetCount);
                outputMessage(targetLcQueue.length + " posts carregados do feed. Iniciando interações...");
                processNextTargetLc();
            } else {
                outputMessage("Erro: Não foi possível carregar o feed.");
            }
        }).fail(() => outputMessage("Erro ao buscar feed"));
    }
}

function processNextTargetLc() {
    if(!vpLicenseGuard()) return;
    if(targetLcQueue.length == 0) {
        outputMessage("Interações concluídas.");
        return;
    }
    
    let media = targetLcQueue.shift();
    let mediaPk = media.pk || media.id;
    let owner = media.user ? media.user.username : 'post';
    
    outputMessage("Interagindo com post de: " + owner);
    
    // Curtir
    ajaxLikePost(mediaPk).done(() => {
        outputMessage("Post curtido com sucesso.");
        
        // Comentar (se houver frases)
        let commentsText = $('#txtActionTargetComments').val().trim();
        if (commentsText) {
            let lines = commentsText.split('\n').filter(l => l.trim().length > 0);
            if (lines.length > 0) {
                let randomComment = lines[Math.floor(Math.random() * lines.length)];
                setTimeout(() => {
                    ajaxCommentOnMedia(mediaPk, randomComment).done(() => {
                        outputMessage("Comentário enviado: " + randomComment);
                        scheduleNextLc();
                    }).fail(() => {
                        outputMessage("Erro ao comentar.");
                        scheduleNextLc();
                    });
                }, 2000); // Pequeno delay de 2s entre like e comment
                return;
            }
        }
        scheduleNextLc();
    }).fail(() => {
        outputMessage("Erro ao curtir (possível block temporário).");
        scheduleNextLc();
    });
}

function scheduleNextLc() {
    let baseTime = gblOptions.timeDelay || 60000;
    let pct = (gblOptions.percentRandomTimeDelay > 0) ? gblOptions.percentRandomTimeDelay : 0.25;
    let waitTime = getRandomInt(Math.max(0, baseTime - (baseTime * pct)), baseTime + (baseTime * pct));
    outputMessage("Aguardando " + (waitTime/1000).toFixed(1) + "s para próxima interação...");
    timeoutsQueue.push(setTimeout(processNextTargetLc, waitTime));
}

// ============ AÇÕES AGENDADAS (growbotActionRunner) ============
// Wrappers usados pelo agendador. Precisam existir no escopo global para
// window[functionName](arguments) funcionar sem quebrar.

function initLikeAndCommentTargetProfile(args) {
    initLikeAndCommentTarget();
}

function initDmToTargetFollowers(args) {
    if (!vpLicenseGuard()) return false;
    outputMessage("DM para seguidores de alvo: limite diário atingido ou recurso em manutenção. Configure manualmente na aba Perfil Alvo.");
    alert("A automação de DM para seguidores de alvo ainda não está habilitada na sua versão.\n\nUse o agendamento para Curtir/Comentar (Perfil Alvo), Carregar Posts do Feed ou Assistir Reels.");
    return false;
}

$('body').on('click', '#btnStartTargetLc', function(e) {
    e.preventDefault();
    initLikeAndCommentTarget();
});

$('body').on('click', '#btnStopTargetLc', function(e) {
    e.preventDefault();
    targetLcQueue = [];
    outputMessage("Interações interrompidas!");
});

$('body').on('change', 'input[name="lcMode"]', function() {
    if ($(this).val() === 'feed') {
        $('#divTargetInput').hide();
    } else {
        $('#divTargetInput').show();
    }
});

$('body').on('change', '#txtActionTargetProfile, #txtActionTargetCount, #txtActionTargetComments', function() {
    saveOptions();
});

// ============ AUTOMAÇÃO DE POSTAGENS COM INTELIGÊNCIA ARTIFICIAL ============

var gblAiSettings = null;
var aiPostingSchedulerInterval = null;

function syncAiSettings() {
    var username = window.__vp_current_ig_username || (user && user.viewer && user.viewer.username);
    if (!username) {
        $('#vp_ai_status').text('Aguardando usuário...').css('color', '#ecc94b');
        return;
    }
    
    $('#vp_ai_status').text('Sincronizando...').css('color', '#3182ce');
    
    chrome.runtime.sendMessage({ fetchAiSettings: username }, function(response) {
        if (chrome.runtime.lastError) {
            console.error("Erro ao sincronizar configurações:", chrome.runtime.lastError);
            $('#vp_ai_status').text('Erro na conexão').css('color', '#e53e3e');
            return;
        }
        
        if (response && response.success && response.settings) {
            var settings = response.settings;
            gblAiSettings = settings;
            
            // Salva no storage local do chrome
            chrome.storage.local.set({ 'vp_ai_settings': JSON.stringify(settings) });
            
            // Atualiza interface
            var statusText = settings.is_enabled ? 'Ativo ✅' : 'Desativado ❌';
            var statusColor = settings.is_enabled ? '#48bb78' : '#e53e3e';
            $('#vp_ai_status').text(statusText).css('color', statusColor);
            
            var modeText = settings.niche_mode === 'auto' ? 'Automático (Tendências/Dark)' : 'Manual';
            $('#vp_ai_mode').text(modeText);
            
            var nicheText = settings.niche_mode === 'auto' ? 'Assunto de tendência viral' : (settings.niche_product || 'Não configurado');
            $('#vp_ai_niche_product').text(nicheText);
            
            $('#vp_ai_time').text(settings.post_time || '--:--');
            
            console.log("Configurações de IA sincronizadas:", settings);
            
            // Inicializa ou reinicializa o scheduler
            initAiPostingScheduler();
        } else {
            var errMsg = (response && response.error) ? response.error : 'Erro desconhecido';
            $('#vp_ai_status').text('Erro: ' + errMsg).css('color', '#e53e3e');
        }
    });
}

function initAiPostingScheduler() {
    if (aiPostingSchedulerInterval) {
        clearInterval(aiPostingSchedulerInterval);
    }
    
    // Inicia um loop que verifica a cada 60 segundos
    aiPostingSchedulerInterval = setInterval(checkSchedulerAndPost, 60000);
    // Também faz uma verificação imediata após 5 segundos
    setTimeout(checkSchedulerAndPost, 5000);
}

function isTimeMatch(currentTime, scheduledTime) {
    if (currentTime === scheduledTime) return true;
    
    try {
        var cParts = currentTime.split(':').map(Number);
        var sParts = scheduledTime.split(':').map(Number);
        
        var cMin = cParts[0] * 60 + cParts[1];
        var sMin = sParts[0] * 60 + sParts[1];
        
        // Tolerância de 30 minutos após o horário agendado
        return cMin >= sMin && cMin <= (sMin + 30);
    } catch(e) {
        return false;
    }
}

async function checkSchedulerAndPost() {
    console.log("[Scheduler] Verificando... gblAiSettings:", gblAiSettings ? "carregado" : "null");
    
    if (!gblAiSettings) {
        // Tenta ler do cache local
        chrome.storage.local.get('vp_ai_settings', function(data) {
            if (data.vp_ai_settings) {
                gblAiSettings = JSON.parse(data.vp_ai_settings);
                console.log("[Scheduler] Settings carregadas do cache:", gblAiSettings);
            } else {
                console.log("[Scheduler] Sem settings no cache.");
            }
        });
        return;
    }
    
    if (!gblAiSettings.is_enabled) {
        console.log("[Scheduler] IA desativada (is_enabled=false). Abortando.");
        return;
    }
    
    // Verificar se hoje é um dos dias programados
    var now = new Date();
    var currentDay = now.getDay(); // 0=Domingo, 1=Segunda, etc.
    var rawDays = gblAiSettings.post_days || '';
    console.log("[Scheduler] post_days bruto:", rawDays, "| Dia atual:", currentDay);
    
    // Se post_days estiver vazio, assumir todos os dias
    var scheduledDays;
    if (!rawDays || rawDays.trim() === '') {
        scheduledDays = [0, 1, 2, 3, 4, 5, 6]; // Todos os dias
        console.log("[Scheduler] post_days vazio, assumindo todos os dias.");
    } else {
        scheduledDays = rawDays.split(',').map(function(d) { return parseInt(d.trim(), 10); }).filter(function(d) { return !isNaN(d); });
    }
    
    console.log("[Scheduler] Dias programados:", scheduledDays, "| Inclui hoje?", scheduledDays.includes(currentDay));
    
    if (!scheduledDays.includes(currentDay)) {
        console.log("[Scheduler] Hoje não é um dia programado. Abortando.");
        return;
    }
    
    // Verificar horário
    var currentHours = String(now.getHours()).padStart(2, '0');
    var currentMinutes = String(now.getMinutes()).padStart(2, '0');
    var currentTimeString = currentHours + ':' + currentMinutes; // "HH:MM"
    
    var scheduledTime = gblAiSettings.post_time || '09:00';
    
    console.log("[Scheduler] Hora atual:", currentTimeString, "| Hora agendada:", scheduledTime, "| Match?", isTimeMatch(currentTimeString, scheduledTime));
    
    if (isTimeMatch(currentTimeString, scheduledTime)) {
        var todayStr = now.getFullYear() + '-' + (now.getMonth() + 1) + '-' + now.getDate();
        chrome.storage.local.get(['vp_ai_last_post_date', 'vp_ai_posting_lock', 'vp_ai_daily_attempts', 'vp_ai_attempts_date'], function(data) {
            var lastPostDate = data.vp_ai_last_post_date;
            var lockTime = data.vp_ai_posting_lock || 0;
            var attempts = data.vp_ai_daily_attempts || 0;
            var attemptsDate = data.vp_ai_attempts_date || '';
            
            console.log("[Scheduler] lastPostDate:", lastPostDate, "| todayStr:", todayStr, "| lockTime:", lockTime, "| attempts:", attempts, "| attemptsDate:", attemptsDate);
            
            if (attemptsDate !== todayStr) {
                attempts = 0; // Resetar contador no novo dia
            }
            
            // Se já postou hoje, não posta de novo
            if (lastPostDate === todayStr) {
                console.log("[Scheduler] Já postou hoje. Abortando.");
                return;
            }
            
            // Proteção contra looping: abortar se falhou muitas vezes hoje
            if (attempts >= 3) {
                console.log("[Scheduler] Abortando: 3 tentativas falhas hoje.");
                chrome.storage.local.set({ 'vp_ai_last_post_date': todayStr });
                return;
            }
            
            // Se houver um lock ativo nos últimos 5 minutos, outra aba está postando
            if (Date.now() - lockTime < 5 * 60 * 1000) {
                console.log("[Scheduler] Outra aba já está executando a postagem automática (lock ativo).");
                return;
            }
            
            // Define o lock e incrementa as tentativas para evitar loops
            chrome.storage.local.set({ 
                'vp_ai_posting_lock': Date.now(),
                'vp_ai_daily_attempts': attempts + 1,
                'vp_ai_attempts_date': todayStr
            }, function() {
                console.log("[Scheduler] ✅ DISPARANDO POSTAGEM AUTOMÁTICA! Horário:", scheduledTime);
                simulateInstagramPost(false);
            });
        });
    }
}

// Gera um delay aleatório humanizado (entre min e max ms)
function humanDelay(minMs, maxMs) {
    var delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    return new Promise(function(resolve) { setTimeout(resolve, delay); });
}

// Suprime erros do console durante automação para evitar fingerprinting
var __vp_original_console_error = null;
function suppressConsoleErrors() {
    if (__vp_original_console_error) return; // já suprimido
    __vp_original_console_error = console.error;
    console.error = function() {
        // Filtra erros conhecidos do Instagram que não são nossos
        var msg = Array.prototype.join.call(arguments, ' ');
        if (msg.indexOf('crossposting') > -1 || 
            msg.indexOf('Invariant Violation') > -1 ||
            msg.indexOf('ErrorUtils') > -1 ||
            msg.indexOf('Cannot read properties of null') > -1) {
            return; // Suprime silenciosamente
        }
        __vp_original_console_error.apply(console, arguments);
    };
}
function restoreConsoleErrors() {
    if (__vp_original_console_error) {
        console.error = __vp_original_console_error;
        __vp_original_console_error = null;
    }
}

// ============================================================
// CANVAS TEXT OVERLAY - Desenha texto diretamente na imagem
// ============================================================
function drawTextOverlayOnImage(blob, textOverlay, callback) {
    if (!textOverlay || textOverlay.trim() === '') {
        // Sem texto para sobrepor, retorna o blob original
        callback(blob);
        return;
    }
    
    var img = new Image();
    var objectUrl = URL.createObjectURL(blob);
    
    img.onload = function() {
        try {
            var canvas = document.createElement('canvas');
            var W = img.naturalWidth || img.width;
            var H = img.naturalHeight || img.height;
            canvas.width = W;
            canvas.height = H;
            var ctx = canvas.getContext('2d');
            
            // 1. Desenhar a imagem original no canvas
            ctx.drawImage(img, 0, 0, W, H);
            
            // 2. Barra de gradiente no TOPO (de preto semi-transparente para transparente)
            var topBarHeight = Math.round(H * 0.22);
            var gradTop = ctx.createLinearGradient(0, 0, 0, topBarHeight);
            gradTop.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
            gradTop.addColorStop(0.6, 'rgba(0, 0, 0, 0.35)');
            gradTop.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = gradTop;
            ctx.fillRect(0, 0, W, topBarHeight);
            
            // 3. Texto principal no topo (overlay)
            var fontSize = Math.round(W * 0.065);
            if (fontSize < 28) fontSize = 28;
            if (fontSize > 72) fontSize = 72;
            
            ctx.font = '900 ' + fontSize + 'px "Segoe UI", "Arial Black", "Impact", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            
            var textX = W / 2;
            var textY = Math.round(H * 0.04);
            var maxWidth = W * 0.85;
            
            // Quebrar texto em linhas se for muito longo
            var words = textOverlay.toUpperCase().split(' ');
            var lines = [];
            var currentLine = '';
            for (var i = 0; i < words.length; i++) {
                var testLine = currentLine ? currentLine + ' ' + words[i] : words[i];
                if (ctx.measureText(testLine).width > maxWidth && currentLine) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            if (currentLine) lines.push(currentLine);
            
            // Desenhar cada linha com sombra
            for (var j = 0; j < lines.length; j++) {
                var lineY = textY + (j * (fontSize * 1.25));
                
                // Sombra preta forte para legibilidade
                ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
                ctx.shadowBlur = 8;
                ctx.shadowOffsetX = 2;
                ctx.shadowOffsetY = 2;
                
                // Contorno preto (stroke)
                ctx.strokeStyle = 'rgba(0, 0, 0, 0.8)';
                ctx.lineWidth = Math.round(fontSize * 0.08);
                ctx.strokeText(lines[j], textX, lineY, maxWidth);
                
                // Texto branco principal
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(lines[j], textX, lineY, maxWidth);
            }
            
            // 4. Barra de gradiente no RODAPÉ (de transparente para preto semi-transparente)
            var bottomBarHeight = Math.round(H * 0.12);
            var gradBottom = ctx.createLinearGradient(0, H - bottomBarHeight, 0, H);
            gradBottom.addColorStop(0, 'rgba(0, 0, 0, 0)');
            gradBottom.addColorStop(1, 'rgba(0, 0, 0, 0.55)');
            ctx.fillStyle = gradBottom;
            ctx.fillRect(0, H - bottomBarHeight, W, bottomBarHeight);
            
            // 5. Marca d'água sutil no rodapé
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;
            var watermarkSize = Math.round(W * 0.028);
            if (watermarkSize < 12) watermarkSize = 12;
            ctx.font = '600 ' + watermarkSize + 'px "Segoe UI", Arial, sans-serif';
            ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'bottom';
            ctx.fillText('Vision Plus AI', W - Math.round(W * 0.03), H - Math.round(H * 0.02));
            
            // 6. Converter canvas de volta para blob
            canvas.toBlob(function(resultBlob) {
                URL.revokeObjectURL(objectUrl);
                if (resultBlob) {
                    outputMessage("✓ Texto sobreposto na imagem com sucesso!");
                    callback(resultBlob);
                } else {
                    outputMessage("⚠️ Falha ao converter canvas. Usando imagem original.");
                    callback(blob);
                }
            }, 'image/jpeg', 0.92);
            
        } catch(e) {
            URL.revokeObjectURL(objectUrl);
            outputMessage("⚠️ Erro ao desenhar texto na imagem: " + e.message);
            callback(blob);
        }
    };
    
    img.onerror = function() {
        URL.revokeObjectURL(objectUrl);
        outputMessage("⚠️ Erro ao carregar imagem para overlay. Usando original.");
        callback(blob);
    };
    
    img.src = objectUrl;
}

function vpDetectUsernameFromNav() {
    // Fallback síncrono: link do próprio perfil na barra lateral (ex: /celso_natupesca/)
    try {
        var deny = { explore: 1, reels: 1, direct: 1, accounts: 1, create: 1, stories: 1, p: 1, tv: 1, about: 1, emojis: 1, developer: 1 };
        var found = '';
        document.querySelectorAll('nav a[href], header a[href]').forEach(function (a) {
            try {
                var h = (a.getAttribute('href') || '').split('?')[0];
                var m = h.match(/^\/([A-Za-z0-9._]{2,30})\/$/);
                if (m && !deny[m[1].toLowerCase()]) found = m[1];
            } catch (e) {}
        });
        if (found) {
            window.__vp_current_ig_username = found;
            return found;
        }
    } catch (e) {}
    return '';
}

function vpCurrentPostInstagram() {
    try {
        if (window.__vp_current_ig_username) return window.__vp_current_ig_username;
        if (typeof user !== 'undefined' && user && user.viewer && user.viewer.username) return user.viewer.username;
        var navUser = vpDetectUsernameFromNav();
        if (navUser) return navUser;
    } catch (e) {}
    return '';
}

function vpRestoreIdentityFromCache(cb) {
    // Fallback assíncrono: último @ com licença verificada (chrome.storage)
    try {
        if (vpCurrentPostInstagram()) { cb(); return; }
        chrome.storage.local.get('vp_license', function (data) {
            try {
                if (data && data.vp_license) {
                    var lic = JSON.parse(data.vp_license);
                    if (lic && lic.instagram) {
                        window.__vp_current_ig_username = lic.instagram;
                        outputMessage('  → @ recuperado do cache: ' + lic.instagram);
                    }
                }
            } catch (e) {}
            cb();
        });
    } catch (e) { cb(); }
}

function vpRefreshQueueStatus() {
    chrome.runtime.sendMessage({ postQueueStatus: vpCurrentPostInstagram() }, function (resp) {
        if (resp && resp.success) {
            var names = (resp.items || []).map(function (it) { return (it && it.name ? it.name + (it.kind === 'reel' ? '(reels)' : '') : it); });
            $('#vp_queue_pending').text(resp.pending + ' na fila' + (names.length ? ': ' + names.slice(0, 8).join(', ') + (names.length > 8 ? '...' : '') : ''));
            outputMessage('Fila de posts: ' + resp.pending + ' pendente(s).');
        } else {
            $('#vp_queue_pending').text('erro');
            outputMessage('❌ Erro ao ver fila: ' + ((resp && resp.error) || 'falha'));
        }
    });
}

function vpDiagnosePostador() {
    try {
        outputMessage('🩺 Diagnóstico (sem postar) — build fix12');
        outputMessage('  → página: ' + window.location.pathname + ' | usuário: ' + (vpCurrentPostInstagram() || '(não detectado)'));
        var nCreateLinks = 0, nNav = 0, nDialogs = 0, nInputs = 0, nIgInputs = 0;
        try { nCreateLinks = document.querySelectorAll('a[href^="/create"]').length; } catch (e) {}
        try { nNav = document.querySelectorAll('nav a, nav div[role="button"], nav button').length; } catch (e) {}
        try { nDialogs = document.querySelectorAll('div[role="dialog"]').length; } catch (e) {}
        try { nInputs = document.querySelectorAll('input[type="file"]').length; } catch (e) {}
        try { nIgInputs = vpListInstagramFileInputs().length; } catch (e) {}
        outputMessage('  → links /create: ' + nCreateLinks + ' | itens nav: ' + nNav + ' | dialogs: ' + nDialogs + ' | fileInputs: ' + nInputs + ' (IG: ' + nIgInputs + ')');
        try {
            var svgLabels = [];
            document.querySelectorAll('svg[aria-label]').forEach(function (s) {
                var l = (s.getAttribute('aria-label') || '').trim();
                if (l && svgLabels.indexOf(l) < 0) svgLabels.push(l);
            });
            outputMessage('  → svg aria-labels: ' + (svgLabels.slice(0, 10).join(' | ') || 'nenhum'));
        } catch (e) {}
        var btn = null;
        try { btn = findCreateButton(); } catch (e) {}
        if (btn) {
            try {
                var rb = btn.getBoundingClientRect ? btn.getBoundingClientRect() : { width: 0, height: 0 };
                outputMessage('  → botão + detectado: ' + (btn.tagName || '?') + ' rect=' + Math.round(rb.width) + 'x' + Math.round(rb.height) + ' visivel=' + ($(btn).is(':visible')));
            } catch (e) { outputMessage('  → botão + detectado (sem medidas).'); }
        } else {
            outputMessage('  → botão + NÃO detectado. Abra o + manual e tente de novo.');
        }
        try {
            var shareBtn = findInstaButton(['share', 'compartilhar', 'publicar', 'postar', 'concluir']);
            var shareOk = shareBtn && shareBtn.length && isValidShareButton(shareBtn);
            outputMessage('  → botão Compartilhar/Concluir: ' + (shareOk ? ('visível (' + (shareBtn.text().trim().slice(0, 30) || shareBtn.attr('aria-label') || '?') + ')') : 'não visível agora (normal fora da tela final; ignora botão da extensão)'));
        } catch (e) {}
        chrome.runtime.sendMessage({ postQueueStatus: vpCurrentPostInstagram() }, function (resp) {
            if (resp && resp.success) {
                var names = (resp.items || []).map(function (it) { return (it && it.name ? it.name + (it.kind === 'reel' ? '(reels)' : '') : it); });
                outputMessage('  → fila: ' + resp.pending + ' pendente(s)' + (names.length ? ': ' + names.slice(0, 8).join(', ') : '') + ' | @: ' + (vpCurrentPostInstagram() || '(vazio = pasta base)'));
            } else {
                outputMessage('  → fila: erro (' + ((resp && (resp.message || resp.error)) || 'falha') + ')');
            }
            outputMessage('✅ Diagnóstico concluído. Copie o Registro e me envie.');
        });
    } catch (e) {
        try { outputMessage('❌ Falha no diagnóstico: ' + e.message); } catch (e2) {}
    }
}

function vpReadFileAsBase64(file) {
    return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.onload = function () {
            var res = String(reader.result || '');
            var idx = res.indexOf('base64,');
            resolve(idx > -1 ? res.substring(idx + 7) : res);
        };
        reader.onerror = function () { reject(new Error('leitura')); };
        reader.readAsDataURL(file);
    });
}

async function vpUploadFolderToQueue() {
    if (window.__vp_uploading) {
        outputMessage('⏳ Upload já em andamento, aguarde terminar.');
        return false;
    }
    if (window.__vp_posting_in_progress) {
        outputMessage('⏳ Aguarde: postagem em andamento. Envie a pasta depois que terminar.');
        return false;
    }
    window.__vp_uploading = true;
    var input = document.getElementById('vp_folder_picker');
    if (!input || !input.files || input.files.length === 0) {
        outputMessage('Selecione a pasta do PC primeiro.');
        window.__vp_uploading = false;
        return false;
    }
    outputMessage('📤 Lendo ' + input.files.length + ' arquivo(s) da pasta...');
    $('#vp_queue_pending').text('enviando...');

    var groups = {};
    function vpNumKey(nm) {
        var m = String(nm).match(/^(.*?)(\d+)$/);
        return m ? '#' + parseInt(m[2], 10) : 'n:' + String(nm).toLowerCase();
    }
    var files = Array.prototype.slice.call(input.files);
    for (var i = 0; i < files.length; i++) {
        (function (f) {
            var parts = f.name.split('.');
            var ext = parts.length > 1 ? parts.pop().toLowerCase() : '';
            var base = parts.join('.');
            if (!/^[A-Za-z0-9_-]+$/.test(base)) return;
            var isImg = ['jpg', 'jpeg', 'png', 'webp'].indexOf(ext) > -1;
            var isVid = ['mp4', 'mov', 'webm'].indexOf(ext) > -1;
            var isTxt = ext === 'txt';
            if (!isImg && !isVid && !isTxt) return;
            var k = vpNumKey(base);
            if (!groups[k]) groups[k] = {};
            if (isImg && !groups[k].image) groups[k].image = { file: f, name: f.name };
            else if (isVid && !groups[k].video) groups[k].video = { file: f, name: f.name };
            else if (isTxt && !groups[k].txt) groups[k].txt = { file: f, name: f.name };
        })(files[i]);
    }

    // Envia grupo a grupo (lê, envia, libera): nunca acumula vídeos na memória
    var gkeys = Object.keys(groups).slice(0, 200);
    var validGroups = gkeys.filter(function (k) {
        var e = groups[k];
        return (e.image || e.video) && e.txt;
    });

    if (validGroups.length === 0) {
        outputMessage('Nenhum par válido (ex: imagem1 + video1 + txt1).');
        $('#vp_queue_pending').text('');
        window.__vp_uploading = false;
        return false;
    }

    outputMessage('📤 Enviando ' + validGroups.length + ' grupo(s) para o servidor (1 por vez)...');
    var allSaved = [];
    var allSkipped = [];
    var failedGroups = 0;
    for (var gi = 0; gi < validGroups.length; gi++) {
        var entry = groups[validGroups[gi]];
        var chunk = [];
        try {
            if (entry.image) {
                var b64 = await vpReadFileAsBase64(entry.image.file);
                chunk.push({ name: entry.image.name, kind: 'media', mime: entry.image.file.type || 'image/jpeg', data: b64 });
                b64 = null;
            }
            if (entry.video) {
                var vb64 = await vpReadFileAsBase64(entry.video.file);
                chunk.push({ name: entry.video.name, kind: 'media', mime: entry.video.file.type || 'video/mp4', data: vb64 });
                vb64 = null;
            }
            var legenda = await new Promise(function (resolve) {
                var r = new FileReader();
                r.onload = function () { resolve(String(r.result || '')); };
                r.onerror = function () { resolve(''); };
                r.readAsText(entry.txt.file);
            });
            chunk.push({ name: entry.txt.name, kind: 'text', mime: 'text/plain', data: btoa(unescape(encodeURIComponent(legenda))) });
            legenda = null;
        } catch (e) {
            outputMessage('⚠️ Grupo ' + (gi + 1) + ' falhou na leitura — pulando...');
            failedGroups++;
            continue;
        }
        outputMessage('📤 Grupo ' + (gi + 1) + '/' + validGroups.length + ' (' + chunk.map(function (f) { return f.name; }).join('+') + ')...');
        var resp = await new Promise(function (resolve) {
            try {
                chrome.runtime.sendMessage({
                    postQueueUpload: { instagram: vpCurrentPostInstagram(), files: chunk }
                }, function (r) { resolve(r); });
            } catch (e) { resolve(null); }
        });
        try { chunk.forEach(function (f) { f.data = null; }); chunk = []; } catch (e) {}
        if (resp && resp.success) {
            allSaved = allSaved.concat(resp.saved || []);
            allSkipped = allSkipped.concat(resp.skipped || []);
        } else {
            failedGroups++;
            outputMessage('⚠️ Grupo ' + (gi + 1) + ' falhou (' + ((resp && (resp.message || resp.error)) || 'falha') + ') — continuando...');
        }
    }
    if (failedGroups === 0) {
        outputMessage('✅ Fila atualizada: ' + allSaved.length + ' salvo(s).' + (allSkipped.length ? ' Ignorados: ' + allSkipped.join(', ') : ''));
        outputMessage('💡 Upload concluído. Agora clique em Postar Agora (não clique durante o envio).');
        window.__vp_uploading = false;
        vpRefreshQueueStatus();
    } else if (allSaved.length > 0) {
        outputMessage('⚠️ Fila parcial: ' + allSaved.length + ' salvo(s), ' + failedGroups + ' grupo(s) falharam. Tente de novo só com os que faltam.');
        window.__vp_uploading = false;
        vpRefreshQueueStatus();
    } else {
        outputMessage('❌ Erro no upload: nenhuma parte coube na mensagem. Feche abas e tente de novo.');
        $('#vp_queue_pending').text('erro');
        window.__vp_uploading = false;
    }
}

function vpWaitLeaveCreateThen(fn) {
    var tries = 0;
    var iv = setInterval(function () {
        tries++;
        var p = window.location.pathname || '';
        if (p.indexOf('/create') === -1) {
            clearInterval(iv);
            try { fn(); } catch (e) {}
            return;
        }
        if (tries >= 30) {
            clearInterval(iv);
            outputMessage('⏳ Tela de criação presa, voltando ao feed para continuar...');
            try { chrome.storage.local.set({ vp_resume_folder_post: 1 }); } catch (e) {}
            window.location.href = 'https://www.instagram.com/';
        }
    }, 500);
}

function vpAutoChainReelSibling(doneName) {
    try {
    var reelsOnlyMode = false;
    try { reelsOnlyMode = !!document.getElementById('vp_reels_only').checked; } catch (e) {}
    window.__vp_reels_only = reelsOnlyMode;
    outputMessage('Filtro da vez: ' + (reelsOnlyMode ? 'somente reels' : 'foto + reels'));
    chrome.runtime.sendMessage({ postQueueNext: true, postQueueInstagram: vpCurrentPostInstagram(), postQueueKind: reelsOnlyMode ? 'reel' : '' }, function (response) {
            try {
                if (!response || !response.success || response.empty || !response.item) return;
                if (response.item.kind !== 'reel') return;
                var a = String(doneName || '').match(/(\d+)/);
                var b = String(response.item.name || '').match(/(\d+)/);
                if (!a || !b || a[1] !== b[1]) return;
                outputMessage('🎬 Reels irmão (' + response.item.name + ') na sequência, postando automaticamente...');
                outputMessage('⏳ Aguardando sair da tela de criação...');
                chrome.storage.local.set({ 'vp_ai_posting_lock': Date.now() });
                window.__vp_posting_in_progress = true;
                vpWaitLeaveCreateThen(function () { vpPostFromFolderQueue(true); });
            } catch (e) {}
        });
    } catch (e) {}
}

function vpPostFromFolderQueue(force) {
    if (!force && !gblAiSettings) {
        outputMessage("⚠️ Configurações não carregadas. Abortando postagem.");
        chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
        window.__vp_posting_in_progress = false;
        return;
    }

    suppressConsoleErrors();

    var reelsOnlyNow = false;
    try { reelsOnlyNow = !!document.getElementById('vp_reels_only').checked || !!window.__vp_reels_only; } catch (e) {}
    // Após recarregar, o @ pode demorar p/ detectar: tenta nav + cache e aguarda até 10s (evita "pasta vazia" falsa)
    try { vpRestoreIdentityFromCache(function () {}); } catch (e) {}
    var waitUser = 0;
    var userTimer = setInterval(function () {
        waitUser++;
        if (vpCurrentPostInstagram() || waitUser >= 20) {
            clearInterval(userTimer);
            if (!vpCurrentPostInstagram()) {
                vpRestoreIdentityFromCache(function () {
                    if (!vpCurrentPostInstagram()) outputMessage('⚠️ @ não detectado (deslogado?) — usando fila base.');
                    vpFetchNextPost(reelsOnlyNow);
                });
            } else {
                vpFetchNextPost(reelsOnlyNow);
            }
        }
    }, 500);
    return;
}

function vpFetchNextPost(reelsOnlyNow) {
    outputMessage("📁 Buscando próximo post da pasta do servidor..." + (reelsOnlyNow ? ' (somente reels)' : ''));
    try { $('#vp_ai_status').text('Buscando ' + (reelsOnlyNow ? 'reels' : 'foto') + ' na pasta...').css('color', '#ecc94b'); } catch (e) {}

    chrome.runtime.sendMessage({ postQueueNext: true, postQueueInstagram: vpCurrentPostInstagram(), postQueueKind: reelsOnlyNow ? 'reel' : '' }, function (response) {
        if (chrome.runtime.lastError || !response || !response.success) {
            outputMessage("❌ Erro ao buscar fila de posts: " + ((response && response.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'falha'));
            $('#vp_ai_status').text('Erro fila de posts').css('color', '#e53e3e');
            chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
            window.__vp_posting_in_progress = false;
            restoreConsoleErrors();
            return;
        }

        if (response.empty) {
            outputMessage("📭 Pasta de posts vazia (@'" + (vpCurrentPostInstagram() || '?') + "'). Coloque videoN.mp4 + videoN.txt na fila.");
            $('#vp_ai_status').text('Pasta vazia').css('color', '#ecc94b');
            chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
            window.__vp_posting_in_progress = false;
            restoreConsoleErrors();
            return;
        }

        var item = response.item;
        var legenda = item.legenda || '';
        var mime = item.mediaMimeType || item.imageMimeType || 'image/jpeg';
        window.__vp_current_queue_item = item.key || item.name;
        window.__vp_current_queue_kind = item.kind || 'photo';
        outputMessage("✓ Foto da vez: " + item.name + " (" + (response.pending || '?') + " na fila)");

        try {
            var rawB64 = String(item.mediaBase64 || item.imageBase64 || '').replace(/\s/g, '');
            if (!rawB64) throw new Error('imagem vazia');
            var binary = atob(rawB64);
            var len = binary.length;
            var bytes = new Uint8Array(len);
            for (var i = 0; i < len; i++) {
                bytes[i] = binary.charCodeAt(i);
            }
            var blob = new Blob([bytes], { type: mime });
            var isVideo = mime.indexOf('video/') === 0;
            var ext = isVideo ? (mime.indexOf('quicktime') > -1 ? 'mov' : 'mp4') : (mime.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
            window.__vp_upload_is_video = isVideo;
            if (isVideo) {
                var vfile = new File([blob], item.name + "." + ext, { type: mime });
                outputMessage("✓ Vídeo da vez: " + item.name + " (" + (response.pending || '?') + " na fila)");
                // Libera memória do base64 (vídeo 10MB+: evita out-of-memory na aba)
                try { rawB64 = null; binary = null; bytes = null; blob = null; response.item.mediaBase64 = null; } catch (e) {}
                executeInstagramDomUpload(vfile, legenda);
                return;
            }
            window.__vp_upload_is_video = false;
            // Valida tamanho mínimo do Instagram (320px) antes de subir
            var imgUrl = URL.createObjectURL(blob);
            var dimImg = new Image();
            dimImg.onload = function () {
                URL.revokeObjectURL(imgUrl);
                var w = dimImg.naturalWidth || 0, h = dimImg.naturalHeight || 0;
                if (w > 0 && h > 0 && (w < 320 || h < 320)) {
                    outputMessage("❌ " + item.name + " muito pequena (" + w + "x" + h + "). Mínimo 320px. Arquivo MANTIDO na fila.");
                    $('#vp_ai_status').text('Imagem muito pequena').css('color', '#e53e3e');
                    chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                    window.__vp_posting_in_progress = false;
                    restoreConsoleErrors();
                    return;
                }
                var file = new File([blob], item.name + "." + ext, { type: mime });
                // Sem overlay/texto gerado: legenda vem do fotoN.txt
                executeInstagramDomUpload(file, legenda);
            };
            dimImg.onerror = function () {
                URL.revokeObjectURL(imgUrl);
                var file = new File([blob], item.name + "." + ext, { type: mime });
                executeInstagramDomUpload(file, legenda);
            };
            dimImg.src = imgUrl;
        } catch (e) {
            outputMessage("❌ Erro ao preparar imagem da pasta: " + e.message);
            $('#vp_ai_status').text('Erro imagem da pasta').css('color', '#e53e3e');
            window.__vp_current_queue_item = null;
            chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
            window.__vp_posting_in_progress = false;
            restoreConsoleErrors();
        }
    });
}

function simulateInstagramPost(force) {
    // GUARD: Impedir re-entrada se já está postando (auto-destrava após 10min preso)
    if (window.__vp_posting_in_progress) {
        var stuckMs = Date.now() - (window.__vp_post_start || 0);
        if (window.__vp_post_start && stuckMs < 10 * 60 * 1000) {
            console.log("[VP] Postagem já em andamento. Ignorando chamada duplicada.");
            outputMessage('⏳ Postagem anterior ainda em andamento. Aguarde ou recarregue a página.');
            return;
        }
        outputMessage('⚠️ Trava anterior liberada (estava presa há ' + Math.round(stuckMs / 60000) + 'min). Reiniciando...');
        window.__vp_posting_in_progress = false;
        try { chrome.storage.local.set({ 'vp_ai_posting_lock': 0 }); } catch (e) {}
    }

    // Marcar se é postagem manual (force=true) ou automática (force=false)
    window.__vp_is_force_post = !!force;
    window.__vp_posting_in_progress = true; // LOCK global
    window.__vp_post_start = Date.now();
    
    if (!vpLicenseGuard()) {
        window.__vp_posting_in_progress = false;
        return;
    }

    // MODO PASTA: foto+legenda vêm do servidor em vez da IA
    if (window.__vp_post_mode === 'folder') {
        vpPostFromFolderQueue(force);
        return;
    }
    
    // Ativar supressão de erros durante toda a automação
    suppressConsoleErrors();
    
    if (!force && !gblAiSettings) {
        outputMessage("⚠️ Configurações de IA não carregadas. Abortando postagem.");
        window.__vp_posting_in_progress = false;
        return;
    }
    
    outputMessage("🤖 Iniciando automação de postagem por IA...");
    $('#vp_ai_status').text('Gerando conteúdo...').css('color', '#ecc94b');
    
    var nicheMode = gblAiSettings ? gblAiSettings.niche_mode : 'manual';
    var niche = gblAiSettings ? gblAiSettings.niche_product : '';
    var instructions = gblAiSettings ? gblAiSettings.instructions : '';
    
    chrome.runtime.sendMessage({
        generateAiContent: {
            niche_mode: nicheMode,
            niche: niche,
            instructions: instructions
        }
    }, function(response) {
        if (chrome.runtime.lastError || !response || !response.success || !response.content) {
            console.error("Erro ao gerar conteúdo:", chrome.runtime.lastError || response);
            outputMessage("❌ Erro ao gerar conteúdo de post da IA.");
            $('#vp_ai_status').text('Erro ao gerar post').css('color', '#e53e3e');
            chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
            window.__vp_posting_in_progress = false;
            restoreConsoleErrors();
            return;
        }
        
        var content = response.content;
        var legenda = content.legenda;
        var imageUrl = content.imageUrl;
        var imageBase64 = content.imageBase64;
        var imageMimeType = content.imageMimeType || 'image/jpeg';
        var textOverlay = content.textOverlay || '';
        var ext = imageMimeType.split('/')[1] || 'jpg';
        
        outputMessage("✓ Conteúdo gerado com sucesso.");
        if (textOverlay) {
            outputMessage("📝 Texto para sobrepor: \"" + textOverlay + "\"");
        }
        
        // Salvar localmente a legenda para teste/verificação
        try {
            var txtBlob = new Blob([legenda], { type: 'text/plain;charset=utf-8' });
            var txtUrl = URL.createObjectURL(txtBlob);
            var aTxt = document.createElement('a');
            aTxt.href = txtUrl;
            aTxt.download = 'visionplus_legenda_' + Date.now() + '.txt';
            document.body.appendChild(aTxt);
            aTxt.click();
            document.body.removeChild(aTxt);
            URL.revokeObjectURL(txtUrl);
        } catch(e) {}
        
        // Função auxiliar: aplica overlay e faz upload
        function processAndUpload(blob) {
            drawTextOverlayOnImage(blob, textOverlay, function(finalBlob) {
                // Salvar localmente a imagem final para teste/verificação
                try {
                    var imgUrl = URL.createObjectURL(finalBlob);
                    var aImg = document.createElement('a');
                    aImg.href = imgUrl;
                    aImg.download = 'visionplus_imagem_' + Date.now() + '.jpg';
                    document.body.appendChild(aImg);
                    aImg.click();
                    document.body.removeChild(aImg);
                    URL.revokeObjectURL(imgUrl);
                } catch(e) {}
                
                var file = new File([finalBlob], "ai_post_" + Date.now() + ".jpg", { type: 'image/jpeg' });
                executeInstagramDomUpload(file, legenda);
            });
        }
        
        if (imageBase64) {
            outputMessage("✓ Imagem obtida com sucesso via API.");
            try {
                var binary = atob(imageBase64);
                var len = binary.length;
                var bytes = new Uint8Array(len);
                for (var i = 0; i < len; i++) {
                    bytes[i] = binary.charCodeAt(i);
                }
                var blob = new Blob([bytes], { type: imageMimeType });
                
                processAndUpload(blob);
                return;
            } catch (e) {
                outputMessage("⚠️ Erro ao decodificar imagem Base64. Tentando download direto...");
            }
        }
        
        $('#vp_ai_status').text('Baixando imagem...').css('color', '#ecc94b');
        
        // Fallback: Baixar a imagem como blob diretamente do cliente (sujeito a CORS)
        fetch(imageUrl)
            .then(function(res) { return res.blob(); })
            .then(function(blob) {
                processAndUpload(blob);
            })
            .catch(function(err) {
                console.error("Erro ao baixar imagem:", err);
                outputMessage("❌ Erro ao baixar imagem gerada.");
                $('#vp_ai_status').text('Erro download imagem').css('color', '#e53e3e');
                chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                window.__vp_posting_in_progress = false;
                restoreConsoleErrors();
            });
    });
}

function triggerReactChange(node) {
    if (!node) return false;
    
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
        if (keys[i].startsWith('__reactProps$')) {
            var props = node[keys[i]];
            if (props && typeof props.onChange === 'function') {
                try {
                    // Passamos um mock completo do target com os arquivos para o React ler de forma limpa
                    props.onChange({
                        target: { files: node.files, value: node.value },
                        currentTarget: { files: node.files, value: node.value },
                        preventDefault: function(){},
                        stopPropagation: function(){},
                        nativeEvent: new Event('change'),
                        type: 'change',
                        bubbles: true,
                        isTrusted: true
                    });
                    return true;
                } catch(e) {
                    // Silencioso - não logar para não deixar rastro
                }
            }
        }
        
        if (keys[i].startsWith('__reactFiber$') || keys[i].startsWith('__reactInternalInstance$')) {
            var fiber = node[keys[i]];
            var depth = 0;
            while (fiber && depth < 15) {
                if (fiber.memoizedProps && typeof fiber.memoizedProps.onChange === 'function') {
                    try {
                        fiber.memoizedProps.onChange({
                            target: { files: node.files, value: node.value },
                            currentTarget: { files: node.files, value: node.value },
                            preventDefault: function(){},
                            stopPropagation: function(){},
                            nativeEvent: new Event('change'),
                            type: 'change',
                            bubbles: true,
                            isTrusted: true
                        });
                        return true;
                    } catch(e) {
                        // Silencioso
                    }
                }
                fiber = fiber.return;
                depth++;
            }
        }
    }
    return false;
}

function triggerReactClick(node) {
    if (!node) return false;
    
    var keys = Object.keys(node);
    for (var i = 0; i < keys.length; i++) {
        if (keys[i].startsWith('__reactProps$')) {
            var props = node[keys[i]];
            if (props && typeof props.onClick === 'function') {
                try {
                    props.onClick({ 
                        preventDefault: function(){}, 
                        stopPropagation: function(){}, 
                        nativeEvent: new MouseEvent('click'), 
                        target: node, 
                        currentTarget: node,
                        type: 'click',
                        bubbles: true,
                        isTrusted: true
                    });
                    return true;
                } catch(e) {
                    // Silencioso
                }
            }
        }
        
        if (keys[i].startsWith('__reactFiber$') || keys[i].startsWith('__reactInternalInstance$')) {
            var fiber = node[keys[i]];
            var depth = 0;
            while (fiber && depth < 15) {
                if (fiber.memoizedProps && typeof fiber.memoizedProps.onClick === 'function') {
                    try {
                        fiber.memoizedProps.onClick({ 
                            preventDefault: function(){}, 
                            stopPropagation: function(){}, 
                            nativeEvent: new MouseEvent('click'), 
                            target: node, 
                            currentTarget: node,
                            type: 'click',
                            bubbles: true,
                            isTrusted: true
                        });
                        return true;
                    } catch(e) {
                        // Silencioso
                    }
                }
                fiber = fiber.return;
                depth++;
            }
        }
    }
    return false;
}

function simulateClick(node) {
    if (!node) return;

    try { node.scrollIntoView({ block: 'center' }); } catch (e) {}

    // 0. Se for container grande (A 48x56), prefere o filho clicável central (DIV 24x24 / svg)
    var clickTargets = [node];
    try {
        var rc0 = node.getBoundingClientRect();
        if (rc0 && rc0.width >= 40) {
            var cx0 = rc0.left + rc0.width / 2, cy0 = rc0.top + rc0.height / 2;
            var inner = document.elementFromPoint(cx0, cy0);
            if (inner && inner !== node && node.contains(inner)) {
                clickTargets.push(inner);
                var innerBtn = null;
                try { innerBtn = inner.closest('div[role="button"], button, a'); } catch (e) {}
                if (innerBtn && innerBtn !== node && clickTargets.indexOf(innerBtn) < 0) clickTargets.push(innerBtn);
            }
            // também tenta o svg interno
            var svgIn = node.querySelector ? node.querySelector('svg') : null;
            if (svgIn && clickTargets.indexOf(svgIn) < 0) clickTargets.push(svgIn);
        }
    } catch (e) {}

    for (var ti = 0; ti < clickTargets.length; ti++) {
        (function (target) {
            if (!target) return;
            // 1. Tenta acionar o React handler diretamente
            try { triggerReactClick(target); } catch (e) {}
            // 2. Eventos com coordenadas do centro (React 17+ / Instagram exigem clientX/Y)
            var cx = 0, cy = 0;
            try {
                var rc = target.getBoundingClientRect();
                cx = rc.left + rc.width / 2; cy = rc.top + rc.height / 2;
            } catch (e) {}
            // Eventos com fidelidade máxima (detail:1 = clique real tem detail 1; sintético sem isso é ignorado)
            var evOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, screenX: cx, screenY: cy, button: 0, detail: 1 };
            var ptrOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, screenX: cx, screenY: cy, button: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true, width: 1, height: 1, detail: 1 };
            try { target.dispatchEvent(new PointerEvent('pointerover', ptrOpts)); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('mouseover', evOpts)); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('mouseenter', evOpts)); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('mousemove', evOpts)); } catch (e) {}
            try { target.dispatchEvent(new PointerEvent('pointerdown', Object.assign({ buttons: 1 }, ptrOpts))); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('mousedown', Object.assign({ buttons: 1 }, evOpts))); } catch (e) {}
            try { target.dispatchEvent(new PointerEvent('pointerup', ptrOpts)); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('mouseup', evOpts)); } catch (e) {}
            try { target.dispatchEvent(new MouseEvent('click', evOpts)); } catch (e) {}
        })(clickTargets[ti]);
    }

    // 3. Clique nativo padrão (evento trusted de verdade)
    try { node.focus(); } catch (e) {}
    try { node.click(); } catch(e) {}

    // 3b. Enter por teclado como fallback
    try {
        node.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
        node.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 }));
    } catch (e) {}

    // 4. Tenta nos pais (até 3 níveis)
    var parent = node.parentElement;
    var level = 0;
    while (parent && level < 3) {
        try { triggerReactClick(parent); } catch (e) {}
        try { parent.click(); } catch(e) {}
        parent = parent.parentElement;
        level++;
    }
}

function findCreateButton() {
    // 1. Rota /create/select/ é inequívoca (criação). Só /create/ puro pode colidir com @create.
    try {
        var selLink = document.querySelector('a[href="/create/select/"], a[href="/create/select"], a[href^="/create/select/"]');
        if (selLink && $(selLink).is(':visible')) return selLink;
        var createLinks = document.querySelectorAll('a[href="/create/select/"], a[href="/create/select"]');
        for (var i = 0; i < createLinks.length; i++) {
            return createLinks[i];
        }
    } catch (e) {}
    
    // 2. Procura por aria-label (prefere o <a> clicável externo, não o DIV interno do ícone)
    var allElements = document.querySelectorAll('a, button, div, span, [aria-label], [title], [role="button"], [tabindex]');
    var createLabels = ['new post', 'novo post', 'nova publicação', 'nova publicacao', 'create', 'criar'];

    for (var j = 0; j < allElements.length; j++) {
        var el = allElements[j];
        var ariaLabel = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '')).toLowerCase();
        for (var k = 0; k < createLabels.length; k++) {
            if (ariaLabel.indexOf(createLabels[k]) > -1) {
                try {
                    var outer = el.closest ? (el.closest('a') || el.closest('button') || el.closest('div[role="button"]')) : null;
                    if (outer && $(outer).is(':visible')) return outer;
                    return el.closest('a, button, [role="button"], [tabindex], div') || el;
                } catch (e) { return el; }
            }
        }
    }
    
    // 3. Procura SVG com aria-label (prefere o <a> externo clicável)
    var svgs = document.querySelectorAll('svg');
    for (var s = 0; s < svgs.length; s++) {
        var svgLabel = ((svgs[s].getAttribute('aria-label') || '') + ' ' + (svgs[s].getAttribute('title') || '') + ' ' + (svgs[s].querySelector('title') ? svgs[s].querySelector('title').textContent : '')).toLowerCase();
        for (var m = 0; m < createLabels.length; m++) {
            if (svgLabel.indexOf(createLabels[m]) > -1) {
                try {
                    var outerA = svgs[s].closest ? (svgs[s].closest('a') || svgs[s].closest('button') || svgs[s].closest('div[role="button"]')) : null;
                    if (outerA && $(outerA).is(':visible')) return outerA;
                } catch (e) {}
                var closest = svgs[s].closest('a, div[role="button"], button, [tabindex], div');
                return closest || svgs[s].parentElement || svgs[s];
            }
        }
    }
    
    // 4. Procura por texto exato SOMENTE dentro de nav/header (evita perfil @create no feed)
    try {
        var navScopes = document.querySelectorAll('nav, header, div[role="navigation"]');
        for (var ni = 0; ni < navScopes.length; ni++) {
            var textNodes = navScopes[ni].querySelectorAll('span, a, div, button');
            for (var t = 0; t < textNodes.length; t++) {
                var txt = (textNodes[t].textContent || '').trim().toLowerCase();
                if (txt === 'create' || txt === 'criar') {
                    try { return textNodes[t].closest('a, button, div[role="button"]') || textNodes[t]; } catch (e) { return textNodes[t]; }
                }
            }
        }
    } catch (e) {}

    return null;
}

function vpListInstagramFileInputs() {
    var list = [];
    try {
        $('div[role="dialog"] input[type="file"]').each(function () { list.push(this); });
        $('input[type="file"]').each(function () {
            var el = this;
            if (list.indexOf(el) > -1) return;
            if (el.id === 'vp_folder_picker') return;
            try {
                if (el.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, .igBotParent, #vp_ai_main_panel')) return;
            } catch (e) {}
            list.push(el);
        });
    } catch (e) {}
    return list;
}

function vpFindInstagramFileInput() {
    var list = vpListInstagramFileInputs();
    return list.length > 0 ? list[0] : null;
}

function vpFindComposerDialog() {
    var found = null;
    try {
        $('div[role="dialog"]').each(function () {
            var t = ($(this).text() || '').toLowerCase();
            if (t.indexOf('select from computer') > -1 || t.indexOf('selecionar') > -1 ||
                t.indexOf('drag photos') > -1 || t.indexOf('arraste') > -1 ||
                t.indexOf('create new post') > -1 || t.indexOf('nova public') > -1) {
                found = $(this);
                return false;
            }
        });
    } catch (e) {}
    return found;
}

function vpCollectCreateCandidates() {
    var list = [];
    function add(el) {
        if (!el || list.indexOf(el) > -1) return;
        try { if (!$(el).is(':visible')) return; } catch (e) {}
        list.push(el);
    }
    try {
        document.querySelectorAll('a[href^="/create/select"]').forEach(function (a) { add(a); });
        document.querySelectorAll('svg[aria-label]').forEach(function (svg) {
            var lbl = (svg.getAttribute('aria-label') || '').toLowerCase();
            if (lbl.indexOf('novo post') > -1 || lbl.indexOf('new post') > -1 || lbl.indexOf('nova public') > -1 || lbl.indexOf('criar') > -1 || lbl.indexOf('creat') > -1) {
                var o = null;
                try { o = svg.closest('a') || svg.closest('button') || svg.closest('div[role="button"]'); } catch (e) {}
                add(o);
                add(svg.closest ? svg.closest('div') : null);
            }
        });
    } catch (e) {}
    return list.slice(0, 3);
}

function vpClickAllCreateCandidates(tag) {
    var cands = vpCollectCreateCandidates();
    outputMessage('  → candidatos +: ' + cands.length + ' (' + tag + ')');
    cands.forEach(function (c, i) {
        setTimeout(function () {
            try {
                var rc = c.getBoundingClientRect ? c.getBoundingClientRect() : { width: 0, height: 0 };
                outputMessage('  → clicando candidato ' + (i + 1) + ': ' + (c.tagName || '?') + ' ' + Math.round(rc.width) + 'x' + Math.round(rc.height));
            } catch (e) {}
            try { simulateClick(c); } catch (e) {}
        }, i * 900);
    });
    return cands.length;
}

function vpIsNavigatingLink(el) {
    // Opção de menu do composer NÃO pode ser link de navegação (senão sai do feed p/ /reels/, /p/...)
    try {
        var a = null;
        if (el && el.tagName === 'A') a = $(el);
        else if (el) { try { a = $(el).closest('a'); } catch (e) {} }
        if (a && a.length) {
            var href = (a.attr('href') || '').trim();
            if (!href || href.charAt(0) === '#' || href.indexOf('javascript') === 0) return false;
            if (/^\/reels(\/|$)/.test(href) || /^\/p\//.test(href) || /^https?:\/\//.test(href) || (href.charAt(0) === '/' && href.indexOf('/create') !== 0)) return true;
        }
    } catch (e) {}
    return false;
}

function vpFindCreateMenu() {
    // Localiza o SUBMENU do + (caixinha com Postar + Reels/Story) — nunca a barra lateral/feed
    // Conceitos distintos (reels|reel contam 1x); exige CRIAÇÃO; rejeita marcas da sidebar
    try {
        var concepts = [
            ['postar'], ['publicação', 'publicacao', 'publicar'],
            ['reels', 'reel'], ['story', 'stories'], ['vídeo', 'video'], ['ao vivo', 'live']
        ];
        var sidebarMarks = ['página inicial', 'mensagens', 'pesquisa', 'notificações', 'explorar'];
        var postActionMarks = ['curtir', 'comentar', 'repostar', 'salvar'];
        var best = null, bestScore = 0, bestLen = Infinity;
        $('div').each(function () {
            try {
                if (!$(this).is(':visible')) return;
                if ($(this).closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, #vp_ai_main_panel').length) return;
                var t = ($(this).text() || '').toLowerCase();
                if (t.length > 220 || t.length < 8) return;
                var marks = 0, m;
                for (m = 0; m < sidebarMarks.length; m++) { if (t.indexOf(sidebarMarks[m]) > -1) marks++; }
                if (marks >= 2) return; // é a barra lateral (ou contém ela) — nunca o submenu
                var pam = 0, q;
                for (q = 0; q < postActionMarks.length; q++) { if (t.indexOf(postActionMarks[q]) > -1) pam++; }
                if (pam >= 3) return; // é o menu de ações do post (curtir/comentar/...) — nunca o Criar
                var s = 0, i, j, hasCreate = false;
                for (i = 0; i < concepts.length; i++) {
                    for (j = 0; j < concepts[i].length; j++) {
                        if (t.indexOf(concepts[i][j]) > -1) {
                            s++;
                            if (i <= 1) hasCreate = true;
                            break;
                        }
                    }
                }
                if (s >= 2 && hasCreate) {
                    var nBtn = $(this).find('a, button, div[role="button"], [role="menuitem"]').length;
                    if (nBtn > 12 || nBtn === 0) return; // barra lateral tem itens demais; item solto não é menu
                    if (s > bestScore || (s === bestScore && t.length < bestLen)) { bestScore = s; bestLen = t.length; best = $(this); }
                }
            } catch (e) {}
        });
        return best;
    } catch (e) { return null; }
}

function vpClickPostMenuOption() {
    // Após clicar no +, clica a opção DENTRO do submenu — VÍDEO prefere Reels, FOTO prefere Publicação
    if (window.__vp_menu_clicked) return false;
    try {
        var isVideo = !!window.__vp_upload_is_video;
        var labels = isVideo
            ? ['reels', 'reel', 'vídeo', 'video', 'postar', 'publicação', 'publicacao', 'publicar', 'post']
            : ['publicação', 'publicacao', 'postar', 'post', 'publicar', 'reels', 'reel'];
        var menu = null;
        try { menu = vpFindCreateMenu(); } catch (e) {}
        if (menu && menu.length) {
            try {
                var opts = [];
                menu.find('a, button, div[role="button"], [role="menuitem"]').each(function () {
                    if (opts.length >= 8) return false;
                    var ot = ($(this).text() || '').trim().replace(/\s+/g, ' ');
                    if (ot && ot.length < 30 && opts.indexOf(ot) < 0 && $(this).is(':visible')) opts.push(ot);
                });
                outputMessage('  → opções do submenu Criar: ' + (opts.join(' | ') || 'ilegíveis'));
            } catch (e) {}
        }
        if (!menu || !menu.length) {
            return false; // submenu ainda não abriu: espera próximo tick (não clica aleatório)
        }
        function vpLabelMatch(t, w) {
            // 'repostar' NÃO pode casar 'postar': exige início ou após espaço (nunca meio/fim)
            if (w.length <= 4) {
                return t.split(/[^a-zà-ú0-9]+/).indexOf(w) > -1;
            }
            return t === w || t.indexOf(w) === 0 || t.indexOf(' ' + w) > -1;
        }
        var found = null;
        menu.find('[role="menuitem"], [role="button"], a, button, [role="option"]').each(function () {
            if (found) return false;
            var t = ($(this).text() || '').trim().toLowerCase();
            for (var i = 0; i < labels.length; i++) {
                if (t.length < 40 && vpLabelMatch(t, labels[i])) {
                    if (!$(this).is(':visible')) return;
                    if (vpIsNavigatingLink($(this)[0])) {
                        outputMessage("  → ignorando link de navegação ('" + t.slice(0, 20) + "').");
                        return;
                    }
                    found = $(this);
                    return false;
                }
            }
        });
        // Fallback SOMENTE dentro do submenu (jamais fora — evita abrir /reels/)
        if (!found) {
            menu.find('span, div, a, button').each(function () {
                if (found) return false;
                var t = ($(this).text() || '').trim().toLowerCase();
                var ok = labels.some(function (w) { return vpLabelMatch(t, w); });
                if (ok && $(this).children().length <= 2 && $(this).is(':visible')) {
                    var cand = $(this).closest('[role="menuitem"], a, button, div[role="button"]');
                    if (!cand || !cand.length) cand = $(this);
                    if (vpIsNavigatingLink(cand[0])) {
                        outputMessage("  → ignorando link de navegação ('" + t.slice(0, 20) + "').");
                        return;
                    }
                    found = cand;
                    return false;
                }
            });
        }
        if (found && found.length) {
            window.__vp_menu_clicked = true;
            var lbl = (found.text() || '').trim().slice(0, 30);
            outputMessage("✓ Opção '" + lbl + "' do menu Criar encontrada. Clicando...");
            simulateClick(found[0]);
            try {
                var r = found[0].getBoundingClientRect();
                var mx = Math.round(r.left + r.width / 2), my = Math.round(r.top + r.height / 2);
                setTimeout(function () {
                    try { chrome.runtime.sendMessage({ vpDebugClick: { x: mx, y: my } }, function () {}); } catch (e) {}
                }, 600);
            } catch (e) {}
            return true;
        }
    } catch (e) {}
    return false;
}

function vpHandleDiscardPopup() {
    // Popup "Descartar publicação?" — SEMPRE manter (Cancelar/Manter/Continuar), NUNCA Descartar
    try {
        var dlg = $('div[role="dialog"]');
        if (!dlg.length) return false;
        var acted = false;
        dlg.each(function () {
            if (acted) return false;
            var dt = (($(this).text() || '').toLowerCase());
            if (dt.indexOf('descart') > -1) {
                $(this).find('div[role="button"], button').each(function () {
                    if (acted) return false;
                    var bt = (($(this).text() || '').trim().toLowerCase());
                    if ((bt === 'cancelar' || bt === 'manter' || bt === 'continuar' || bt === 'voltar' || bt === 'cancel' || bt === 'keep' || bt === 'continue') && $(this).is(':visible')) {
                        outputMessage("✓ Popup 'Descartar' detectado: mantendo rascunho ('" + bt + "').");
                        simulateClick($(this)[0]);
                        acted = true;
                        return false;
                    }
                });
                if (!acted) outputMessage("⚠️ Popup 'Descartar' aberto sem botão Manter visível — clique em Cancelar manual.");
            }
        });
        return acted;
    } catch (e) { return false; }
}

function vpAbortFlow(reason) {
    // Interrompe tudo MANTENDO o arquivo na fila (nada é apagado sem sucesso confirmado)
    if (window.__vp_aborted) return;
    window.__vp_aborted = true;
    try { outputMessage('⛔ ' + reason + ' Arquivo MANTIDO na fila — verifique e tente de novo.'); } catch (e) {}
    try { $('#vp_ai_status').text('Interrompido (arquivo mantido)').css('color', '#e53e3e'); } catch (e) {}
    try { chrome.storage.local.set({ 'vp_ai_posting_lock': 0 }); } catch (e) {}
    window.__vp_posting_in_progress = false;
    window.__vp_caption_writing = false;
    try { window.__vp_pending_file = null; window.__vp_pending_legenda = null; } catch (e) {}
    try { restoreConsoleErrors(); } catch (e) {}
    try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch (e) {}
    try { $('#igBotInjectedContainer, #igBotContainer, .igBotContainer').show(); } catch (e) {}
}

function vpDismissInfoDialog(scope) {
    // Avisos tipo "vídeos serão publicados como reels" — botão OK/Entendi (nunca Compartilhar)
    // ERROS do Instagram (falhou, tente de novo...) NUNCA são dispensados: aborta mantendo o arquivo
    try {
        var done = false;
        var errPats = ['erro', 'falhou', 'falha', 'não foi possível', 'nao foi possivel', 'tente novamente', 'tente de novo', 'failed', 'error', 'couldn', 'unable', 'algo deu errado', 'something went wrong', 'bloque', 'block', 'limite', 'tente mais tarde'];
        scope.find('div[role="dialog"]').each(function () {
            if (done || window.__vp_aborted) return false;
            var dt = (($(this).text() || '').toLowerCase());
            for (var i = 0; i < errPats.length; i++) {
                if (dt.indexOf(errPats[i]) > -1) {
                    var snip = (($(this).text() || '').replace(/\s+/g, ' ').trim().substring(0, 160));
                    vpAbortFlow('Erro do Instagram: "' + snip + '".');
                    done = true;
                    return false;
                }
            }
        });
        if (done || window.__vp_aborted) return done;
        scope.find('div[role="button"], button').each(function () {
            if (done) return false;
            var t = ($(this).text() || '').trim().toLowerCase();
            if (t === 'ok' || t === 'entendi' || t === 'entendido' || t === 'got it' || t === 'dispensar' || t === 'fechar' || t === 'close') {
                if (!$(this).is(':visible')) return;
                outputMessage("✓ Aviso do Instagram dispensado ('" + t + "').");
                simulateClick($(this)[0]);
                done = true;
                return false;
            }
        });
        return done;
    } catch (e) { return false; }
}

function vpDumpCropButtonsOnce(scope) {
    // Diagnóstico: lista botões visíveis da tela de corte (para mapear o seletor 9:16 exato)
    if (window.__vp_crop_dumped) return;
    window.__vp_crop_dumped = true;
    try {
        var btns = [];
        scope.find('button, div[role="button"], [aria-label], [title]').each(function () {
            if (btns.length >= 15) return false;
            if (!$(this).is(':visible')) return;
            var b = ((($(this).attr('aria-label') || '') + '|' + ($(this).attr('title') || '') + '|' + ($(this).text() || '').trim())).replace(/\s+/g, ' ').slice(0, 80);
            if (b.replace(/\|/g, '') && btns.indexOf(b) < 0) btns.push(b);
        });
        outputMessage('  → botões da tela de corte: ' + (btns.join(' || ') || 'nenhum'));
    } catch (e) {}
}

function vpEnsureOriginalRatio(scope) {
    // Reels vertical 9:16 OBRIGATÓRIO (nunca quadrado): 2 fases — abre ferramenta de corte, depois clica 9:16
    // Se já concluiu, NÃO reclica (evita loop infinito sem Avançar)
    if (window.__vp_ratio_done) return false;
    try {
        var target = null, why = '';
        // 1. Botão com texto 9:16 (seletor de proporção do corte)
        scope.find('button, div[role="button"], div[role="menuitem"], span').each(function () {
            if (target) return false;
            var t = ($(this).text() || '').trim();
            if ((t === '9:16' || t === '9 : 16') && $(this).is(':visible') && $(this).children().length <= 2) {
                target = $(this).closest('button, div[role="button"], div[role="menuitem"]');
                if (!target || !target.length) target = $(this);
                why = '9:16';
                return false;
            }
        });
        // 2. Original / Expandir / Proporção / Vertical / Retrato via aria-label ou texto
        if (!target) {
            scope.find('button, div[role="button"], [aria-label], [title]').each(function () {
                if (target) return false;
                var lbl = ((($(this).attr('aria-label') || '') + ' ' + ($(this).attr('title') || '') + ' ' + ($(this).text() || ''))).toLowerCase();
                if (lbl.indexOf('original') > -1 || lbl.indexOf('expand') > -1 || lbl.indexOf('tamanho real') > -1 ||
                    lbl.indexOf('propor') > -1 || lbl.indexOf('aspect') > -1 || lbl.indexOf('tela cheia') > -1 ||
                    lbl.indexOf('vertical') > -1 || lbl.indexOf('retrato') > -1 || lbl.indexOf('9:16') > -1 ||
                    lbl.indexOf('cortar') > -1 || lbl.indexOf('crop') > -1 || lbl.indexOf('ajustar') > -1 || lbl.indexOf('adjust') > -1) {
                    if (!$(this).is(':visible')) return;
                    target = $(this);
                    why = 'original';
                    return false;
                }
            });
        }
        // 2b. Ícone "< >" (expandir) no canto inferior esquerdo do preview: abre as proporções
        if (!target && !window.__vp_expand_clicked) {
            try {
                var dlgRect = null;
                try { var d0 = scope.first ? scope.first() : scope[0]; if (d0 && d0.getBoundingClientRect) dlgRect = d0.getBoundingClientRect(); } catch (e) {}
                scope.find('button, div[role="button"], a, [tabindex="0"], svg').each(function () {
                    if (target) return false;
                    var self = $(this);
                    if (!self.is(':visible')) return;
                    var rr = this.getBoundingClientRect ? this.getBoundingClientRect() : null;
                    if (!rr || rr.width < 8 || rr.width > 90 || rr.height < 8 || rr.height > 90) return;
                    var lbl = (((self.attr('aria-label') || '') + ' ' + (self.attr('title') || '') + ' ' + (self.text() || ''))).toLowerCase();
                    var kw = lbl.indexOf('expand') > -1 || lbl.indexOf('ampliar') > -1 || lbl.indexOf('tela cheia') > -1 ||
                        lbl.indexOf('fullscreen') > -1 || lbl.indexOf('full screen') > -1 || lbl.indexOf('ajustar') > -1 ||
                        lbl.indexOf('preencher') > -1 || lbl.indexOf('fill') > -1 || lbl.indexOf('fit') > -1 || lbl.indexOf('zoom') > -1;
                    var bottomLeft = false;
                    if (dlgRect && rr) {
                        var cx = rr.left + rr.width / 2, cy = rr.top + rr.height / 2;
                        bottomLeft = (cx < dlgRect.left + dlgRect.width * 0.4) && (cy > dlgRect.top + dlgRect.height * 0.55);
                    }
                    var isSvgIcon = (this.tagName === 'svg') || (self.find('svg').length > 0 && (self.text() || '').trim() === '');
                    if (kw || (bottomLeft && isSvgIcon)) {
                        target = self[0].tagName === 'svg' ? (function () { var c = null; try { c = self.closest('button, div[role="button"], a'); } catch (e) {} return (c && c.length) ? c : self; })() : self;
                        why = 'expand-icon';
                        return false;
                    }
                });
            } catch (e) {}
            if (target) window.__vp_expand_clicked = true;
        }
        // 3. Fase 2: botão "Selecionar corte" (texto visível no seu layout) abre as proporções
        if (!target && !window.__vp_crop_tool_opened) {
            scope.find('button, div[role="button"], span, div').each(function () {
                if (target) return false;
                var tx = ($(this).text() || '').trim().toLowerCase();
                if ((tx === 'selecionar corte' || tx === 'selecionar o corte') && $(this).children().length <= 3 && $(this).is(':visible')) {
                    target = $(this).closest('button, div[role="button"]');
                    if (!target || !target.length) target = $(this);
                    why = 'abrir-corte';
                    return false;
                }
            });
            if (!target) {
                scope.find('button, div[role="button"]').each(function () {
                    if (target) return false;
                    var lbl = ((($(this).attr('aria-label') || '') + ' ' + ($(this).attr('title') || ''))).toLowerCase();
                    var hasCropIcon = ($(this).find('svg').length > 0 && ($(this).text() || '').trim() === '');
                    if ((lbl.indexOf('cort') > -1 || lbl.indexOf('crop') > -1 || hasCropIcon) && $(this).is(':visible')) {
                        target = $(this);
                        why = 'abrir-corte';
                        return false;
                    }
                });
            }
            if (target) window.__vp_crop_tool_opened = true;
        }
        if (target && target.length) {
            if (why !== 'abrir-corte' && why !== 'expand-icon') window.__vp_ratio_done = true;
            outputMessage((why === 'abrir-corte' ? "⟳ Abrindo ferramenta de corte ('" : why === 'expand-icon' ? "⟳ Clicando expandir '< >' ('" : "✓ Proporção vertical selecionada (" + why + ": '") + ((target.attr('aria-label') || target.attr('title') || target.text().trim()).slice(0, 40)) + "').");
            simulateClick(target[0]);
            // Reforço com clique real (opções do Instagram ignoram sintético como o botão +)
            try {
                var rr2 = target[0].getBoundingClientRect();
                var rx = Math.round(rr2.left + rr2.width / 2), ry = Math.round(rr2.top + rr2.height / 2);
                setTimeout(function () {
                    try { chrome.runtime.sendMessage({ vpDebugClick: { x: rx, y: ry } }, function () {}); } catch (e) {}
                }, 500);
            } catch (e) {}
            return true;
        } else if (window.__vp_upload_is_video && !window.__vp_ratio_missing_logged) {
            window.__vp_ratio_missing_logged = true;
            outputMessage("  → seletor 9:16 não achado; tentando Avançar (confira o formato; Registro tem a lista de botões).");
        }
    } catch (e) {}
    return false;
}

function vpOpenCreateComposer() {
    try {
        // Se preso numa tela /create sem composer, volta ao feed e retoma (recarrega o estado)
        var p = window.location.pathname || '';
        if (p.indexOf('/create') === 0) {
            outputMessage('⏳ Saindo da tela de criação travada, voltando ao feed...');
            try { chrome.storage.local.set({ vp_resume_folder_post: 1 }); } catch (e) {}
            window.location.href = 'https://www.instagram.com/';
            return;
        }
        // 1. Link seguro /create/select/ (NUNCA usar /create/ puro: pode ser o perfil @create)
        var selLink = document.querySelector('a[href="/create/select/"], a[href="/create/select"], a[href^="/create/select/"]');
        if (selLink) {
            try {
                var r0 = selLink.getBoundingClientRect();
                outputMessage("✓ Link /create/select/ encontrado (" + selLink.tagName + ", visivel=" + ($(selLink).is(':visible')) + ", rect=" + Math.round(r0.width) + "x" + Math.round(r0.height) + "). Clicando...");
            } catch (e) { outputMessage("✓ Link /create/select/ encontrado. Clicando..."); }
            simulateClick(selLink);
            return;
        } else {
            try { outputMessage("  → nenhum a[href^='/create/select'] no DOM (total a[href^='/create']=" + document.querySelectorAll('a[href^="/create"]').length + ")"); } catch (e) {}
        }
        var navBtn = null;
        try {
            document.querySelectorAll('svg[aria-label]').forEach(function (svg) {
                if (navBtn) return;
                var lbl = (svg.getAttribute('aria-label') || '').toLowerCase();
                if (lbl.indexOf('creat') > -1 || lbl.indexOf('criar') > -1 || lbl.indexOf('new post') > -1 || lbl.indexOf('nova public') > -1 || lbl.indexOf('post') > -1) {
                    var c = null;
                    try { c = svg.closest('a, button, div[role="button"]'); } catch (e) {}
                    if (c) navBtn = c;
                }
            });
            // Fallback: SVG com <title> interno (layout novo sem aria-label no svg)
            if (!navBtn) {
                document.querySelectorAll('svg').forEach(function (svg) {
                    if (navBtn) return;
                    var inner = '';
                    try { var tEl = svg.querySelector('title'); if (tEl) inner = (tEl.textContent || '').toLowerCase(); } catch (e) {}
                    if (inner.indexOf('creat') > -1 || inner.indexOf('criar') > -1 || inner.indexOf('new post') > -1 || inner.indexOf('nova public') > -1) {
                        var c2 = null;
                        try { c2 = svg.closest('a, button, div[role="button"]'); } catch (e) {}
                        if (c2) navBtn = c2;
                    }
                });
            }
        } catch (e) {}
        if (!navBtn) {
            try {
                var allLinks = document.querySelectorAll('a[href^="/create/select"]');
                if (allLinks.length) navBtn = allLinks[0];
            } catch (e) {}
        }
        if (!navBtn) {
            try {
                var spans = document.querySelectorAll('nav span, div[role="navigation"] span');
                for (var i = 0; i < spans.length; i++) {
                    var t = (spans[i].textContent || '').trim().toLowerCase();
                    if (t === 'criar' || t === 'create') {
                        navBtn = spans[i].closest('a, button, div[role="button"]') || spans[i];
                        break;
                    }
                }
            } catch (e) {}
        }
        if (navBtn) {
            try {
                var r1 = navBtn.getBoundingClientRect ? navBtn.getBoundingClientRect() : { width: 0, height: 0 };
                var desc = (navBtn.tagName || '?') + ' aria=' + (navBtn.getAttribute && (navBtn.getAttribute('aria-label') || '')) + ' txt=' + ((navBtn.textContent || '').trim().slice(0, 30)) + ' rect=' + Math.round(r1.width) + 'x' + Math.round(r1.height);
                outputMessage("✓ Botão Criar encontrado (" + desc + "). Clicando...");
            } catch (e) { outputMessage("✓ Botão Criar encontrado. Clicando..."); }
            simulateClick(navBtn);
            // Reforço: clica também nos demais candidatos (ícone + rótulo) com intervalo
            try {
                var extras = vpCollectCreateCandidates().filter(function (c) { return c !== navBtn; }).slice(0, 2);
                extras.forEach(function (c, i) {
                    setTimeout(function () { try { simulateClick(c); } catch (e) {} }, 700 * (i + 1));
                });
                if (extras.length) outputMessage('  → +' + extras.length + ' clique(s) de reforço agendados.');
            } catch (e) {}
        } else {
            outputMessage("⚠️ Botão Criar não achado, tentando link parcial...");
            var fb = findCreateButton();
            if (fb) {
                simulateClick(fb);
            } else {
                // Registra os controles expostos pelo layout atual do Instagram.
                try {
                    var labels = [];
                    var probes = document.querySelectorAll('nav a, nav button, nav [role="button"], header a, header button, header [role="button"], [aria-label], [title]');
                    for (var q = 0; q < probes.length && labels.length < 30; q++) {
                        var probe = probes[q];
                        if (!$(probe).is(':visible')) continue;
                        var label = ((probe.getAttribute('aria-label') || '') + '|' + (probe.getAttribute('title') || '') + '|' + (probe.getAttribute('href') || '') + '|' + (probe.textContent || '').trim()).replace(/\s+/g, ' ').slice(0, 120);
                        if (label && labels.indexOf(label) === -1) labels.push(label);
                    }
                    outputMessage('Controles Instagram detectados: ' + (labels.join(' || ') || 'nenhum rótulo visível'));
                    var svgInfo = [];
                    var navSvgs = document.querySelectorAll('nav svg, [role="navigation"] svg');
                    for (var z = 0; z < navSvgs.length && z < 20; z++) {
                        var rect = navSvgs[z].getBoundingClientRect();
                        if (rect.width < 10 || rect.height < 10) continue;
                        svgInfo.push(z + '@' + Math.round(rect.left) + ',' + Math.round(rect.top) + ':' + navSvgs[z].outerHTML.slice(0, 180));
                    }
                    outputMessage('SVGs de navegação: ' + (svgInfo.join(' || ') || 'nenhum'));
                } catch (e) {}
            }
        }
    } catch (e) {
        outputMessage("⚠️ Erro ao abrir composer: " + e.message);
    }
}

function executeInstagramDomUpload(file, legenda) {
    // Só opera no feed: fora dele (reels/perfil), volta sozinho e retoma após carregar
    try {
        var curP = window.location.pathname || '/';
        if (curP !== '/') {
            outputMessage('⏳ Fora do feed (' + curP + '). Voltando para postar de lá...');
            try { chrome.storage.local.set({ vp_resume_folder_post: 1 }); } catch (e) {}
            window.location.href = 'https://www.instagram.com/';
            return;
        }
    } catch (e) {}
    outputMessage("🤖 Iniciando automação no DOM do Instagram...");
    $('#vp_ai_status').text('Abrindo modal...').css('color', '#ecc94b');
    
    // Ocultar o painel da extensão para dar visão completa ao usuário
    $('#igBotInjectedContainer, #igBotContainer, .igBotContainer').hide();
    try {
        if (typeof hideControlsDiv === 'function') hideControlsDiv(false);
    } catch(e) {}
    
    // Fallback agressivo com Vanilla JS para garantir que a UI não bloqueie eventos
    try {
        var idsToHide = ['igBotInjectedContainer', 'igBotContainer', 'vp_ai_main_panel'];
        idsToHide.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) {
                el.style.display = 'none';
                el.style.setProperty('display', 'none', 'important');
            }
        });
        $('.igBotContainer, .igBotParent').hide();
    } catch(e) {}
    
    // ESTRATÉGIA ZERO: Se já estiver na tela de detalhes, pula direto para a legenda!
    // (exceto reels encadeados: precisam de upload novo, nunca reaproveitar tela velha)
    if (window.location.pathname.indexOf('/create/details') > -1 && window.__vp_upload_is_video !== true) {
        outputMessage("✓ Já estamos na tela de detalhes da postagem! Pulando upload de imagem...");
        setTimeout(function() {
            writeCaptionAndShare(legenda);
        }, 1500);
        return;
    }
    
    // Guarda o arquivo globalmente para re-usar após navegação
    window.__vp_pending_file = file;
    window.__vp_pending_legenda = legenda;
    window.__vp_file_input_idx = 0;
    window.__vp_ratio_clicks = 0;
    window.__vp_share_waits = 0;
    window.__vp_aborted = false;
    window.__vp_ratio_done = false;
    window.__vp_ratio_ok = false;
    window.__vp_ratio_idle = 0;
    window.__vp_ratio_tries = 0;
    window.__vp_expand_clicked = false;
    window.__vp_crop_dumped = false;
    window.__vp_crop_tool_opened = false;
    window.__vp_ratio_missing_logged = false;
    window.__vp_cover_picked = false;
    window.__vp_realclick_done = false;
    window.__vp_realkey_done = false;
    window.__vp_menu_clicked = false;
    
    // 0. Se o composer já está aberto com input, injeta direto nele
    var composerNow = vpFindComposerDialog();
    if (composerNow) {
        var composerInputNow = composerNow.find('input[type="file"]');
        if (composerInputNow.length > 0) {
            outputMessage("✓ Composer já aberto. Injetando arquivo diretamente...");
            injectFileAndTrigger(composerInputNow[0], file, legenda);
            return;
        }
    }

    // 1. MODO AUTOMÁTICO: clica no + Criar sozinho (1 vídeo/dia no horário agendado).
    // Se o auto-clique falhar, cai para o modo guiado (usuário abre manual).
    outputMessage("🤖 Modo automático: abrindo o + Criar sozinho...");
    window.__vp_auto_create_tries = 0;
    window.__vp_auto_create_done = false;

    // Clique REAL (trusted, isTrusted=true) via background+debugger.
    // Necessário porque o Instagram ignora cliques sintéticos no + Criar.
    function vpRequestTrustedClick(el) {
        try {
            var rc = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
            if (!rc || rc.width <= 0 || rc.height <= 0) {
                outputMessage("  → sem coordenadas visíveis para clique real.");
                return;
            }
            var cx = Math.round(rc.left + rc.width / 2), cy = Math.round(rc.top + rc.height / 2);
            outputMessage("  → clique real em (" + cx + "," + cy + ")... (o Chrome pode mostrar aviso de depuração, é normal)");
            chrome.runtime.sendMessage({ vpTrustedClick: { x: cx, y: cy } }, function (resp) {
                if (resp && resp.success) outputMessage("  → clique real enviado, aguardando menu/composer...");
                else outputMessage("  → clique real falhou (" + ((resp && resp.error) || "sem resposta") + "). Feche o DevTools (F12) e tente de novo.");
            });
        } catch (e) {
            outputMessage("  → erro no clique real: " + e.message);
        }
    }

    // Clica na opção Post/Publicação do menu do + Criar (qualquer markup: menuitem,
    // botão ou link dentro/fora de role=menu). Nunca clica em Reels puro, Repost, nem no próprio +.
    // Só age até 8s após um clique no + (evita clicar em botões do feed como "Repostar").
    // Retorna true se clicou.
    function vpClickPostMenuOption(useTrusted) {
        var clicked = false;
        try {
            var lastPlus = window.__vp_last_plus_click || 0;
            if (!lastPlus || Date.now() - lastPlus > 8000) return false;
            var postTexts = ['publicação', 'publicacao', 'post', 'postar', 'postagem', 'publicar', 'new post', 'novo post', 'nova publicação', 'nova publicacao'];
            function vpIsPostText(t) {
                if (!t) return false;
                // Texto duplicado pelo markup (ex: A com 2 SPANs "PostarPostar") -> usa metade
                try {
                    var n = t.length;
                    if (n % 2 === 0 && n >= 8) {
                        var h = t.substring(0, n / 2);
                        if (h === t.substring(n / 2)) t = h;
                    }
                } catch (eD) {}
                for (var i = 0; i < postTexts.length; i++) {
                    if (t === postTexts[i]) return true;
                }
                // Palavra isolada (nunca substring: "repostar"/"repost" NÃO vale)
                var words = t.split(/[^a-zà-ú0-9]+/);
                for (var w = 0; w < words.length; w++) {
                    for (var k = 0; k < postTexts.length; k++) {
                        if (words[w] === postTexts[k]) return true;
                    }
                }
                return false;
            }
            var cands = [];
            var seenTargets = [];
            document.querySelectorAll('div[role="menuitem"], div[role="menu"] button, div[role="menu"] div[role="button"], div[role="menu"] a, body > div a, body > div button, body > div div[role="button"], body > div span').forEach(function (el) {
                try {
                    if (window.__vp_last_create_btn && (el === window.__vp_last_create_btn || (el.contains && el.contains(window.__vp_last_create_btn)))) return;
                    if (el.closest && el.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, nav, header')) return;
                    if (!$(el).is(':visible')) return;
                    var t = (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
                    if (!t || t.length > 40) return;
                    if (t.indexOf('criar') > -1) return; // nunca o próprio Criar
                    if (t.indexOf('reel') > -1 && t.indexOf('publica') === -1) return; // nunca Reels puro
                    if (t.indexOf('repost') > -1) return; // nunca Repost/Repostar do feed
                    // Alvo clicável: o próprio elemento ou o ancestral clicável (ex: SPAN "Postar" -> A)
                    var target = el;
                    try {
                        var tag = (el.tagName || '').toUpperCase();
                        if (tag === 'SPAN' || tag === 'DIV') {
                            var up = el.closest ? el.closest('a, button, div[role="button"], div[role="menuitem"]') : null;
                            if (up && up !== window.__vp_last_create_btn) target = up;
                        }
                    } catch (eUp) {}
                    if (seenTargets.indexOf(target) > -1) return;
                    seenTargets.push(target);
                    cands.push({ el: target, t: t });
                } catch (e2) {}
            });
            // Texto exato ou palavra isolada — mesmo clique REAL do botão + (via debugger)
            for (var ci = 0; ci < cands.length && !clicked; ci++) {
                if (vpIsPostText(cands[ci].t)) {
                    try {
                        var mrc = cands[ci].el.getBoundingClientRect ? cands[ci].el.getBoundingClientRect() : { width: 0, height: 0, left: 0, top: 0 };
                        outputMessage("✓ Opção '" + cands[ci].t.slice(0, 25) + "' em (" + Math.round(mrc.left + mrc.width / 2) + "," + Math.round(mrc.top + mrc.height / 2) + "), clicando" + (useTrusted ? " (real)..." : "..."));
                    } catch (eL) {
                        outputMessage("✓ Opção '" + cands[ci].t.slice(0, 25) + "' encontrada, clicando" + (useTrusted ? " (real)..." : "..."));
                    }
                    if (useTrusted) vpRequestTrustedClick(cands[ci].el);
                    else simulateClick(cands[ci].el);
                    window.__vp_menu_clicked = true;
                    try { window.__vp_menu_click_time = Date.now(); } catch (eT) {}
                    clicked = true;
                    break;
                }
            }
            // Diagnóstico sempre (limitado): mostra o que está visível p/ ajuste fino
            if (!clicked && cands.length) {
                try {
                    var sig = cands.slice(0, 6).map(function (c) { return "'" + c.t.slice(0, 25) + "'"; }).join(' | ');
                    if (window.__vp_last_cands_sig !== sig || (window.__vp_auto_create_tries || 0) >= 6) {
                        window.__vp_last_cands_sig = sig;
                        outputMessage("  → candidatos visíveis (sem match): " + sig);
                    }
                } catch (eS) {}
            }
        } catch (e) {}
        return clicked;
    }

    function vpAutoClickCreate() {
        if (window.__vp_auto_create_done) return;
        // Já tem composer? não precisa clicar
        try { if (vpFindComposerDialog()) { window.__vp_auto_create_done = true; return; } } catch (e) {}
        if ((window.__vp_auto_create_tries || 0) >= 10) return; // máx 10 auto-cliques (~20s)
        window.__vp_auto_create_tries = (window.__vp_auto_create_tries || 0) + 1;
        // A partir da 6ª tentativa o clique sintético provou não funcionar (IG ignora
        // isTrusted=false): usa clique REAL via debugger (1x a cada 2 tentativas p/ não spammar)
        var useTrusted = window.__vp_auto_create_tries >= 6 && (window.__vp_auto_create_tries % 2 === 0);
        try {
            // 1a. Menu do + já aberto? clica em Post/Publicação
            if (vpClickPostMenuOption(useTrusted)) return;
            // 1b. Senão, clica no + Criar da barra lateral (com diagnóstico p/ ajuste)
            var btn = null;
            try { btn = findCreateButton(); } catch (e) { btn = null; }
            if (btn) {
                try {
                    var dbgTag = btn.tagName || '?';
                    var dbgHref = (btn.getAttribute && btn.getAttribute('href')) || '-';
                    var dbgLabel = ((btn.getAttribute && (btn.getAttribute('aria-label') || btn.getAttribute('title'))) || '') + '|' + ((btn.textContent || '').trim().slice(0, 20));
                    var dbgRect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : { width: 0, height: 0 };
                    outputMessage("⟳ Auto-clique no + Criar (" + window.__vp_auto_create_tries + "/10)" + (useTrusted ? " [REAL via debugger]" : "") + ": " + dbgTag + " href=" + dbgHref + " label=" + dbgLabel + " rect=" + Math.round(dbgRect.width) + "x" + Math.round(dbgRect.height));
                } catch (eDbg) {}
                if (useTrusted) vpRequestTrustedClick(btn);
                else simulateClick(btn);
                try { window.__vp_last_create_btn = btn; window.__vp_last_plus_click = Date.now(); } catch (eB) {}
                // Após o clique, lista o que apareceu (menu/dialog ou qualquer texto post/publica)
                setTimeout(function () {
                    try {
                        var items = [];
                        document.querySelectorAll('div[role="menuitem"], div[role="menu"], div[role="dialog"]').forEach(function (m) {
                            try {
                                if (!$(m).is(':visible')) return;
                                var tx = (m.textContent || '').replace(/\s+/g, ' ').trim().substring(0, 80);
                                if (tx) items.push((m.getAttribute('role') || '?') + ':"' + tx + '"');
                            } catch (e2) {}
                        });
                        // Fallback: qualquer elemento visível falando de post/publica
                        if (!items.length) {
                            document.querySelectorAll('button, div[role="button"], a, span').forEach(function (m) {
                                try {
                                    if (items.length >= 6) return;
                                    if (m.closest && m.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, nav, header')) return;
                                    if (!$(m).is(':visible')) return;
                                    var tx2 = (m.textContent || '').replace(/\s+/g, ' ').trim().substring(0, 40);
                                    if (!tx2 || tx2.length > 40) return;
                                    var low = tx2.toLowerCase();
                                    if (low.indexOf('criar') > -1) return;
                                    if (low === 'post' || low === 'publicação' || low === 'publicacao' || low === 'publicar' || low.indexOf('post') > -1 || low.indexOf('publica') > -1) {
                                        items.push((m.tagName || '?') + ':"' + tx2 + '"');
                                    }
                                } catch (e3) {}
                            });
                        }
                        if (items.length) outputMessage("  → após clique: " + items.slice(0, 6).join(' | '));
                        else outputMessage("  → após clique: nenhum menu/dialog visível (clique ignorado pelo IG?)");
                    } catch (e) {}
                }, 1200);
            } else if (window.__vp_auto_create_tries === 1) {
                try {
                    var svgLabels = [];
                    document.querySelectorAll('svg[aria-label]').forEach(function (s) {
                        var l = (s.getAttribute('aria-label') || '').trim();
                        if (l && svgLabels.indexOf(l) < 0) svgLabels.push(l);
                    });
                    outputMessage("👆 Botão + não detectado. svg aria-labels: " + (svgLabels.slice(0, 12).join(' | ') || 'nenhum'));
                } catch (e) {}
            }
        } catch (e) {}
    }

    // 2. Aguarda o composer renderizar e injeta no input DELE
    var attempts = 0;
    var pushedState = false;
    var navAwayCount = 0;
    var fileInputInterval = setInterval(function() {
        attempts++;

        if (window.__vp_aborted) { clearInterval(fileInputInterval); return; }

        // Guarda: se saiu do feed (ex: foi p/ /reels/), volta sozinho e retoma (não aborta)
        try {
            var curPath = window.location.pathname || '/';
            if (curPath !== '/') {
                navAwayCount++;
                if (navAwayCount >= 4) {
                    clearInterval(fileInputInterval);
                    outputMessage('⏳ Saiu do feed (' + curPath + '). Voltando para postar de lá...');
                    try { chrome.storage.local.set({ vp_resume_folder_post: 1 }); } catch (e) {}
                    try { chrome.storage.local.set({ 'vp_ai_posting_lock': 0 }); } catch (e2) {}
                    window.__vp_posting_in_progress = false;
                    window.__vp_auto_create_done = false;
                    window.__vp_auto_create_tries = 0;
                    restoreConsoleErrors();
                    window.location.href = 'https://www.instagram.com/';
                    return;
                }
            } else {
                navAwayCount = 0;
            }
        } catch (e) {}

        var composer = vpFindComposerDialog();
        if (composer) {
            var ci = composer.find('input[type="file"]');
            if (ci.length > 0) {
                clearInterval(fileInputInterval);
                window.__vp_auto_create_done = true;
                outputMessage("✓ Composer aberto, input encontrado após " + (attempts * 500 / 1000).toFixed(1) + "s!");
                injectFileAndTrigger(ci[0], file, legenda);
                return;
            }
        }

        // AUTO-CLIQUE: tenta abrir o + Criar sozinho a cada 2s até o composer aparecer
        if (attempts % 4 === 0 && attempts <= 40 && !window.__vp_auto_create_done) {
            vpAutoClickCreate();
        }

        // Vigia do menu a cada tick (500ms): se a caixinha do + abriu entre um auto-clique
        // e outro, clica em Postar na hora sem esperar o próximo ciclo de 2s
        if (attempts <= 110 && !window.__vp_auto_create_done && !window.__vp_menu_clicked) {
            try {
                if (!vpFindComposerDialog()) {
                    vpClickPostMenuOption((window.__vp_auto_create_tries || 0) >= 6);
                }
            } catch (eM) {}
        }
        if (window.__vp_menu_clicked) {
            try { if (vpFindComposerDialog()) { window.__vp_menu_clicked = false; window.__vp_menu_click_time = 0; } } catch (eM2) {}
            // Reabilita a vigia se o composer ainda não veio após 4s do clique no menu (tenta de novo)
            if (!window.__vp_menu_click_time) { try { window.__vp_menu_click_time = Date.now(); } catch (eM3) {} }
            else if (Date.now() - window.__vp_menu_click_time > 4000) {
                window.__vp_menu_clicked = false;
                window.__vp_menu_click_time = 0;
            }
        }

        // SE ESTIVER NUMA PÁGINA /create SEM COMPOSER (ex: perfil @create por navegação
        // direta), volta sozinha para o feed — o Instagram atual só abre o criador como dialog no feed.
        if (attempts === 6 && !window.__vp_auto_create_done && !vpFindComposerDialog()) {
            try {
                var p0 = window.location.pathname || '/';
                if (p0.indexOf('/create') > -1) {
                    outputMessage("⏳ Página /create sem composer (perfil @create). Voltando ao feed...");
                    window.location.href = 'https://www.instagram.com/';
                    return;
                }
            } catch (e) {}
        }

        // 3. Fallback legado: qualquer input (fluxo antigo das fotos) após 5s
        if (attempts === 10) {
            var fileInputEl = vpFindInstagramFileInput();
            if (fileInputEl) {
                clearInterval(fileInputInterval);
                outputMessage("✓ Input de arquivo encontrado após " + (attempts * 500 / 1000).toFixed(1) + "s!");
                injectFileAndTrigger(fileInputEl, file, legenda);
                return;
            }
        }

        // 4. Fallback: History API após 10s sem composer
        // Não usar History API: o roteador atual interpreta /create/select/
        // como o perfil @create em vez de abrir o compositor.
        if (false && attempts === 20 && !pushedState) {
            pushedState = true;
            outputMessage("⟳ Abrindo /create/select/ via History API...");
            try {
                window.history.pushState(null, '', '/create/select/');
                window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
                outputMessage("✓ History alterada para /create/select/");
            } catch(e) {
                outputMessage("⚠️ Erro ao navegar: " + e.message);
            }
        }

        // MODO AUTOMÁTICO com fallback guiado: após 20s de auto-clique, pede ajuda manual
        if (attempts === 20 || attempts === 60 || attempts === 100) {
            outputMessage('👆 Auto-clique tentando abrir o + Criar sozinho (' + Math.round(attempts / 2) + 's)... Se não abrir, clique você no + e escolha Postar.');
        }

        if (attempts > 120) { // 60 segundos p/ abertura manual (sem recarregamento de página!)
            clearInterval(fileInputInterval);
            outputMessage("❌ Modal de criação não foi aberto a tempo.");
            outputMessage("💡 Clique no + Criar, escolha Postar e clique Postar Agora de novo (a fila foi mantida).");
            $('#vp_ai_status').text('Abra o + e tente de novo').css('color', '#e53e3e');
            chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
            window.__vp_posting_in_progress = false;
            try { window.__vp_pending_file = null; window.__vp_pending_legenda = null; } catch (e) {}
            restoreConsoleErrors();
            try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
        }
    }, 500);
}


function injectFileAndTrigger(inputElement, file, legenda) {
    $('#vp_ai_status').text('Enviando imagem...').css('color', '#ecc94b');
    
    // IMPORTANTE: Remover o atributo 'accept' do input para evitar rejeição de formato
    try {
        inputElement.removeAttribute('accept');
        inputElement.setAttribute('accept', window.__vp_upload_is_video ? 'video/*' : 'image/*');
    } catch(e) {}
    
    // Se o arquivo não for JPEG, converter para JPEG via canvas para máxima compatibilidade
    var processFile = function(finalFile) {
        var container = new DataTransfer();
        container.items.add(finalFile);
        
        try {
            var dtFiles = container.files;
            try {
                var filesSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'files').set;
                if (filesSetter) filesSetter.call(inputElement, dtFiles);
                else inputElement.files = dtFiles;
            } catch (e) { inputElement.files = dtFiles; }
        } catch(e) {}
        try {
            outputMessage("  → arquivos no input: " + (inputElement.files ? inputElement.files.length : 0));
        } catch(e) {}
        
        // Tenta disparar o handler do React diretamente para evitar Invariant Violation / null checks do Instagram
        var reactTriggered = false;
        try {
            reactTriggered = triggerReactChange(inputElement);
        } catch(e) {}
        
        if (!reactTriggered) {
            try {
                // Disparar eventos no input de arquivo que o React escuta
                inputElement.dispatchEvent(new Event('input', { bubbles: true }));
                inputElement.dispatchEvent(new Event('change', { bubbles: true }));
            } catch(e) {}
        }
        
        // TAMBÉM disparar evento DROP só no modal do Instagram (evita clonar arquivo pesado na página toda)
        try {
            var dlgEl = document.querySelector('div[role="dialog"]');
            var dropTargets = dlgEl ? [dlgEl] : [document.body];
            for (var d = 0; d < dropTargets.length; d++) {
                var target = dropTargets[d];
                var dragOver = new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: container });
                var dropEvt = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: container });
                target.dispatchEvent(dragOver);
                target.dispatchEvent(dropEvt);
            }
        } catch(e) {}
        
        outputMessage("✓ Imagem injetada no input e enviada via eventos (tipo: " + finalFile.type + ", tamanho: " + Math.round(finalFile.size / 1024) + "KB).");
        
        // Aguardar transição para a próxima tela
        waitForNextButton(1, legenda);
    };
    
    // Se é vídeo, valida proporção 9:16 vertical antes de enviar (reels 1080x1920 ideal)
    if (file.type.indexOf('video/') === 0) {
        outputMessage("✓ Vídeo detectado, enviando original (" + Math.round(file.size / 1024 / 1024 * 10) / 10 + "MB)...");
        try {
            var vUrl = URL.createObjectURL(file);
            var vProbe = document.createElement('video');
            vProbe.muted = true;
            vProbe.preload = 'metadata';
            vProbe.onloadedmetadata = function () {
                try {
                    var vw = vProbe.videoWidth || 0, vh = vProbe.videoHeight || 0;
                    var ratio = vh > 0 ? (vw / vh) : 0;
                    var isVertical = vh >= vw && ratio > 0.5 && ratio < 0.65; // ~9:16 = 0.5625
                    outputMessage("📐 Vídeo: " + vw + "x" + vh + (isVertical ? " ✓ vertical 9:16" : " ⚠️ NÃO é 9:16 — o Instagram vai cortar; ideal 1080x1920"));
                    URL.revokeObjectURL(vUrl);
                } catch (e) { try { URL.revokeObjectURL(vUrl); } catch (e2) {} }
                processFile(file);
            };
            vProbe.onerror = function () { try { URL.revokeObjectURL(vUrl); } catch (e) {} processFile(file); };
            vProbe.src = vUrl;
            // Timeout de segurança: se metadados não carregarem em 5s, envia mesmo assim
            setTimeout(function () { try { if (!vProbe.videoWidth) { try { URL.revokeObjectURL(vUrl); } catch (e) {} processFile(file); } } catch (e) {} }, 5000);
            // Flag para não chamar processFile duas vezes
            var _origProcess = processFile;
            var _called = false;
            processFile = function (f) { if (_called) return; _called = true; _origProcess(f); };
        } catch (e) {
            processFile(file);
        }
    } else if (file.type === 'image/jpeg' || file.type === 'image/jpg') {
        processFile(file);
    } else {
        // Converter para JPEG via canvas (resolve "somente imagens podem ser postadas")
        outputMessage("⟳ Convertendo imagem " + file.type + " para JPEG...");
        var reader = new FileReader();
        reader.onload = function(e) {
            var img = new Image();
            img.onload = function() {
                var canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                var ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                canvas.toBlob(function(blob) {
                    var jpegFile = new File([blob], "ai_post_" + Date.now() + ".jpg", { type: "image/jpeg" });
                    outputMessage("✓ Imagem convertida para JPEG (" + Math.round(blob.size / 1024) + "KB).");
                    processFile(jpegFile);
                }, 'image/jpeg', 0.92);
            };
            img.onerror = function() {
                outputMessage("⚠️ Erro ao converter imagem. Usando arquivo original...");
                processFile(file);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}


function waitForNextButton(step, legenda) {
    var stepName = step === 1 ? "Cortar (Crop)" : "Filtros (Filters)";
    var isVideoFlow = !!window.__vp_upload_is_video;
    // Vídeo demora mais para processar (10MB+): thresholds maiores
    var forceEvery = isVideoFlow ? 40 : 10;
    var step2MinAttempts = isVideoFlow ? 20 : 5;
    outputMessage("Aguardando confirmação da tela de " + stepName + "...");
    $('#vp_ai_status').text('Avançando (' + step + '/3)...').css('color', '#ecc94b');
    
    var attempts = 0;
    var nextInterval = setInterval(function() {
        attempts++;

        if (window.__vp_aborted) { clearInterval(nextInterval); return; }

        var dialog = $('div[role="dialog"], [role="dialog"], div[aria-modal="true"]');
        var scope = dialog.length > 0 ? dialog : $('body');

        // 0. Dispensar avisos (ex: "vídeos serão publicados como reels" → OK) + manter rascunho se pedir Descartar
        try { vpDismissInfoDialog(scope); } catch (e) {}
        try { vpHandleDiscardPopup(); } catch (e) {}

        // 0b. Na tela de corte, garantir proporção vertical 9:16 (nunca quadrado)
        if (step === 1 && isVideoFlow) {
            try { vpDumpCropButtonsOnce(scope); } catch (e) {}
            // Verifica se o 9:16 ficou SELECIONADO; se não, tenta de novo (máx 3x) antes do Avançar
            try {
                if (window.__vp_ratio_done && (window.__vp_ratio_tries || 0) < 3) {
                    var sel = false;
                    scope.find('[aria-checked="true"], [aria-selected="true"]').each(function () {
                        if (sel) return false;
                        var st = ((($(this).attr('aria-label') || '') + ' ' + ($(this).text() || ''))).toLowerCase();
                        if (st.indexOf('9:16') > -1 || st.indexOf('retrato') > -1 || st.indexOf('original') > -1) { sel = true; return false; }
                    });
                    if (!sel) {
                        window.__vp_ratio_tries = (window.__vp_ratio_tries || 0) + 1;
                        window.__vp_ratio_ok = false;
                        if (window.__vp_ratio_tries >= 3) {
                            outputMessage('  → seguindo para Avançar sem confirmação visual do 9:16.');
                            window.__vp_ratio_ok = true;
                        } else {
                            window.__vp_ratio_done = false;
                            outputMessage('  → 9:16 ainda não confirmado, reforçando (' + window.__vp_ratio_tries + '/3)...');
                        }
                    } else {
                        window.__vp_ratio_ok = true;
                        outputMessage('✓ Proporção 9:16 confirmada ativa.');
                    }
                }
            } catch (e) {}
            var ratioActed = false;
            try {
                window.__vp_ratio_clicks = window.__vp_ratio_clicks || 0;
                if (window.__vp_ratio_clicks >= 4) {
                    if (!window.__vp_ratio_ok) {
                        window.__vp_ratio_ok = true;
                        outputMessage('  → limite de tentativas do 9:16; seguindo para Avançar.');
                    }
                } else if (vpEnsureOriginalRatio(scope)) {
                    window.__vp_ratio_clicks++;
                    ratioActed = true;
                    window.__vp_ratio_idle = 0;
                    return; // aguarda 500ms e reavalia (Avançar vem depois)
                }
            } catch (e) {}
            // Sem nenhuma ação de proporção por 6 ticks seguidos: segue com aviso (não trava)
            if (!window.__vp_ratio_ok) {
                window.__vp_ratio_idle = (window.__vp_ratio_idle || 0) + (ratioActed ? 0 : 1);
                if (window.__vp_ratio_idle >= 6) {
                    window.__vp_ratio_ok = true;
                    outputMessage('  → sem opção 9:16 acessível; seguindo para Avançar (confira o formato).');
                }
            }
        }

        // 1. Verificar se a tela final de LEGENDA já está ativa DENTRO DO MODAL
        var captionBox = scope.find('div[role="textbox"], div[contenteditable="true"], [data-lexical-editor], textarea[name="caption"]');
        var shareBtnInDialog = scope.find('div[role="button"], button').filter(function() {
            var txt = $(this).text().trim().toLowerCase();
            return txt === 'compartilhar' || txt === 'share' || txt === 'publicar';
        });
        
        if (captionBox.length > 0 && shareBtnInDialog.length > 0) {
            clearInterval(nextInterval);
            outputMessage("✓ Tela final de legenda detectada no modal! Avançando para inserção da legenda...");
            writeCaptionAndShare(legenda);
            return;
        }
        
        // 2. Procurar o botão 'Avançar' / 'Next' DENTRO DO MODAL
        var nextBtn = null;
        var nextTexts = ['avançar', 'avancar', 'next', 'seguinte', 'próximo', 'proximo'];
        
        scope.find('div[role="button"], button, [role="button"], a').each(function() {
            var txt = $(this).text().trim().toLowerCase();
            var lbl = ($(this).attr('aria-label') || '').toLowerCase();
            if (nextTexts.includes(txt) || nextTexts.includes(lbl)) {
                nextBtn = $(this);
                return false;
            }
        });
        
        // Fallback: procura em div e span puro
        if (!nextBtn || nextBtn.length === 0) {
            scope.find('div, span, button').each(function() {
                var el = $(this);
                var txt = el.text().trim().toLowerCase();
                var lbl = (el.attr('aria-label') || '').toLowerCase();
                if ((nextTexts.includes(txt) || nextTexts.includes(lbl)) && el.children().length <= 3 && txt.length < 20) {
                    nextBtn = el;
                    return false;
                }
            });
        }
        
        if (nextBtn && nextBtn.length > 0) {
            // Vídeo no corte: NÃO avança sem 9:16 confirmado (evita post quadrado)
            if (step === 1 && isVideoFlow && !window.__vp_ratio_ok) {
                if (attempts % 4 === 1) outputMessage('  → aguardando confirmação do 9:16 antes do Avançar...');
                return;
            }
            // Segurança p/ vídeo pesado: só avança com botão HABILITADO (upload processado)
            try {
                var disNext = nextBtn.prop ? nextBtn.prop('disabled') : false;
                var ariaDis = nextBtn.attr ? nextBtn.attr('aria-disabled') : null;
                if (disNext === true || ariaDis === 'true') {
                    if (attempts % 4 === 1) outputMessage('  → Avançar desativado (vídeo processando ' + Math.round((window.__vp_pending_file ? window.__vp_pending_file.size : 0) / 1048576) + 'MB), aguardando...');
                    return;
                }
            } catch (e) {}
            clearInterval(nextInterval);
            var btnText = nextBtn.text().trim() || 'Avançar';
            outputMessage("✓ Botão '" + btnText + "' encontrado na tela " + stepName + ". Clicando...");
            simulateClick(nextBtn[0]);
            
            if (step === 1) {
                // Após clicar Avançar na tela de Crop, aguarda 1.5s e verifica o próximo passo
                setTimeout(function() {
                    waitForNextButton(2, legenda);
                }, 1500);
            } else {
                setTimeout(function() {
                    writeCaptionAndShare(legenda);
                }, 2000);
            }
        } else {
            // Se estiver no passo 2 e não houver botão Avançar (Instagram pulou filtros)
            if (step === 2 && attempts >= step2MinAttempts) {
                clearInterval(nextInterval);
                outputMessage("⟳ Passo 2: Sem botão Avançar adicional. Transicionando para tela de legenda...");
                writeCaptionAndShare(legenda);
                return;
            }
            
            if (attempts % forceEvery === 0) {
                clearInterval(nextInterval); // IMPORTANTE: limpar interval antes de avançar
                var stillSelecting = window.location.pathname.indexOf('/create/select') > -1 || window.location.pathname === '/create' || window.location.pathname === '/create/';
                var dlg = $('div[role="dialog"]');
                var dlgHasPreview = dlg.length > 0 && dlg.find('img, canvas').length > 0;
                if (stillSelecting && !dlgHasPreview) {
                    try {
                        var dlgText = (dlg.length > 0 ? dlg.text() : $('body').text()) || '';
                        dlgText = dlgText.replace(/\s+/g, ' ').trim().substring(0, 300);
                        outputMessage('  → tela mostra: "' + dlgText + '"');
                        var dlgBtns = [];
                        dlg.find('div[role="button"], button').each(function () {
                            var t = $(this).text().trim();
                            if (t && t.length < 40) dlgBtns.push(t);
                        });
                        if (dlgBtns.length) outputMessage('  → botões: ' + dlgBtns.slice(0, 8).join(' | '));
                    } catch (e) {}
                    var tryList = vpListInstagramFileInputs();
                    var tryIdx = (window.__vp_file_input_idx || 0) + 1;
                    if (tryIdx < tryList.length && window.__vp_pending_file) {
                        window.__vp_file_input_idx = tryIdx;
                        outputMessage("⟳ Tentando próximo input de arquivo (" + (tryIdx + 1) + "/" + tryList.length + ")...");
                        injectFileAndTrigger(tryList[tryIdx], window.__vp_pending_file, window.__vp_pending_legenda || legenda);
                        waitForNextButton(1, window.__vp_pending_legenda || legenda);
                        return;
                    }
                    outputMessage("❌ Instagram não aceitou a imagem (travado na tela de seleção).");
                    outputMessage("💡 Use JPG/PNG com pelo menos 320px e clique em 'Postar Agora (Teste)' de novo. O arquivo foi MANTIDO na fila.");
                    $('#vp_ai_status').text('Imagem não aceita').css('color', '#e53e3e');
                    chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                    window.__vp_posting_in_progress = false;
                    restoreConsoleErrors();
                    try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
                    return;
                }
                outputMessage("⚠️ Transição demorada no passo " + stepName + ". Forçando avanço para escrita de legenda...");
                writeCaptionAndShare(legenda);
                return; // Sai do callback para não continuar o interval
            }
        }
    }, 500);
}

function writeCaptionAndShare(legenda) {
    // Trava contra escrita dupla concorrente (causava legenda 2x/3x)
    if (window.__vp_caption_writing) {
        outputMessage('  → escrita de legenda já em andamento, ignorando chamada duplicada.');
        return;
    }
    window.__vp_caption_writing = true;
    outputMessage("Aguardando campo de legenda...");
    $('#vp_ai_status').text('Inserindo legenda...').css('color', '#ecc94b');
    
    if (!legenda || legenda.trim() === '') {
        outputMessage("\u26a0\ufe0f Aviso: A legenda est\u00e1 vazia. Usando texto padr\u00e3o.");
        legenda = "Post gerado por IA \ud83e\udd16";
    }
    
    // ESCONDER EXTENSÃO IMEDIATAMENTE para evitar que seus elementos interfiram
    try {
        var idsToHide = ['igBotInjectedContainer', 'igBotContainer', 'instabotIcon', 'vp_ai_main_panel'];
        idsToHide.forEach(function(id) {
            var panelEl = document.getElementById(id);
            if (panelEl) { panelEl.style.setProperty('display', 'none', 'important'); }
        });
    } catch(e) {}
    
    // Fun\u00e7\u00e3o auxiliar: verifica se um elemento pertence \u00e0 extens\u00e3o (para ignorar)
    function isExtensionElement(node) {
        if (!node) return true;
        try {
            var parent = node.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, .igBotParent, #vp_ai_main_panel');
            return parent !== null;
        } catch(e) { return false; }
    }
    
    var attempts = 0;
    var maxAttempts = window.__vp_upload_is_video ? 90 : 30; // reels processa o vídeo: espera até 45s
    window.__vp_caption_advances = 0;
    var captionInterval = setInterval(function() {
        attempts++;

        if (window.__vp_aborted) { clearInterval(captionInterval); return; }

        var el = null;
        
        // Seletores em ordem de prioridade - usa querySelectorAll e filtra
        var selectors = [
            'div[role="textbox"][aria-label*="caption" i]',
            'div[role="textbox"][aria-label*="legenda" i]',
            'div[role="textbox"][aria-label*="Write" i]',
            'div[role="textbox"][aria-label*="Escreva" i]',
            'div[role="textbox"][aria-label*="descri" i]',
            'div[role="textbox"][placeholder*="legend" i]',
            'div[role="textbox"][placeholder*="caption" i]',
            'textarea[placeholder*="legend" i]',
            'textarea[placeholder*="caption" i]',
            'textarea[aria-label*="legend" i]',
            'textarea[aria-label*="caption" i]',
            'input[placeholder*="legend" i]',
            'div[data-lexical-editor="true"]',
            'textarea[name="caption"]',
            'div[role="textbox"]',
            'div[contenteditable="true"]',
            'textarea',
            'input[type="text"]'
        ];
        
        for (var s = 0; s < selectors.length; s++) {
            var nodes = document.querySelectorAll(selectors[s]);
            for (var n = 0; n < nodes.length; n++) {
                if (!isExtensionElement(nodes[n])) {
                    el = nodes[n];
                    break;
                }
            }
            if (el) break;
        }
        
        if (attempts % 5 === 1) {
            outputMessage("  \u2192 Procurando campo... (" + attempts + "/" + maxAttempts + ") Campo: " + (el ? el.tagName + '[' + (el.getAttribute('aria-label') || el.getAttribute('role') || 'sem-label') + ']' : 'nenhum'));
        }
        
        if (!el) {
            // Popup Descartar pode aparecer aqui também: sempre manter
            try { vpHandleDiscardPopup(); } catch (e) {}
            // Mapeamento: lista editáveis visíveis no dialog (para acertar o seletor exato)
            if (attempts % 8 === 1) {
                try {
                    var cands = [];
                    document.querySelectorAll('div[role="textbox"], div[contenteditable="true"], textarea, input[type="text"], [data-lexical-editor]').forEach(function (n) {
                        if (cands.length >= 6) return;
                        try {
                            if (!$(n).is(':visible')) return;
                            if (n.closest && n.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, #vp_ai_main_panel')) return;
                            cands.push(n.tagName + '[' + ((n.getAttribute('aria-label') || n.getAttribute('placeholder') || n.getAttribute('role') || '') + '').slice(0, 40) + ']');
                        } catch (e) {}
                    });
                    outputMessage('  → editáveis visíveis: ' + (cands.join(' || ') || 'nenhum'));
                } catch (e) {}
            }
            // Tela de CAPA do reels: escolhe o 1º frame 1x (destrava o Avançar)
            if (!window.__vp_cover_picked && attempts % 4 === 0) {
                try {
                    var dlgTxt = ($('div[role="dialog"]').first().text() || '').toLowerCase();
                    if (dlgTxt.indexOf('capa') > -1 || dlgTxt.indexOf('cover') > -1 || dlgTxt.indexOf('miniatura') > -1 || dlgTxt.indexOf('thumbnail') > -1) {
                        var thumbs = [];
                        $('div[role="dialog"]').first().find('img, canvas, div[role="button"]').each(function () {
                            try {
                                if (!$(this).is(':visible')) return;
                                var rr = this.getBoundingClientRect ? this.getBoundingClientRect() : { width: 0, height: 0 };
                                if (rr.width >= 30 && rr.width <= 200 && rr.height >= 30 && rr.height <= 200) thumbs.push($(this));
                            } catch (e) {}
                        });
                        if (thumbs.length) {
                            window.__vp_cover_picked = true;
                            outputMessage('✓ Tela de capa detectada: selecionando frame...');
                            simulateClick(thumbs[0][0]);
                        }
                    }
                } catch (e) {}
            }
            // Telas intermediárias do reels (Capa, etc.): avança sozinho até 6x
            if (window.__vp_caption_advances < 6 && attempts % 4 === 0) {
                try {
                    var adv = null;
                    var advTexts = ['avançar', 'avancar', 'next', 'próximo', 'proximo', 'continuar', 'continue', 'concluir', 'done', 'ok'];
                    $('div[role="dialog"]').find('div[role="button"], button').each(function () {
                        if (adv) return false;
                        var at = ($(this).text() || '').trim().toLowerCase();
                        var aa = ($(this).attr('aria-label') || '').toLowerCase();
                        if ((advTexts.indexOf(at) > -1 || advTexts.indexOf(aa) > -1) && $(this).is(':visible')) {
                            adv = $(this);
                            return false;
                        }
                    });
                    if (adv) {
                        var dis = false;
                        try { dis = adv.prop('disabled') === true || adv.attr('aria-disabled') === 'true'; } catch (e) {}
                        if (dis) {
                            if (attempts % 8 === 0) outputMessage("  → botão '" + (adv.text().trim().slice(0, 20) || 'Avançar') + "' DESATIVADO (selecione capa/frame e aguarde)...");
                        } else {
                            window.__vp_caption_advances++;
                            outputMessage("⟳ Tela intermediária do reels: avançando (" + window.__vp_caption_advances + "/6)...");
                            simulateClick(adv[0]);
                        }
                    } else if (attempts % 8 === 0) {
                        var snip = '';
                        try { snip = ($('div[role="dialog"]').first().text() || '').replace(/\s+/g, ' ').trim().substring(0, 160); } catch (e) {}
                        outputMessage("  → aguardando tela de legenda... mostra: \"" + snip + "\"");
                    }
                } catch (e) {}
            }
            if (attempts >= maxAttempts) {
                clearInterval(captionInterval);
                window.__vp_caption_writing = false;
                outputMessage("\u274c Campo de legenda n\u00e3o encontrado. Tela: " + window.location.pathname);
                $('#vp_ai_status').text('Legenda n\u00e3o encontrada').css('color', '#e53e3e');
                chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                window.__vp_posting_in_progress = false;
                try { window.__vp_pending_file = null; window.__vp_pending_legenda = null; } catch (e) {}
                restoreConsoleErrors();
                try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
                try { document.getElementById('igBotInjectedContainer').style.removeProperty('display'); } catch(e) {}
            }
            return;
        }
        
        clearInterval(captionInterval);
        outputMessage("\u2713 Campo encontrado: " + el.tagName + ' [' + (el.getAttribute('aria-label') || el.getAttribute('role') || 'contenteditable') + ']');
        outputMessage("  \u2192 Localiza\u00e7\u00e3o: " + window.location.pathname);
        
        // PASSO 1: Clicar no campo como humano
        try { el.click(); } catch(e) {}
        
        // PASSO 2: Aguardar foco real do browser
        setTimeout(function() {
            try { el.focus(); } catch(e) {}
            
            // PASSO 3: Inserir texto 1x — métodos mutuamente exclusivos (checa antes de cada um)
            setTimeout(function() {
                function vpHasLeg() {
                    try {
                        var p = (legenda || '').trim().slice(0, 60);
                        var cur = (el.textContent || el.value || '');
                        if (p.length < 10) return cur.trim().length > 0;
                        return cur.indexOf(p) > -1;
                    } catch (e) { return false; }
                }

                // Limpeza inicial no mesmo tick do foco (selectAll+delete com foco real)
                try {
                    el.focus();
                    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                        var clearProto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                        Object.getOwnPropertyDescriptor(clearProto, 'value').set.call(el, '');
                        el.dispatchEvent(new Event('input', { bubbles: true }));
                    } else {
                        document.execCommand('selectAll', false, null);
                        document.execCommand('delete', false, null);
                    }
                } catch (e) {}

                // Cadeia: 1 método por vez com espera (Lexical aplica sintético com atraso; tudo junto = 2x/3x)
                var vpMethods = ['beforeinput', 'execCommand', 'paste'];
                var vpMi = 0;
                (function vpTryNext() {
                    if (vpHasLeg()) {
                        outputMessage('✓ Legenda inserida via ' + (vpMi > 0 ? vpMethods[vpMi - 1] : 'limpeza') + ' (1x).');
                        vpDoVerify();
                        return;
                    }
                    if (vpMi >= vpMethods.length) { vpDoVerify(); return; }
                    var mm = vpMethods[vpMi++];
                    try {
                        el.focus();
                        if (mm === 'beforeinput') {
                            el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: legenda, bubbles: true, cancelable: true, composed: true }));
                        } else if (mm === 'execCommand') {
                            document.execCommand('insertText', false, legenda);
                        } else if (mm === 'paste') {
                            var dt2 = new DataTransfer();
                            dt2.setData('text/plain', legenda);
                            el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt2, bubbles: true, cancelable: true }));
                        }
                    } catch (e) {}
                    setTimeout(vpTryNext, 1500);
                })();

                // Verificação (chamada 1s após a cadeia concluir)
                function vpDoVerify() { setTimeout(function() {
                    var finalText = (el.textContent || el.value || '').trim();
                    var expectedLen = (legenda || '').trim().length;
                    var probe = (legenda || '').trim().slice(0, 60);
                    var hasLegenda = probe.length > 10 && finalText.indexOf(probe) > -1;
                    if (finalText.length > 0 && (hasLegenda || finalText.length >= expectedLen)) {
                        // Normaliza: se a legenda entrou 2x/3x, limpa (selectAll no mesmo tick) e insere 1x só
                        try {
                            var occ = probe.length > 10 ? finalText.split(probe).length - 1 : 1;
                            if (occ >= 2) {
                                outputMessage('⚠️ Legenda repetida ' + occ + 'x — normalizando para 1x...');
                                el.focus();
                                document.execCommand('selectAll', false, null);
                                document.execCommand('delete', false, null);
                                var cleared = ((el.textContent || el.value || '').trim().length === 0);
                                if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                                    var np = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                                    if (!cleared) Object.getOwnPropertyDescriptor(np, 'value').set.call(el, '');
                                    Object.getOwnPropertyDescriptor(np, 'value').set.call(el, legenda);
                                    el.dispatchEvent(new Event('input', { bubbles: true }));
                                } else if (cleared) {
                                    el.focus();
                                    document.execCommand('insertText', false, legenda);
                                } else {
                                    outputMessage('  → limpeza incompleta, mantendo como está para não triplicar.');
                                }
                            }
                        } catch (e) {}
                        window.__vp_caption_writing = false;
                        outputMessage("\u2713 Legenda confirmada! Ajustando feed e compartilhando...");
                        $('#vp_ai_status').text('Compartilhando...').css('color', '#ecc94b');
                        try { vpDisableShareToFeed(); } catch (e) {}
                        setTimeout(clickShareButton, 2500);
                    } else if (finalText.length > 0) {
                        outputMessage('⚠️ Campo com texto estranho (' + finalText.length + ' chars, sem a legenda). Reinserindo 1x...');
                        try {
                            el.focus();
                            if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                                var rp = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                                Object.getOwnPropertyDescriptor(rp, 'value').set.call(el, legenda);
                                el.dispatchEvent(new Event('input', { bubbles: true }));
                            } else {
                                var sel1 = window.getSelection();
                                var rng1 = document.createRange();
                                rng1.selectNodeContents(el);
                                sel1.removeAllRanges();
                                sel1.addRange(rng1);
                                document.execCommand('delete', false, null);
                                sel1.removeAllRanges();
                                el.focus();
                                document.execCommand('insertText', false, legenda);
                            }
                        } catch (e) {}
                        setTimeout(function() {
                            outputMessage('✓ Seguindo para compartilhar...');
                            window.__vp_caption_writing = false;
                            $('#vp_ai_status').text('Compartilhando...').css('color', '#ecc94b');
                            try { vpDisableShareToFeed(); } catch (e) {}
                            setTimeout(clickShareButton, 2500);
                        }, 800);
                        return;
                    } else {
                        window.__vp_caption_writing = false;
                        outputMessage("\u26a0\ufe0f Texto n\u00e3o confirmado no campo. Parando para evitar postar sem legenda.");
                        outputMessage("\ud83d\udca1 Clique no campo de legenda, digite manualmente e clique em Compartilhar.");
                        $('#vp_ai_status').text('Digite a legenda manualmente').css('color', '#e53e3e');
                        chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                        window.__vp_posting_in_progress = false;
                        restoreConsoleErrors();
                        try { document.getElementById('igBotInjectedContainer').style.removeProperty('display'); } catch(e) {}
                        try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
                    }
                }, 1000); }

            }, 500);
        }, 800);
    }, 500);
}


function vpDisableShareToFeed() {
    // Reels somente na aba Reels: desliga "Compartilhar no feed" antes de publicar
    try {
        var scope = $('div[role="dialog"]');
        if (!scope.length) scope = $('body');
        var candidates = [];
        scope.find('input[type="checkbox"], div[role="switch"], button[aria-checked], div[role="checkbox"]').each(function () {
            var el = $(this);
            var wrapTxt = '';
            try {
                var wrap = el.closest('label, div');
                wrapTxt = ((wrap.text() || '') + ' ' + (el.attr('aria-label') || '') + ' ' + (el.attr('title') || '')).toLowerCase();
            } catch (e) {}
            if (wrapTxt.indexOf('feed') > -1) candidates.push(el);
        });
        if (!candidates.length) {
            scope.find('span, div, label').each(function () {
                var t = ($(this).text() || '').trim().toLowerCase();
                var isFeedLabel = t.indexOf('feed') > -1 && (t.indexOf('compartilh') > -1 || t.indexOf('share') > -1 || t.indexOf('também') > -1 || t.indexOf('tambem') > -1 || t.indexOf('also') > -1);
                if (isFeedLabel && $(this).children().length <= 2) {
                    try {
                        var box = $(this).closest('div').parent().find('input[type="checkbox"], div[role="switch"], button[aria-checked]').first();
                        if (box && box.length) candidates.push(box);
                    } catch (e) {}
                }
            });
        }
        var acted = false;
        candidates.forEach(function (el) {
            if (acted) return;
            try {
                var on = el.prop ? el.prop('checked') : undefined;
                var aria = el.attr ? el.attr('aria-checked') : undefined;
                var isOn = (on === true) || (aria === 'true');
                var isOff = (on === false) || (aria === 'false');
                if (isOn) {
                    outputMessage("✓ Desativando 'Compartilhar no feed' (reels fora do feed)...");
                    simulateClick(el[0] || el);
                    acted = true;
                } else if (isOff) {
                    outputMessage("  → 'Compartilhar no feed' já está desativado.");
                    acted = true;
                }
            } catch (e) {}
        });
        if (!acted) outputMessage("  → opção 'feed' não encontrada nesta tela (segue com padrão do Instagram).");
        return acted;
    } catch (e) { return false; }
}

function isValidShareButton(elem) {
    if (!elem || elem.length === 0) return false;
    if (elem.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, #vp_ai_main_panel').length) return false;
    if (!elem.is(':visible')) return false;
    if (elem.prop('disabled')) return false;
    var txt = (elem.text() || '').trim().toLowerCase();
    var aria = (elem.attr('aria-label') || '').trim().toLowerCase();
    var shareTerms = ['share','compartilhar','publicar','post','postar','publish','enviar','done','ok','concluir'];
    for (var i = 0; i < shareTerms.length; i++) {
        var term = shareTerms[i];
        if (txt === term || txt.indexOf(term) > -1 || aria === term || aria.indexOf(term) > -1) {
            return true;
        }
    }
    return false;
}

function clickShareButton() {
    outputMessage("Procurando botão de compartilhar/publicar...");
    
    var possibleTexts = ['share', 'compartilhar', 'publicar', 'post', 'postar', 'publish', 'submit', 'enviar', 'done', 'ok', 'concluir'];
    
    // Esconder extensão imediatamente para evitar que seus botões interfiram na busca
    try {
        var idsToHide = ['igBotInjectedContainer', 'igBotContainer', 'instabotIcon'];
        idsToHide.forEach(function(id) {
            var panelEl = document.getElementById(id);
            if (panelEl) { panelEl.style.setProperty('display', 'none', 'important'); }
        });
    } catch(e) {}

    // Busca 1: usar findInstaButton e validar com isValidShareButton
    var shareBtn = findInstaButton(possibleTexts);
    if (shareBtn && shareBtn.length && !isValidShareButton(shareBtn)) {
        shareBtn = null;
    }

    // Busca 2: botão submit fora da extensão, filtrado
    if (!shareBtn) {
        var submitBtn = $('button[type="submit"]').not('#igBotInjectedContainer *').not('#igBotContainer *').filter(function(){ return isValidShareButton($(this)); }).last();
        if (submitBtn.length) shareBtn = submitBtn;
    }

    // Busca 3: último botão da página que passe nas validações
    if (!shareBtn) {
        var allBtns = $('button, div[role="button"]').not('#igBotInjectedContainer *').not('#igBotContainer *').not('[id^="vp_"]').not('[class*="igBot"]');
        for (var i = allBtns.length - 1; i >= 0; i--) {
            var btn = $(allBtns[i]);
            if (isValidShareButton(btn)) {
                shareBtn = btn;
                outputMessage("  → Usando último botão válido com texto: '" + btn.text().trim() + "'");
                break;
            }
        }
    }
    
    if (shareBtn && shareBtn.length > 0) {
        var btnText = shareBtn.text().trim() || shareBtn.attr('aria-label') || 'desconhecido';
        outputMessage("✓ Disparando clique no botão: '" + btnText + "'");
        simulateClick(shareBtn[0]);
        outputMessage("✓ Botão de publicar clicado! Aguardando publicação...");
        $('#vp_ai_status').text('Publicando...').css('color', '#ecc94b');
        // Verifica se o clique surtiu efeito (tela de detalhes SUMIU de verdade) com retentativas
        var shareTries = 0;
        var shareCheck = setInterval(function() {
            if (window.__vp_aborted) { clearInterval(shareCheck); return; }
            var detailsGone = true;
            try {
                var d = $('div[role="dialog"]');
                var scope2 = d.length > 0 ? d : $('body');
                var cap = scope2.find('div[role="textbox"], div[contenteditable="true"], [data-lexical-editor], textarea[name="caption"]').filter(function () {
                    try { return !this.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, #vp_ai_main_panel'); } catch (e) { return true; }
                });
                var sh = scope2.find('div[role="button"], button').filter(function () {
                    var tt = ($(this).text() || '').trim().toLowerCase();
                    return tt === 'compartilhar' || tt === 'share' || tt === 'publicar';
                });
                detailsGone = !(cap.length > 0 && sh.length > 0);
            } catch (e) {}
            var successText = $('span:contains("shared"), span:contains("compartilhada"), h2:contains("shared"), h2:contains("compartilhada")').length > 0;
            if (detailsGone || successText) {
                clearInterval(shareCheck);
                monitorPostingSuccess();
                return;
            }
            // Compartilhar DESATIVADO = vídeo ainda subindo: espera (até ~2min) sem gastar tentativa
            try {
                var shDis = shareBtn.prop ? shareBtn.prop('disabled') : false;
                var shAria = shareBtn.attr ? shareBtn.attr('aria-disabled') : null;
                if (shDis === true || shAria === 'true') {
                    window.__vp_share_waits = (window.__vp_share_waits || 0) + 1;
                    if (window.__vp_share_waits <= 40) {
                        if (window.__vp_share_waits % 8 === 1) outputMessage('  → Compartilhar desativado (upload em andamento), aguardando...');
                        return;
                    }
                }
            } catch (e) {}
            window.__vp_share_waits = 0;
            shareTries++;
            if (shareTries >= 3) {
                clearInterval(shareCheck);
                outputMessage("❌ Compartilhar não avançou (tela parada). Arquivo MANTIDO na fila.");
                outputMessage("💡 Clique manualmente em 'Compartilhar' no Instagram. O sucesso será detectado.");
                $('#vp_ai_status').text('Clique em Compartilhar').css('color', '#e53e3e');
                chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                window.__vp_posting_in_progress = false;
                try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
                monitorPostingSuccess();
                return;
            }
            outputMessage("⟳ Tentativa " + (shareTries + 1) + " no Compartilhar...");
            simulateClick(shareBtn[0]);
        }, 3000);
    } else {
        outputMessage("⟳ Nenhum botão encontrado ainda, aguardando 3s...");
        setTimeout(function() {
            var retryBtn = findInstaButton(possibleTexts);
            if (!retryBtn || retryBtn.length === 0) {
                var lastBtn = $('button, div[role="button"]').last();
                if (lastBtn.length > 0) retryBtn = lastBtn;
            }
            if (retryBtn && retryBtn.length > 0) {
                outputMessage("✓ Botão encontrado na 2ª tentativa: '" + retryBtn.text().trim() + "'");
                simulateClick(retryBtn[0]);
                $('#vp_ai_status').text('Publicando...').css('color', '#ecc94b');
                monitorPostingSuccess();
            } else {
                outputMessage("❌ Botão de publicar não encontrado.");
                outputMessage("💡 A legenda foi preenchida. Clique manualmente em 'Compartilhar' ou 'Publicar' no Instagram.");
                $('#vp_ai_status').text('Clique em Compartilhar').css('color', '#e53e3e');
                chrome.storage.local.set({ 'vp_ai_posting_lock': 0 });
                window.__vp_posting_in_progress = false;
                restoreConsoleErrors();
            }
        }, 3000);
    }
}

function monitorPostingSuccess() {
    var attempts = 0;
    var MIN_ATTEMPTS_BEFORE_SUCCESS = 10; // Esperar pelo menos 5 segundos (10 x 500ms) antes de declarar sucesso
    var successInterval = setInterval(function() {
        attempts++;

        if (window.__vp_aborted) { clearInterval(successInterval); return; }

        // Erro pós-compartilhar (ex: falha no processamento): aborta MANTENDO o arquivo
        try {
            var errToast = $('div[role="dialog"], div[role="alert"]').text().toLowerCase();
            if (errToast && (errToast.indexOf('não foi possível') > -1 || errToast.indexOf('nao foi possivel') > -1 ||
                errToast.indexOf('falhou') > -1 || errToast.indexOf('tente novamente') > -1 ||
                errToast.indexOf('couldn') > -1 || errToast.indexOf('failed') > -1 ||
                errToast.indexOf('algo deu errado') > -1 || errToast.indexOf('went wrong') > -1)) {
                clearInterval(successInterval);
                vpAbortFlow('Instagram recusou a publicação.');
                return;
            }
        } catch (e) {}

        // A página pode ter diálogos que não pertencem ao compositor. Só o
        // compositor visível do Instagram deve impedir o próximo reels.
        var igDialogs = $('div[role="dialog"]').filter(function() {
            if (!$(this).is(':visible')) return false;
            try { return !this.closest('#igBotInjectedContainer, #igBotContainer, .igBotContainer, .igBotParent, #vp_ai_main_panel'); } catch (e) { return true; }
        });
        var successText = igDialogs.find('span, div, h1, h2, h3').filter(function() {
            return /(shared|compartilhad|posted|publicad)/i.test($(this).text() || '');
        });
        var composerStillOpen = igDialogs.filter(function() {
            var dialog = $(this);
            var hasEditor = dialog.find('input[type="file"], div[role="textbox"], div[contenteditable="true"], textarea').length > 0;
            var hasShare = dialog.find('button, div[role="button"]').filter(function() {
                return /^(share|compartilhar|publicar)$/i.test($(this).text().trim());
            }).length > 0;
            return hasEditor || hasShare;
        }).length > 0;
        var isComposerClosed = !composerStillOpen;
        
        // Só declarar sucesso após pelo menos MIN_ATTEMPTS_BEFORE_SUCCESS ticks
        // para evitar falso-positivo quando o modal ainda está transitando
        if (attempts >= MIN_ATTEMPTS_BEFORE_SUCCESS && (successText.length > 0 || isComposerClosed)) {
            clearInterval(successInterval);
            outputMessage("🎉 Post publicado com sucesso no Instagram!");
            $('#vp_ai_status').text('Postado com sucesso! ✅').css('color', '#48bb78');
            
            // Restaurar console.error original
            restoreConsoleErrors();
            
            // IMPORTANTE: Liberar o lock de postagem em progresso + memória do arquivo
            window.__vp_posting_in_progress = false;
            window.__vp_caption_writing = false;
            try { window.__vp_pending_file = null; window.__vp_pending_legenda = null; } catch (e) {}

            var todayStr = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate();
            // SEMPRE marca 'já postou hoje' — tanto manual quanto automático
            // Isso impede o scheduler de re-disparar dentro da janela de 30 min
            chrome.storage.local.set({ 'vp_ai_last_post_date': todayStr, 'vp_ai_posting_lock': 0 });
            sessionStorage.removeItem('__vp_post_retries');

            // 1. Fecha o modal de sucesso ANTES de encadear (evita "quer cancelar?" e corrida de composer)
            if ($('div[role="dialog"]').length > 0) {
                outputMessage("⟳ Fechando modal de sucesso...");
                try {
                    var closeBtn = $('button[aria-label*="Close" i], button[aria-label*="Fechar" i], button[aria-label*="Concluir" i], button[aria-label*="Done" i], svg[aria-label*="Close" i], svg[aria-label*="Fechar" i]').closest('button, div[role="button"]');
                    if (closeBtn.length === 0) {
                        closeBtn = $('div[role="dialog"]').find('div[role="button"], button').filter(function () {
                            var ct = ($(this).text() || '').trim().toLowerCase();
                            return ct === 'concluir' || ct === 'done' || ct === 'ok' || ct === 'fechar' || ct === 'close';
                        });
                    }
                    if (closeBtn.length > 0) {
                        simulateClick(closeBtn[0]);
                        outputMessage("✓ Modal de sucesso fechado.");
                    } else {
                        var dialogClose = $('div[role="dialog"] svg[aria-label*="Fechar" i], div[role="dialog"] svg[aria-label*="Close" i]').parent();
                        if (dialogClose.length > 0) {
                            simulateClick(dialogClose[0]);
                            outputMessage("✓ Modal de sucesso fechado via fallback.");
                        }
                    }
                } catch (e) {}
            }

            // MODO PASTA: apaga mídia do servidor para não repostar (com delay p/ composer fechar)
            if (window.__vp_current_queue_item) {
                (function (doneName, doneKind) {
                    window.__vp_current_queue_item = null;
                    window.__vp_current_queue_kind = null;
                    setTimeout(function () {
                        try {
                            chrome.runtime.sendMessage({ postQueueDone: doneName, postQueueInstagram: vpCurrentPostInstagram() }, function (resp) {
                                if (resp && resp.success) {
                                    outputMessage("🗑️ " + doneName + " apagado da pasta (foto+txt). Restam: " + resp.pending);
                                    // Encadeia o reels irmão (mesmo número) após o modal fechar
                                    if (doneKind === 'photo') {
                                        vpAutoChainReelSibling(doneName);
                                    } else {
                                        outputMessage('✅ Reels concluído. Atualizando para o feed em 6s...');
                                        setTimeout(function () {
                                            try { window.location.href = 'https://www.instagram.com/'; } catch (e) {}
                                        }, 6000);
                                    }
                                } else {
                                    outputMessage("⚠️ Postado, mas NÃO foi possível apagar " + doneName + " da pasta. Apague manualmente.");
                                }
                            });
                        } catch (e) {
                            outputMessage("⚠️ Postado, mas NÃO foi possível apagar " + doneName + " da pasta. Apague manualmente.");
                        }
                    }, 4000);
                })(window.__vp_current_queue_item, window.__vp_current_queue_kind);
            }
        } else if (attempts > 60) { // 30 segundos
            clearInterval(successInterval);
            outputMessage("⚠️ Post enviado, mas não foi possível confirmar o sucesso (sem feedback visível).");
            $('#vp_ai_status').text('Enviado (verificar IG)').css('color', '#ecc94b');
            
            // Restaurar console.error original
            restoreConsoleErrors();
            
            // IMPORTANTE: Liberar o lock de postagem em progresso
            window.__vp_posting_in_progress = false;
            
            try { if (typeof openControlsDiv === 'function') openControlsDiv(); } catch(e) {}
            $('#igBotInjectedContainer, #igBotContainer, .igBotContainer').show();
            
            var todayStr = new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate();
            // SEMPRE marca 'já postou hoje' para impedir loop
            chrome.storage.local.set({ 'vp_ai_last_post_date': todayStr, 'vp_ai_posting_lock': 0 });
            sessionStorage.removeItem('__vp_post_retries');
        }
    }, 500);
}



function findInstaButton(possibleTexts) {
    var found = null;
    
    // Função auxiliar para procurar em um conjunto de elementos
    function searchIn(elements) {
        var localFound = null;
        // 1. Tenta os botões/roles e elementos interativos comuns
        elements.find('div[role="button"], button, [role="button"], a, [tabindex="0"], div[role="menuitem"]').each(function() {
            var text = $(this).text().trim().toLowerCase();
            var ariaLabel = ($(this).attr('aria-label') || '').toLowerCase();
            var title = ($(this).attr('title') || '').toLowerCase();
            for (var i = 0; i < possibleTexts.length; i++) {
                var term = possibleTexts[i].toLowerCase();
                if (text === term || text.indexOf(term) > -1 || ariaLabel === term || ariaLabel.indexOf(term) > -1 || title === term || title.indexOf(term) > -1) {
                    localFound = $(this);
                    return false; // break
                }
            }
        });
        if (localFound) return localFound;

        // 2. Tenta os elementos de fallback (div, span, svg, etc.) mais específicos
        var candidates = [];
        possibleTexts.forEach(function(term) {
            var termLower = term.toLowerCase();
            elements.find('div, span, p, h1, h2, h3, svg, path, polyline').each(function() {
                var el = $(this);
                var txt = el.text().trim().toLowerCase();
                var ariaLabel = (el.attr('aria-label') || '').toLowerCase();
                if (txt === termLower || txt.indexOf(termLower) > -1 || ariaLabel === termLower || ariaLabel.indexOf(termLower) > -1) {
                    if (el.children().length <= 3 && txt.length < 50) {
                        candidates.push(el);
                    }
                }
            });
        });
        if (candidates.length > 0) {
            candidates.sort(function(a, b) {
                // Prioriza quem tem o texto exato igual à palavra buscada (ex: 'Compartilhar' vs 'Compartilhar no Facebook')
                var aExact = possibleTexts.some(pt => a.text().trim().toLowerCase() === pt.toLowerCase());
                var bExact = possibleTexts.some(pt => b.text().trim().toLowerCase() === pt.toLowerCase());
                if (aExact && !bExact) return -1;
                if (!aExact && bExact) return 1;
                
                // Prioriza quem não é container muito grande
                return a.text().trim().length - b.text().trim().length;
            });
            return candidates[0];
        }
        return null;
    }

    // Tenta primeiro dentro do modal/dialog (muito mais específico e seguro)
    var dialog = $('div[role="dialog"], [role="dialog"], div[aria-modal="true"]');
    if (dialog.length > 0) {
        found = searchIn(dialog);
        if (found) {
            outputMessage("  → Botão encontrado dentro do modal: '" + (found.text().trim() || found.attr('aria-label')) + "'");
            return found;
        }
    }

    // Se não encontrou no modal (ou modal não está identificado como role=dialog), busca no body inteiro
    found = searchIn($('body'));
    if (found) {
        outputMessage("  → Botão encontrado fora do modal principal: '" + (found.text().trim() || found.attr('aria-label')) + "'");
    }
    return found;
}

// Vincula eventos do painel da extensão
$('body').on('click', '#btnSyncSettings', function(e) {
    e.preventDefault();
    // Ao sincronizar manualmente, reseta o agendador para permitir re-teste
    chrome.storage.local.remove(['vp_ai_last_post_date', 'vp_ai_posting_lock', 'vp_ai_daily_attempts', 'vp_ai_attempts_date'], function() {
        console.log('[Scheduler] ♻️ Estado do agendador resetado pelo usuário.');
        syncAiSettings();
    });
});

$('body').on('click', '#btnForcePostNow', function(e) {
    e.preventDefault();
    simulateInstagramPost(true);
});

function domReady() {

    if (shouldLoadGrowbotOnThisPage() == false) return false;

    userUpdateListener();

    chrome.runtime.sendMessage({
        "updatewanted": true
    });

    waitForWinVars();
    
    // Inicia a sincronização automática de IA após carregamento do DOM
    setTimeout(syncAiSettings, 2000);
}

function waitForDomReady() {
    if (document.readyState === 'complete' || document.readyState !== 'loading') {
        domReady();
    } else {
        document.addEventListener('DOMContentLoaded', domReady);
    }
}

if (window.location.href == 'https://www.instagram.com/') {
    setTimeout(waitForDomReady, 1500);
} else {
    setTimeout(waitForDomReady, 100);
}
